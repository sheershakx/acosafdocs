<?php
require "connection.php";
$notice=$_REQUEST["notice"];
$uid=$_REQUEST["uid"];
$date=$_REQUEST["date"];

$query="INSERT INTO notice (date,notice,uid) VALUES ('$date','$notice','$uid')";

  if ($con->query($query)=== TRUE) {

    	echo "Data inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

?>