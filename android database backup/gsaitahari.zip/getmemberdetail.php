<?php
require "connection.php";
$memid=$_REQUEST["memid"];

$query="SELECT * FROM members WHERE memid like '$memid'";

$result=mysqli_query($con,$query);

if(mysqli_num_rows($result)>0)
{
	$row=mysqli_fetch_assoc($result);

	$id=$row["memid"];
	$mobile=$row["mobile"];
	$proname=$row["proname"];
	$firmname=$row["firmname"];
	$address=$row["address"];
	$pan=$row["pan"];

	$data["fmemid"] = $id;
	$data["fmobile"] = $mobile;
	$data["fproname"] = $proname;
	$data["fname"]=$firmname;
	$data["faddress"] = $address;
		$data["fpan"] = $pan;

	
	echo json_encode($data); 
	#echo "Login Succesful";

}
else{
$data["responsemessage"]="no";
echo json_encode($data);
}

?>
