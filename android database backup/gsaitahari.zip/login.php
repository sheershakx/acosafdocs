<?php
require "connection.php";
$mobile=$_REQUEST["mobile"];
$password=$_REQUEST["password"];

$query="SELECT * FROM auth where mobile like '$mobile' and password like '$password'";

$result=mysqli_query($con,$query);

if(mysqli_num_rows($result)>0)
{
	$row=mysqli_fetch_assoc($result);
	
	$mymobile=$row["mobile"];
	$usertype=$row["type"];
		$id=$row["id"];


$data["mymobile"]="$mymobile";
$data["usertype"]="$usertype";
$data["id"]="$id";
	$data["status"]="Succesful";
	echo json_encode($data); 
	#echo "Login Succesful";


   
   

}
else{
	echo "Sorry, user not found";
}

?>