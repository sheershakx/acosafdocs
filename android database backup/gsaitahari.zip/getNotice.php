<?php
require "connection.php";

$query="SELECT date,notice,uid FROM notice order by date desc";

$result=mysqli_query($con,$query);
$json_array=array();

while ($row=mysqli_fetch_assoc($result)) {
    $uid=$row["uid"];
    
    $query1="Select mobile from auth where id='$uid'";
    $result1=mysqli_query($con,$query1);
    while ($row1=mysqli_fetch_assoc($result1)) {
        
        $mobile=$row1["mobile"];
        $query2="SELECT firmname,id from members where mobile='$mobile'";
           $result2=mysqli_query($con,$query2);
           
            while ($row2=mysqli_fetch_assoc($result2)) {
                	$json_array[]=$row+$row2;
            }
    }
    

}

echo json_encode($json_array); 

?>
