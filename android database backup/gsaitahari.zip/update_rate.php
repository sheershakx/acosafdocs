<?php
require "connection.php";
$tejgold=$_REQUEST["tejgold"];
$finegold=$_REQUEST["finegold"];
$silver=$_REQUEST["silver"];
$date=$_REQUEST["date"];

$query="INSERT INTO rate_today (finegold,tejgold,silver,date) VALUES ('$finegold','$tejgold','$silver','$date')";

  if ($con->query($query)=== TRUE) {

    	echo "Data inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

?>