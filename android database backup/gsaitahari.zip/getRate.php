<?php
require "connection.php";
$date=$_REQUEST["date"];

$query="SELECT * from rate_today where date like '$date'";

$result=mysqli_query($con,$query);
$json_array=array();

while ($row=mysqli_fetch_assoc($result)) {
   
 	$json_array[]=$row;
 	
 	
 	
    }

    



echo json_encode($json_array); 

?>
