
<?php
   require "connection.php";
    $userid=$_POST["userid"];
    $orderno=$_POST["orderno"];
    $billdate=$_POST["billdate"];
    $billno=$_POST["billno"];
    $firminfo=$_POST["firminfo"];
    $product=$_POST["productdetails"]; 
    $total=$_POST["total"];

    $query="INSERT INTO bill_details (user_id,orderno,billno,billdate,client_details,product_details,total) VALUES ('$userid','$orderno','$billno','$billdate','$firminfo','$product','$total')";
    
    $querynext="UPDATE gold_order SET bill_status='1' WHERE id like '$orderno'";

    if ($con->query($query)=== TRUE) {
        if ($con->query($querynext)=== TRUE){
        

    	echo "Data inserted succesfully";
        }

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>