
<?php
   require "connection.php";
    $orderno=$_REQUEST["orderno"];
    $statustype=$_REQUEST["statustype"];
    
    if($statustype=="approve"){
          $query="UPDATE gold_order SET status='1' WHERE id='$orderno'";
    
    }else if ($statustype=="deliver"){
         $query="UPDATE gold_order SET status='2' WHERE id='$orderno'";
    }
    
    if ($con->query($query)=== TRUE) {

    	echo "Data updated succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>