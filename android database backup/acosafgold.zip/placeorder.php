
<?php
   require "connection.php";
    $firm_name=$_POST["firm_name"];
    $address=$_POST["firm_address"];
    $userid=$_POST["userid"];
    $date=$_POST["date"];
    $quantity=$_POST["quantity"];
    $rate=$_POST["rate"];
    $panno=$_POST["firm_pan"];
     $metal=$_POST["metal"];
    $total=$_POST["total"];
    $details=$_POST["details"]; 
    $status=$_POST["status"];

    $query="INSERT INTO gold_order (user_id,date,firm_name,firm_address,firm_pan,metal,quantity,rate,total,details,status) VALUES ('$userid','$date','$firm_name','$address','$panno','$metal','$quantity','$rate','$total','$details','$status')";

    if ($con->query($query)=== TRUE) {

    	echo "Data inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>