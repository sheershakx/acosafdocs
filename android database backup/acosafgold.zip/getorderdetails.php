<?php
require "connection.php";
$order_no=$_REQUEST["order_no"];

$query="SELECT * FROM gold_order WHERE id like '$order_no'";

$result=mysqli_query($con,$query);
$json_array=array();

if(mysqli_num_rows($result)>0)
{
	$row=mysqli_fetch_assoc($result);
	$userid=$row["user_id"];
	$orderno=$row["id"];
	$orderdate=$row["date"];
	$firmname=$row["firm_name"];
	$firmaddress=$row["firm_address"];
	$firmpan=$row["firm_pan"];
	$metal=$row["metal"];
	$quantity=$row["quantity"];
	$rate=$row["rate"];
	$total=$row["total"];
	$details=$row["details"];
	$status=$row["status"];
	$billstatus=$row["bill_status"];
					
$data["userid"]="$userid";
$data["orderno"]="$orderno";
$data["orderdate"]="$orderdate";
$data["firm_name"]="$firmname";
$data["firm_address"]="$firmaddress";
$data["firm_pan"]="$firmpan";
$data["metal"]="$metal";
$data["quantity"]="$quantity";
$data["rate"]="$rate";
$data["total"]="$total";
$data["details"]="$details";
$data["status"]="$status";
$data["billstatus"]="$billstatus";

	echo json_encode($data);
}
?>