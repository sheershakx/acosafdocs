<?php
require "connection.php";
$mobile=$_REQUEST["mobile"];
$password=$_REQUEST["password"];

$query="SELECT * FROM userdetail where mobile like '$mobile' and password like '$password'";

$result=mysqli_query($con,$query);

if(mysqli_num_rows($result)>0)
{
	$row=mysqli_fetch_assoc($result);
	
	$firmname=$row["firm_name"];
	$firmaddress=$row["address"];
	$firmpan=$row["panno"];
	$usertype=$row["usertype"];
	$userid=$row["id"];
	
$data["firmname"]="$firmname";
$data["firmaddress"]="$firmaddress";
$data["firmpan"]="$firmpan";
$data["usertype"]="$usertype";
$data["id"]="$userid";
	$data["status"]="Succesful";
	echo json_encode($data); 
	#echo "Login Succesful";


   
   

}
else{
	echo "Sorry, user not found";
}

?>