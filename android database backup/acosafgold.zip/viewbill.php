<?php
require "connection.php";
$orderno=$_REQUEST["order_no"];

$query="SELECT * FROM bill_details WHERE orderno like '$orderno'";

$result=mysqli_query($con,$query);
$json_array=array();

if(mysqli_num_rows($result)>0)
{
	$row=mysqli_fetch_assoc($result);
	$orderno=$row["orderno"];
	$billno=$row["billno"];
	$billdate=$row["billdate"];
	$details=$row["client_details"];
	$product=$row["product_details"];
	$total=$row["total"];

					
$data["orderno"]="$orderno";
$data["billno"]="$billno";
$data["billdate"]="$billdate";
$data["details"]="$details";
$data["product"]="$product";
$data["total"]="$total";
;

	echo json_encode($data);
}
?>