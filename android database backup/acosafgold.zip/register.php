
<?php
   require "connection.php";
    $firm_name=$_POST["firm_name"];
    $address=$_POST["address"];
    $panno=$_POST["panno"];
    $mobile=$_POST["mobile"];
    $password=$_POST["password"]; 
    $usertype=$_POST["usertype"];
  //  $hash=md5($password);

    $query="INSERT INTO userdetail (firm_name,address,panno,mobile,password,usertype) VALUES ('$firm_name','$address','$panno','$mobile','$password','$usertype')";

    if ($con->query($query)=== TRUE) {

    	echo "Data inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>