<?php
require "connection.php";

$query="SELECT * FROM gold_order ORDER BY id DESC";

$result=mysqli_query($con,$query);
$json_array=array();

while ($row=mysqli_fetch_assoc($result)) {
	$json_array[]=$row;
}

echo json_encode($json_array); 

?>
