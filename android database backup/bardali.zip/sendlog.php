
<?php
   require "phpmysqlconnect.php";
    $userid=$_POST["userid"];
    $logstring=$_POST["logstring"]; 
 

    $query="INSERT INTO activitylog (userid,logmessage) VALUES('$userid','$logstring')";

    if ($con->query($query)=== TRUE) {

    	echo "Log inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>