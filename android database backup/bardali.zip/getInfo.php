<?php
require "phpmysqlconnect.php";
$getid=$_REQUEST["itemid"];

$query="SELECT * FROM sellers_tab WHERE id like '$getid'";

$result=mysqli_query($con,$query);

if(mysqli_num_rows($result)>0)
{
	$row=mysqli_fetch_assoc($result);
	$id=$row["id"];
	$userid=$row["userid"];
	$username=$row["username"];
	$ItemName=$row["ItemName"];
	$ItemDesc=$row["ItemDesc"];
	$ItemQuantity=$row["ItemQuantity"];
	$ItemUnit=$row["ItemUnit"];
	$ItemTotal=$row["ItemTotal"];
	$HomeDelivery=$row["HomeDelivery"];
	$ImageUrl=$row["imageurl"];

	$data["sid"] = $id;
	$data["suid"] = $userid;
	$data["suname"] = $username;
	$data["sitemname"]=$ItemName;
	$data["sdesc"] = $ItemDesc;
	$data["squantity"] = $ItemQuantity;
	$data["sunit"] = $ItemUnit;
	$data["stotal"] = $ItemTotal;
	$data["sdelivery"] = $HomeDelivery;
	$data["simageurl"] = $ImageUrl;
	$data["responsemessage"] = "yes";
	
	echo json_encode($data); 
	#echo "Login Succesful";

}
else{
$data["responsemessage"]="no";
echo json_encode($data);
}

?>
