
<?php
   require "phpmysqlconnect.php";

  $userid=$_POST["userid"];
$message=$_POST["message"];
$saleno=$_POST["saleno"];


    $query="INSERT INTO openchat (saleno,userid,message) VALUES ('$saleno','$userid','$message')";

    if ($con->query($query)=== TRUE) {

    	echo "Data inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>