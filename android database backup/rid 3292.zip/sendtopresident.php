
<?php
   require "connection.php";


$message=$_POST["message"];
$fromtype=$_POST["fromtype"];

    $query="INSERT INTO president_recv (message,fromtype) VALUES ('$message','$fromtype')";
    

    if ($con->query($query)=== TRUE) {

    	echo "Data inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>