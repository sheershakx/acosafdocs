
<?php
   require "connection.php";


$message=$_POST["message"];
$clubid=$_POST["clubid"];
$fromtype=$_POST["fromtype"];


    $query="INSERT INTO ag_recv (message,fromtype,clubid) VALUES ('$message','$fromtype','$clubid')";
    

    if ($con->query($query)=== TRUE) {

    	echo "Data inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>