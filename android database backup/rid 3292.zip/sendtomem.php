
<?php
   require "connection.php";


$message=$_POST["message"];
$clubid=$_POST["clubid"];
$fromtype=$_POST["fromtype"];

    $query="INSERT INTO mem_recv (message,clubid,fromtype) VALUES ('$message','$clubid','$fromtype')";
    

    if ($con->query($query)=== TRUE) {

    	echo "Data inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>