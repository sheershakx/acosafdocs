
<?php
   require "connection.php";


$message=$_POST["message"];
$clubid=$_POST["clubid"];


    $query="INSERT INTO dg_recv (message,clubid) VALUES ('$message','$clubid')";
    

    if ($con->query($query)=== TRUE) {

    	echo "Data inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>