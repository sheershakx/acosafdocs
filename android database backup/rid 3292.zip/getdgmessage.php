<?php
require "connection.php";


$querysent="SELECT * FROM dg_recv ORDER BY id DESC";

$resultsent=mysqli_query($con,$querysent);
$json_array=array();
//$resultreceived=mysqli_query($con,$queryreceived);

while ($row=mysqli_fetch_assoc($resultsent)) {
	$json_array[]=$row;
}

echo json_encode($json_array); 

?>