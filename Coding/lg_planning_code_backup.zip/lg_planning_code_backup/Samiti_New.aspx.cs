﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Samiti_New : System.Web.UI.Page
{
    public static string guid = "";
    public static double targettotal = 0;

    public static string firstbutton = "";
    public static string secondbutton = "";

    private void GetData()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from U_SamitiDetailTemp where Guid='" + guid +"'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptTable.DataSource = ds;
            rptTable.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }

    private void GetDataLive()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from U_SamitiDetail where  PlanningId='" + drpplanning.SelectedValue + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptTable.DataSource = ds;
            rptTable.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }
    private void GetData2()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from U_SamitiOtherDetailTemp where Guid='" + guid +"'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptother.DataSource = ds;
            rptother.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }


    private void GetData2Live()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from U_SamitiOtherDetail  where PlanningId='" + drpplanning.SelectedValue + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptother.DataSource = ds;
            rptother.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }
    private void GetData3()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from U_Samiti_PeopleTemp where [Guid]='" + guid +"'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptpeople.DataSource = ds;
            rptpeople.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }



    private void GetData3admin()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from U_Samiti_People where [Guid]='" + guid + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptpeople.DataSource = ds;
            rptpeople.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }


    private void GetData3Live()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from U_Samiti_People where PlanningId='" + drpplanning.SelectedValue + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptpeople.DataSource = ds;
            rptpeople.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }
    private void GetData4()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from U_Samiti_AnugamanTemp where [Guid]='" + guid + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptanupeople.DataSource = ds;
            rptanupeople.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }

    private void GetData4Live()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from U_Samiti_Anugaman  where PlannigId='" + drpplanning.SelectedValue + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptanupeople.DataSource = ds;
            rptanupeople.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }


    private void fxbuttonstatus()
    {
        if (firstbutton == "true")
        { 
        Page.ClientScript.RegisterStartupScript(this.GetType(), "disalb1", "disalb1()", true);
        }
        if (secondbutton == "true")
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "disalb2", "disalb2()", true);
        }
        
    }

    private void FxSaveDetail()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_SamitiDetailTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
       
        cmd.Parameters.Add("@SamitiName", SqlDbType.NVarChar, 440).Value = txtsamitiname.Text;
        cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 440).Value = txtsplace.Text;
        cmd.Parameters.Add("@StartDate", SqlDbType.VarChar, 40).Value = txtjointdate.Text;
        cmd.Parameters.Add("@JoinMember", SqlDbType.VarChar, 40).Value = txttotalmemeber.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
          //  btnsavesamiti.Visible = false;
            txtsamitiname.Text = "";
            txtsplace.Text = "";
            txttotalmemeber.Text = "";
            txtjointdate.Text = "";
          //  firstbutton = "true";
           // b3.Visible = false;
           // Page.ClientScript.RegisterStartupScript(this.GetType(), "disalb1", "disalb1()", true);
         //   txtjointdate.Text = "";
          //  txtsamitiname.Text = "";
          //  txtsplace.Text = "";
          //  txttotalmemeber.Text = "";
            GetData();
           // GetData2();
           // GetData3();
           // GetData4();

         //   fxclearAll();
            // FxClearAnu();
          //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
           // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }




    private void FxEditDetail(string id)
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_SamitiDetailTempUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;


        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = id;
        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;

        cmd.Parameters.Add("@SamitiName", SqlDbType.NVarChar, 440).Value = txtsamitiname.Text;
        cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 440).Value = txtsplace.Text;
        cmd.Parameters.Add("@StartDate", SqlDbType.VarChar, 40).Value = txtjointdate.Text;
        cmd.Parameters.Add("@JoinMember", SqlDbType.VarChar, 40).Value = txttotalmemeber.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
          //  btnsavesamiti.Visible = false;
            txtsamitiname.Text = "";
            txtsplace.Text = "";
            txttotalmemeber.Text = "";
            txtjointdate.Text = "";
            //  firstbutton = "true";
            // b3.Visible = false;
            // Page.ClientScript.RegisterStartupScript(this.GetType(), "disalb1", "disalb1()", true);
            //   txtjointdate.Text = "";
            //  txtsamitiname.Text = "";
            //  txtsplace.Text = "";
            //  txttotalmemeber.Text = "";
            GetData();
           // GetDataLive();
            // GetData2();
            // GetData3();
            // GetData4();

            //   fxclearAll();
            // FxClearAnu();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void FxdelDetail()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_SamitiDetailTempDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;


        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = hsamitidetail.Value;
        

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            //btnsavesamiti.Visible = false;
            txtsamitiname.Text = "";
            txtsplace.Text = "";
            txttotalmemeber.Text = "";
            txtjointdate.Text = "";
            //  firstbutton = "true";
            // b3.Visible = false;
            // Page.ClientScript.RegisterStartupScript(this.GetType(), "disalb1", "disalb1()", true);
            //   txtjointdate.Text = "";
            //  txtsamitiname.Text = "";
            //  txtsplace.Text = "";
            //  txttotalmemeber.Text = "";
            GetData();
            // GetData2();
            // GetData3();
            // GetData4();

            //   fxclearAll();
            // FxClearAnu();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }

    private void FxSaveUAnugamn()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("usp_U_Samiti_AnugamanTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlannigId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@Post", SqlDbType.NVarChar, 240).Value = drpapost.SelectedValue;
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 240).Value = txtaname.Text;
        cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 240).Value = txtaplace.Text;
        cmd.Parameters.Add("@ContactNo", SqlDbType.NVarChar, 240).Value = txtacontactno.Text;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 40).Value = Session["@fiscalyear"].ToString();

        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            txtaname.Text = "";
            txtaplace.Text = "";
            txtacontactno.Text = "";

            GetData4();
           // FxClearAnu();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
           // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }

    private void FxUpdateUAnugamn()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_Samiti_AnugamanTempUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = hopeople.Value;
        cmd.Parameters.Add("@PlannigId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@Post", SqlDbType.NVarChar, 240).Value = drpapost.SelectedValue;
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 240).Value = txtaname.Text;
        cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 240).Value = txtaplace.Text;
        cmd.Parameters.Add("@ContactNo", SqlDbType.NVarChar, 240).Value = txtacontactno.Text;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 40).Value = Session["@fiscalyear"].ToString();

        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            txtaname.Text = "";
            txtaplace.Text = "";
            txtacontactno.Text = "";

            GetData4();
            // FxClearAnu();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void FxDelUAnugamn()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_Samiti_AnugamanTempDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = hopeople.Value;
       

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            txtaname.Text = "";
            txtaplace.Text = "";
            txtacontactno.Text = "";

            GetData4();
            // FxClearAnu();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void FxSaveOtherDetail()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_SamitiOtherDetailTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@TargetTotal", SqlDbType.VarChar, 40).Value = txttargettotal.Text;
        cmd.Parameters.Add("@TargetFemale", SqlDbType.VarChar, 40).Value = txttargetfemale.Text;
        cmd.Parameters.Add("@TargetMale", SqlDbType.VarChar, 40).Value = txttargetmale.Text;
        cmd.Parameters.Add("@TargetHouse", SqlDbType.VarChar, 40).Value = txttargethouse.Text;
        cmd.Parameters.Add("@TargetJanaJati", SqlDbType.VarChar, 40).Value = txttargetjanajati.Text;
        cmd.Parameters.Add("@TargetDalit", SqlDbType.VarChar, 40).Value = txttargetdalit.Text;
        cmd.Parameters.Add("@TargetMadhesi", SqlDbType.VarChar, 40).Value = txttargetmadhesi.Text;
        cmd.Parameters.Add("@TargetOther", SqlDbType.VarChar, 40).Value = txttargetother.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

            txttargetdalit.Text = "";
            txttargetfemale.Text = "";
            txttargethouse.Text = "";
            txttargetjanajati.Text = "";
            txttargetmadhesi.Text = "";
            txttargetmale.Text = "";
            txttargetother.Text = "";
            txttotalmemeber.Text = "";
          //  GetData();
          //  btnother.Visible = false;
            secondbutton = "true";
           // Page.ClientScript.RegisterStartupScript(this.GetType(), "disalb2", "disalb2()", true);
             GetData2();
            // GetData3();
            // GetData4();

            //   fxclearAll();
            // FxClearAnu();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void FxUpdateOtherDetail()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_SamitiOtherDetailTempUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = hother.Value;
        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@TargetTotal", SqlDbType.VarChar, 40).Value = txttargettotal.Text;
        cmd.Parameters.Add("@TargetFemale", SqlDbType.VarChar, 40).Value = txttargetfemale.Text;
        cmd.Parameters.Add("@TargetMale", SqlDbType.VarChar, 40).Value = txttargetmale.Text;
        cmd.Parameters.Add("@TargetHouse", SqlDbType.VarChar, 40).Value = txttargethouse.Text;
        cmd.Parameters.Add("@TargetJanaJati", SqlDbType.VarChar, 40).Value = txttargetjanajati.Text;
        cmd.Parameters.Add("@TargetDalit", SqlDbType.VarChar, 40).Value = txttargetdalit.Text;
        cmd.Parameters.Add("@TargetMadhesi", SqlDbType.VarChar, 40).Value = txttargetmadhesi.Text;
        cmd.Parameters.Add("@TargetOther", SqlDbType.VarChar, 40).Value = txttargetother.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

            txttargetdalit.Text = "";
            txttargetfemale.Text = "";
            txttargethouse.Text = "";
            txttargetjanajati.Text = "";
            txttargetmadhesi.Text = "";
            txttargetmale.Text = "";
            txttargetother.Text = "";
            txttotalmemeber.Text = "";
            //  GetData();
            //  btnother.Visible = false;
            secondbutton = "true";
            // Page.ClientScript.RegisterStartupScript(this.GetType(), "disalb2", "disalb2()", true);
            GetData2();
            // GetData3();
            // GetData4();

            //   fxclearAll();
            // FxClearAnu();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }

    private void FxDeleteOtherDetail()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_SamitiOtherDetailTempDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = hother.Value;
        

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

            txttargetdalit.Text = "";
            txttargetfemale.Text = "";
            txttargethouse.Text = "";
            txttargetjanajati.Text = "";
            txttargetmadhesi.Text = "";
            txttargetmale.Text = "";
            txttargetother.Text = "";
            txttotalmemeber.Text = "";
            //  GetData();
            //  btnother.Visible = false;
            secondbutton = "true";
            // Page.ClientScript.RegisterStartupScript(this.GetType(), "disalb2", "disalb2()", true);
            GetData2();
            // GetData3();
            // GetData4();

            //   fxclearAll();
            // FxClearAnu();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


   private void FxSaveUPeople()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_Samiti_PeopleTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@Post", SqlDbType.VarChar, 40).Value = drpPost.SelectedValue;
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 500).Value = txtuname.Text;
        cmd.Parameters.Add("@Gender", SqlDbType.VarChar, 40).Value = drpgender.SelectedValue;
        cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 300).Value = txtuplace.Text;
        cmd.Parameters.Add("@CitizenshipNo", SqlDbType.NVarChar, 100).Value = txtucitizenshipno.Text;
        cmd.Parameters.Add("@IssuedPlace", SqlDbType.NVarChar, 40).Value = drpdistrict.SelectedValue;
        cmd.Parameters.Add("@ContactNo", SqlDbType.NVarChar, 200).Value = txtucontactno.Text;
        cmd.Parameters.Add("@Remark", SqlDbType.NVarChar, 200).Value = txturemarks.Text;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = "1"; //drpstatus.SelectedValue;
        cmd.Parameters.Add("@OffficeId", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 40).Value = "";
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            drpapost.SelectedValue = "";
            txtuname.Text = "";
            drpgender.SelectedValue = "";
            txtuplace.Text = "";
            txtucitizenshipno.Text = "";
            drpdistrict.SelectedValue = "";
            txtacontactno.Text = "";

            GetData3();

           // FxClear();
          //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
          //  lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }

   private void FxSaveUPeopleAdmin()
   {

       SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
       SqlCommand cmd = new SqlCommand("sp_U_Samiti_PeopleAdminInsert", con);
       cmd.CommandType = CommandType.StoredProcedure;

       cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
       cmd.Parameters.Add("@Post", SqlDbType.VarChar, 40).Value = drpPost.SelectedValue;
       cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 500).Value = txtuname.Text;
       cmd.Parameters.Add("@Gender", SqlDbType.VarChar, 40).Value = drpgender.SelectedValue;
       cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 300).Value = txtuplace.Text;
       cmd.Parameters.Add("@CitizenshipNo", SqlDbType.NVarChar, 100).Value = txtucitizenshipno.Text;
       cmd.Parameters.Add("@IssuedPlace", SqlDbType.NVarChar, 40).Value = drpdistrict.SelectedValue;
       cmd.Parameters.Add("@ContactNo", SqlDbType.NVarChar, 200).Value = txtucontactno.Text;
       cmd.Parameters.Add("@Remark", SqlDbType.NVarChar, 200).Value = txturemarks.Text;
       cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = "1"; //drpstatus.SelectedValue;
       cmd.Parameters.Add("@OffficeId", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
       cmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 40).Value = "";
       cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

       try
       {
           con.Open();
           cmd.ExecuteNonQuery();
           drpapost.SelectedValue = "";
           txtuname.Text = "";
           drpgender.SelectedValue = "";
           txtuplace.Text = "";
           txtucitizenshipno.Text = "";
           drpdistrict.SelectedValue = "";
           txtacontactno.Text = "";
           GetData3Live();
           //GetData3();

           // FxClear();
           //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



       }
       catch (Exception ex)
       {
           //  lblerror.Text = ex.Message.ToString();
       }
       finally
       {
           con.Close();
       }



   }


   private void FxUPdateUPeople()
   {

       SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
       SqlCommand cmd = new SqlCommand("sp_U_Samiti_PeopleTempUpdate", con);
       cmd.CommandType = CommandType.StoredProcedure;

       cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = hpeople.Value;
       cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
       cmd.Parameters.Add("@Post", SqlDbType.VarChar, 40).Value = drpPost.SelectedValue;
       cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 500).Value = txtuname.Text;
       cmd.Parameters.Add("@Gender", SqlDbType.VarChar, 40).Value = drpgender.SelectedValue;
       cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 300).Value = txtuplace.Text;
       cmd.Parameters.Add("@CitizenshipNo", SqlDbType.NVarChar, 100).Value = txtucitizenshipno.Text;
       cmd.Parameters.Add("@IssuedPlace", SqlDbType.NVarChar, 40).Value = drpdistrict.SelectedValue;
       cmd.Parameters.Add("@ContactNo", SqlDbType.NVarChar, 200).Value = txtucontactno.Text;
       cmd.Parameters.Add("@Remark", SqlDbType.NVarChar, 200).Value = txturemarks.Text;
       cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = "1"; //drpstatus.SelectedValue;
       cmd.Parameters.Add("@OffficeId", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
       cmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 40).Value = "";
       cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

       try
       {
           con.Open();
           cmd.ExecuteNonQuery();
           drpapost.SelectedValue = "";
           txtuname.Text = "";
           drpgender.SelectedValue = "";
           txtuplace.Text = "";
           txtucitizenshipno.Text = "";
           drpdistrict.SelectedValue = "";
           txtacontactno.Text = "";

           GetData3();

           // FxClear();
           //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



       }
       catch (Exception ex)
       {
           //  lblerror.Text = ex.Message.ToString();
       }
       finally
       {
           con.Close();
       }



   }


   private void FxdelUPeople()
   {

       SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
       SqlCommand cmd = new SqlCommand("sp_U_Samiti_PeopleTempDelete", con);
       cmd.CommandType = CommandType.StoredProcedure;

       cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = hpeople.Value;
       

       try
       {
           con.Open();
           cmd.ExecuteNonQuery();
           drpapost.SelectedValue = "";
           txtuname.Text = "";
           drpgender.SelectedValue = "";
           txtuplace.Text = "";
           txtucitizenshipno.Text = "";
           drpdistrict.SelectedValue = "";
           txtacontactno.Text = "";

           GetData3();

           // FxClear();
           //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



       }
       catch (Exception ex)
       {
           //  lblerror.Text = ex.Message.ToString();
       }
       finally
       {
           con.Close();
       }



   }


    protected void btnsavesamiti_Click(object sender, EventArgs e)
    {
        if (h1.Value == "Save")
        {

            FxSaveDetail();
        }
        else if (h1.Value == "Edit")
        {
            FxEditDetail(hsamitidetail.Value);
        
        }

        else if (h1.Value == "Delete")
        {

            FxdelDetail();
        }

    }

    protected void btnpeople_Click(object sender, EventArgs e)
    {
        Class1 a=new Class1();
       // FxSaveUPeople();

    //    if (Session["UserGroup"].ToString() == "2")
      //  {
        //    FxSaveUPeopleAdmin();
         //   return;
      //  }


        if (h3.Value == "Save")
        {

            if (a.fxrecordcheck("select * from U_Samiti_PeopleTemp where CitizenshipNo='" + txtucitizenshipno.Text + "'") == true)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Citizenship already exits !')", true);
                return;

            }

            if (a.fxrecordcheck("select * from U_Samiti_People where CitizenshipNo='" + txtucitizenshipno.Text + "'") == true)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Citizenship already exits !')", true);
                return;

            }
            

            
            FxSaveUPeople();
        }
        else if (h3.Value == "Edit")
        {
            FxUPdateUPeople();

        }

        else if (h3.Value == "Delete")
        {
            FxdelUPeople();
            view.Visible = true;
            GetDataLive();
            GetData2Live();
            GetData3Live();
            GetData4Live();
           // btnproceed_Click(sender, e);

           // FxDeleteOtherDetail();
        }

    }

    protected void btnanusave_Click(object sender, EventArgs e)
    {

        


        if (h4.Value == "Save")
        {

            FxSaveUAnugamn();
        }
        else if (h4.Value == "Edit")
        {
            FxUpdateUAnugamn();

        }

        else if (h4.Value == "Delete")
        {

            FxDelUAnugamn();
        }

    }

    



    protected void btnother_Click(object sender, EventArgs e)
    {
        string d = txttargettotal.Text;
        

        if (h2.Value == "Save")
        {

            FxSaveOtherDetail();
        }
        else if (h2.Value == "Edit")
        {
            FxUpdateOtherDetail();

        }

        else if (h2.Value == "Delete")
        {

            FxDeleteOtherDetail();
        }


    }



    protected void Page_Load(object sender, EventArgs e)

    {
        fxbuttonstatus();
        if (!IsPostBack)
        {

            
            view.Visible = false;   
            //txttargetdalit.Attributes.Add("Type","Number");
            //txttargetfemale.Attributes.Add("Type","Number");
            //txttargethouse.Attributes.Add("Type","Number");
            //txttargetjanajati.Attributes.Add("Type","Number");
            //txttargetmadhesi.Attributes.Add("Type","Number");
            //txttargetother.Attributes.Add("Type","Number");
            //txttargettotal.Attributes.Add("Type","Number");
            //txttotalmemeber.Attributes.Add("Type", "Number");
           // targettotal =Convert.ToDouble(txttargettotal.Text);
            Class1 a = new Class1();
            guid = System.Guid.NewGuid().ToString();
            btnsavesamiti.Visible = true;
            btnother.Visible = true;
            //txttargettotal.Text = "56";
            //a.loadcombo(drpsubject, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from Plansubject", "Name", "ID");
             // a.loadgrid(GridView1, "Select * from planHead");
            // a.loadgrid(GridView2, "Select * from planHead");
          //  a.loadcombo(drpplanning, @"Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning where [Process]=1", "Name", "Id");
           a.loadcombo(drpPost, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from SamitiPostType", "Name", "ID");
            a.loadcombo(drpgender, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from GenderType", "Name", "ID");
            a.loadcombo(drpdistrict, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from District", "Name", "ID");

          
            a.loadcomboForFiscalyear(drpfiscalyear, "select * from Fiscalyear order by Id desc ", "FiscalYear", "FiscalYear");
            a.loadcombo(drpwardno, "select * from WardName order by Id asc ", "Name", "Name");
            a.loadcombo(drpapost, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from SamitiPostType", "Name", "ID");
            a.loadcombo(drpagender, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from GenderType", "Name", "ID");

            drpwardno_SelectedIndexChanged(sender, e);

            if (drpplanning.Items.Count > 1)
            {
                btnproceed1.Visible = true;

            }
            else
            {
              //  btnproceed1.Visible = false;
            }

        }
    }



    private void FxSaveAll()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_SamitiDetailInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

           // fxclearAll();
            // FxClearAnu();
            rptanupeople.DataSource = null;
            rptanupeople.DataBind();
            rptother.DataSource = null;
            rptother.DataBind();
            rptpeople.DataSource = null;
            rptpeople.DataBind();
            rptTable.DataSource = null;
            rptTable.DataBind();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);
            view.Visible = false;


        }
        catch (Exception ex)
        {
           // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }

    private void FxPlanningDetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning where Id= " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    lbldetail.Text = " स्थान : " + myreader["Place"].ToString() + ",     वडा नं. :" + myreader["WardNo"].ToString() + ",   आर्थिक बर्ष : " + myreader["FiscalYear"].ToString();
                    //   txtpplace.Text = myreader["Place"].ToString();
                    //  txtpward.Text = myreader["WardNo"].ToString();
                    //  txtfiscalyear.Text = myreader["FiscalYear"].ToString();
                    //   txtsamitiname.Text = myreader["Name"].ToString() + " उपभोक्ता समिति";



                }
            }
            else
            {
                lbldetail.Text = "";
                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

   

    protected void btnproceed_Click(object sender, EventArgs e)

    {
        FxSaveAll();
    }

   


    protected void btnproceed1_Click(object sender, EventArgs e)
    {
        view.Visible = true;
        GetDataLive();
        GetData2Live();
        GetData3Live();
        GetData4Live();

    }
    protected void drpplanning_SelectedIndexChanged(object sender, EventArgs e)
    {
        FxPlanningDetail(drpplanning.SelectedValue);
    }
    //protected void drpfiscalyear_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    Class1 a = new Class1();
    //    a.loadcombo(drpplanning, @"Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning where [Process]=1 and FiscalYear='"+ drpfiscalyear.SelectedValue +"'", "Name", "Id");
    //}
    protected void drpwardno_SelectedIndexChanged(object sender, EventArgs e)
    {
        Class1 a = new Class1();
        a.loadcombo(drpplanning, @"Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning where [Process]=1 and FiscalYear='" + drpfiscalyear.SelectedValue + "' and WardNo='"+drpwardno.SelectedValue+"'", "Name", "Id");
    }
}