﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class LocateSamitPeople : System.Web.UI.Page
{
    public static string gu = "";
    public static string planid = "";


    private void Fxsamitidetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from Samiti where SamitiCode=" + id +"";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    lblcode.Text = myreader["SamitiCode"].ToString();
                    lblname.Text = myreader["Name"].ToString();
                    lbladdress.Text = myreader["Address"].ToString();
                    


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }




    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string planid = Request.QueryString["SamitiCode"].ToString();
            gu = Guid.NewGuid().ToString();
            Session["PlainId"] = planid;
            Class1 a = new Class1();
          //  a.loadgrid(GridView1, "select * from Samiti");
            a.loadforbank(drppeople, "select * from SamitiPeopleSetup", "People", "Code");
            Fxsamitidetail(planid);
        
        }
    }


    private void FxAdd()
    {
        //gu=
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_InsertSamitiPeopleDetail", con);
        cmd.CommandType = CommandType.StoredProcedure;
      //  cmd.Parameters.Add("@Code", SqlDbType.VarChar, 40).Value = drppeople.SelectedValue;
        cmd.Parameters.Add("@People", SqlDbType.VarChar, 40).Value = txtpeople.Text;
        cmd.Parameters.Add("@guid", SqlDbType.VarChar, 40).Value = gu;
        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = Session["PlainId"].ToString();

        
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            Class1 a = new Class1();
            a.loadgrid(GridView2, "select * from SamitiPeopleDetail where Guid='" + gu + "'");
            // fxClear();
            //string contractID = Convert.ToString(cmd.Parameters["@IdentitY"].Value);
            //string contractIDd = Convert.ToString(cmd.Parameters["@result"].Value);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
        }


    }

    protected void btnadd_Click(object sender, EventArgs e)
    {
        FxAdd();
    }


    private void FxSave()
    {
        //gu=
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_InsertSamitiPeopleDetail", con);
      
        cmd.Parameters.Add("@guid", SqlDbType.VarChar, 40).Value = gu;
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            // Class1 a = new Class1();
            //  a.loadgrid(GridView1, "select * from TippaniDetailTemp where Guid='" + gu + "'");
            // fxClear();
            //string contractID = Convert.ToString(cmd.Parameters["@IdentitY"].Value);
            //string contractIDd = Convert.ToString(cmd.Parameters["@result"].Value);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
        }


    }
}