﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Inventory;

public partial class change_pp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }



    private void FxSave()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_ChangePassword", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Password", SqlDbType.VarChar, 40).Value = txtconfirmpassword.Text;
        cmd.Parameters.Add("@UserId", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();


        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Information", "javascript:alert('Password changed successfully!')", true);
            // string contractID = Convert.ToString(cmd.Parameters["@IdentitY"].Value);
            // string contractIDd = Convert.ToString(cmd.Parameters["@result"].Value);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
        }


    }
    


    protected void btnchange_Click(object sender, EventArgs e)
    {
        Class1 a = new Class1();
        if (a.fxrecordcheck("select * from UserTable where password='" + txtcurrentpassword.Text + "' and  username='" + Session["USERNAME"].ToString() + "'") == true)
        {
            if (txtnewpassword.Text != txtconfirmpassword.Text)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Information", "javascript:alert('password mismatch!')", true);
            }
            else if (txtnewpassword.Text == txtconfirmpassword.Text)
            {
                FxSave();

            }

        }
        else
        {

            ScriptManager.RegisterStartupScript(this, this.GetType(), "Information", "javascript:alert('Old password not match!')", true);
        }
        
    }
}