﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class NewNewCostEstimation : System.Web.UI.Page
{
    public static string guid = "";
    public static double workorder = 0;

    private void FxPlanningDetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning where Id= " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    txtplace.Text = myreader["Place"].ToString();
                    txtward.Text = myreader["WardNo"].ToString();
                    txtfiscalyear.Text = myreader["FiscalYear"].ToString();
                    // txtremarks.Text = myreader["Remarks"].ToString();



                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }





    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


            // txttargetdalit.Attributes.Add("Type", "Number");


            //   txtqty.Attributes.Add("Type", "Number");
            //    txtrate.Attributes.Add("Type", "Number");
            //  txttotal.Attributes.Add("Type", "Number");


            guid = System.Guid.NewGuid().ToString();
            Class1 a = new Class1();
            a.loadcombo(drpcostsource, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from CostSource", "Name", "ID");
            //  a.loadgrid(GridView1, "Select * from planHead");
            // a.loadgrid(GridView2, "Select * from planHead");
            a.loadcombo(drpplanning, @"Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning where [Process]=1
                                        and Id  in (Select PlanningId from U_SamitiDetail)
                                        and Id not in (Select PlanningId from CostEstimation)", "Name", "Id");
        }
    }


    private void FxClear()
    {
       // txtremarks.Text = "";

        Session["ID"] = "";
        // drpsubject.SelectedValue = "0";
        //drpstatus.SelectedValue = "0";
        btncostadd.Text = "Save";
      //  btndelete.Enabled = false;
        Class1 a = new Class1();
        a.loadgrid(GridView1, "Select * from planHead");

    }



    private void FxDelete()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_AnugamDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            // FxClear();
            Class1 a = new Class1();
            a.loadgrid(GridView1, @"select Id,Particular,Qty,Unit,Rate,Total from CostEstimationTemp where [Guid]='" + guid + "'");

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }

    private void FxUpdate()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanHeadUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        //cmd.Parameters.Add("@SID", SqlDbType.VarChar, 100).Value = drpsubject.SelectedValue;

        //cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 500).Value = txttype.Text;

        cmd.Parameters.Add("@Description", SqlDbType.NVarChar, 500).Value = "";
        //cmd.Parameters.Add("@Status", SqlDbType.VarChar, 200).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Updated Successfully !')", true);


        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }


    private void FxSave()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanHeadInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        // cmd.Parameters.Add("@SID", SqlDbType.VarChar, 100).Value = drpsubject.SelectedValue;

        //cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 300).Value = txttype.Text;

        cmd.Parameters.Add("@Description", SqlDbType.NVarChar, 500).Value = "";
        //cmd.Parameters.Add("@Status", SqlDbType.VarChar, 200).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = "1";// Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }
    protected void btnsave_Click(object sender, EventArgs e)
    {


        if (btncostadd.Text == "Save")
        {
            FxSave();
        }
        else if (btncostadd.Text == "Update")
        {
            FxUpdate();

        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;
        Session["ID"] = row.Cells[1].Text;


        txtparticular.Text = row.Cells[1].Text;
        txtqty.Text = row.Cells[2].Text;
        txtunit.Text = row.Cells[3].Text;
        txtrate.Text = row.Cells[4].Text;
        txttotal.Text = row.Cells[5].Text;


        //  txtremarks.Text = Server.HtmlDecode(row.Cells[5].Text);
        btncostadd.Text = "Update";
      //  btndelete.Enabled = true;

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        FxClear();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        FxDelete();
    }




    private void FxCostAdd()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("usp_CostEstimationTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@Particular", SqlDbType.NVarChar, 440).Value = txtparticular.Text;
        cmd.Parameters.Add("@Qty", SqlDbType.VarChar, 40).Value = txtqty.Text;
        cmd.Parameters.Add("@Unit", SqlDbType.NVarChar, 140).Value = txtunit.Text;
        cmd.Parameters.Add("@Rate", SqlDbType.VarChar, 40).Value = txtrate.Text;
        cmd.Parameters.Add("@Total", SqlDbType.VarChar, 40).Value = txttotal.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            txtparticular.Text = "";
            txtqty.Text = "";
            txtrate.Text = "";
            txttotal.Text = "";

            Class1 a = new Class1();
            a.loadgrid(GridView1, @"select Id as '#',Particular as 'विवरण',Qty as 'परिमाण',Unit as 'इकाई',Rate as 'दर',Total as 'जम्मा' from CostEstimationTemp where [Guid]='" + guid + "'");

            double amount = 0;
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                amount = amount + Convert.ToDouble(GridView1.Rows[i].Cells[6].Text);
              //  txttotalanugam.Text = Convert.ToDouble(GridView1.Rows[i].Cells[6].Text).ToString();

            }
            txttotalanugam.Text = amount.ToString();
            // FxClear();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void FxCostSourceAdd()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_CostEstimationSourceTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@Source", SqlDbType.VarChar, 40).Value = drpcostsource.SelectedValue;
        cmd.Parameters.Add("@Amount", SqlDbType.VarChar, 40).Value = txtcostsourceamount.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            drpcostsource.Text = "";
            txtcostsourceamount.Text = "";
            Class1 a = new Class1();
            a.loadgrid(GridView2, @"select C.Id as '#',P.Name as 'स्रोतको विवरण',Amount as 'रकम' from CostEstimationSourceTemp C
                                    inner join CostSource P
                                    on C.Source=P.Id where [Guid]='" + guid + "'");



            double amount = 0;
            for (int i = 0; i < GridView2.Rows.Count; i++)
            {
                amount = amount + Convert.ToDouble(GridView2.Rows[i].Cells[3].Text);
                //  txttotalanugam.Text = Convert.ToDouble(GridView1.Rows[i].Cells[6].Text).ToString();

            }
            txttotalshrotamount.Text = amount.ToString();


            // FxClear();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void FxCostSaveAll()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_CostEstimationAll", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;
        cmd.Parameters.Add("@WorkOrderAmount", SqlDbType.VarChar, 40).Value = workorder;
        cmd.Parameters.Add("@ContigencyAmount", SqlDbType.VarChar, 40).Value = txtcontigencyamount.Text;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            FxClearAll();

            // FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    protected void btncostadd_Click(object sender, EventArgs e)
    {
        if (txttotal.Text == "")
        {

        }
        else
        {
            FxCostAdd();
        }
    }
    protected void btncostsource_Click(object sender, EventArgs e)
    {
        if (txtcostsourceamount.Text == "")
        {
        }
        else
        {
            FxCostSourceAdd();
        }
    }

    private void FxClearAll()
    {

        txtcontigencyamount.Text = "";
        txttotalshrotamount.Text = "";
        txttotalanugam.Text = "";
        txtcostsourceamount.Text = "";
        txtfiscalyear.Text = "";
        txtparticular.Text = "";
        txtplace.Text = "";
        txtqty.Text = "";
        txtrate.Text = "";
        txttotal.Text = "";
        txtunit.Text = "";
        txtward.Text = "";
        drpcostsource.SelectedValue = "";
        drpplanning.SelectedValue = "";
        GridView1.DataSource = null;
        GridView1.DataBind();
        GridView2.DataSource = null;
        GridView2.DataBind();
        
    }

    protected void btnsaveall_Click(object sender, EventArgs e)
    {
        if (txttotalanugam.Text == txttotalshrotamount.Text)
        {
            FxCostSaveAll();
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Amount not Equal !')", true);
        }
    }
    protected void drpplanning_SelectedIndexChanged(object sender, EventArgs e)
    {
        FxPlanningDetail(drpplanning.SelectedValue);
    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView2.SelectedRow;
        Session["ID"] = row.Cells[1].Text;

        drpcostsource.SelectedValue = row.Cells[2].Text;
        txtcostsourceamount.Text = row.Cells[3].Text;

        // txtparticular.Text = row.Cells[1].Text;
        //  txtqty.Text = row.Cells[2].Text;
        //  txtunit.Text = row.Cells[3].Text;
        //  txtrate.Text = row.Cells[4].Text;
        // txttotal.Text = row.Cells[5].Text;


        //  txtremarks.Text = Server.HtmlDecode(row.Cells[5].Text);
        // btncostadd.Text = "Update";
        //  btndelete.Enabled = true;
    }
    protected void GridView2_SelectedIndexChanged1(object sender, EventArgs e)
    {
        GridViewRow row = GridView2.SelectedRow;
        Session["ID"] = row.Cells[1].Text;

        drpcostsource.SelectedItem.Text = row.Cells[2].Text;
        txtcostsourceamount.Text = row.Cells[3].Text;
    }
    protected void btndeleteforcost_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_CostEstimationSourceTemp", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            Class1 a = new Class1();
            a.loadgrid(GridView2, @"select C.Id,P.Name as Source,Amount from CostEstimationSourceTemp C
                                    inner join CostSource P
                                    on C.Source=P.Id where [Guid]='" + guid + "'");

            // FxClear();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }


    }
    protected void txtqty_TextChanged(object sender, EventArgs e)
    {
       // double rate = 0;
       // double qty = 0;
       // double total = 0;
       //// txtrate.Text = "0";
       // rate = Convert.ToDouble(txtrate.Text);
       // qty = Convert.ToDouble(txtqty.Text);
       // total = rate * qty;
       // txttotal.Text = total.ToString();
    }
    protected void txtrate_TextChanged(object sender, EventArgs e)
    {
        double rate = 0;
        double qty = 0;
        double total = 0;
       // txtrate.Text = "0";
        rate = Convert.ToDouble(txtrate.Text);
        qty = Convert.ToDouble(txtqty.Text);
        total = rate * qty;
        txttotal.Text = total.ToString();
    }
    protected void txtcontigencyamount_TextChanged(object sender, EventArgs e)
    {
        double total = 0;
        double cont = 0;
        double net = 0;
        // txtrate.Text = "0";
        total = Convert.ToDouble(txttotalshrotamount.Text);
        cont = Convert.ToDouble(txtcontigencyamount.Text);
        total = total - cont;
        lblworkorder.Text = "Work order Amount :" + total.ToString();
        workorder = total;
    }
}