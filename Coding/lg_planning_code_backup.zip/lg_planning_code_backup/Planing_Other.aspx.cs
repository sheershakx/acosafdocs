﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Planing_Other : System.Web.UI.Page
{
    public static string newid = "";

    public static string guid = "";


    private void FxGetPlanningDetail1(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {


                    drpplanning.SelectedValue = myreader["Id"].ToString();
                    txtward.Text = myreader["WardNo"].ToString();
                    txtplace.Text = myreader["Place"].ToString();

                 



                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();



                }

                Class1 a = new Class1();
                a.loadgrid2(GridView2, @"select P.Name as Source,Amount from CostEstimationSource C
                                    inner join CostSource P
                                    on C.Source=P.Id");
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }




    private void FxGetPlannigDetail(string Id)
    {

        // sql1 = "";



        string sql = @"select * from PlanningActivity where Id=" + Id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    Class1 a = new Class1();


                  //  txtactivity.Text = myreader["ActivityDetail"].ToString();
                  //  txtdocumentname.Text = myreader["DocumentDetail"].ToString();
                   // txtotherDetail.Text = myreader["OtherDetail"].ToString();
                    // txtremarks.Text = myreader["PlanSubject"].ToString();





                    // lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();
                    // string logo = myreader["LogoPath"].ToString();
                    // lbldate.Text = System.DateTime.Now.ToString();


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }



    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Class1 a = new Class1();
            txtcostamount.Attributes.Add("Type", "Number");
            txtaggrementamount.Attributes.Add("Type", "Number");
            a.loadcombo(drpcostsource, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from CostSource", "Name", "ID");
            a.loadcombo(drpplanning, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning", "Name", "Id");
            a.loadgrid(GridView2, @"select P.Id,C.Name,Amount from PlanningOtherDetailSourceTemp P
                                    inner join CostSource C
                                    on P.SourceId=C.ID where [Guid] ='" + guid + "'");
            string id = Request.QueryString["id"].ToString();
            newid = id;
            FxGetPlanningDetail1(id);

        }
    }


    private void FxClear()
    {
        //txtremarks.Text = "";

        //Session["ID"] = "";
        //// drpsubject.SelectedValue = "0";
        ////drpstatus.SelectedValue = "0";
        //btnsave.Text = "Save";
        //btndelete.Enabled = false;
        //Class1 a = new Class1();
        //a.loadgrid(GridView1, "Select * from planHead");

    }



    private void FxDelete()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_PlanningOtherDetailSourceTempDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            FxClear();
            Class1 a = new Class1();
            a.loadgrid(GridView2, @"select P.Id,C.Name,Amount from PlanningOtherDetailSourceTemp P
                                    inner join CostSource C
                                    on P.SourceId=C.ID where [Guid] ='" + guid + "'");

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }

    private void FxUpdate()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanHeadUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        //cmd.Parameters.Add("@SID", SqlDbType.VarChar, 100).Value = drpsubject.SelectedValue;

        //cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 500).Value = txttype.Text;

        cmd.Parameters.Add("@Description", SqlDbType.NVarChar, 500).Value = txtremarks.Text;
        //cmd.Parameters.Add("@Status", SqlDbType.VarChar, 200).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Updated Successfully !')", true);


        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }


    private void FxAdd()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanningOtherDetailSourceTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@SourceId", SqlDbType.VarChar, 40).Value = drpcostsource.SelectedValue;
        cmd.Parameters.Add("@Amount", SqlDbType.VarChar, 40).Value = txtcostamount.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            Class1 a = new Class1();
            a.loadgrid(GridView2, @"select P.Id,C.Name,Amount from PlanningOtherDetailSourceTemp P
                                    inner join CostSource C
                                    on P.SourceId=C.ID where [Guid] ='" + guid + "'");
            FxClear();
           // ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void FxSaveAll()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanningOtherActivityInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@FirmName", SqlDbType.VarChar, 40).Value = txtfirmname.Text;
        cmd.Parameters.Add("@AggrementDate", SqlDbType.VarChar, 40).Value = txtaggrementdate.Text;
        cmd.Parameters.Add("@AggrementAmountt", SqlDbType.VarChar, 40).Value = txtaggrementamount.Text;
        cmd.Parameters.Add("@OtherDetail", SqlDbType.VarChar, 40).Value = txtotherdetail.Text;
        cmd.Parameters.Add("@WorkOrderDate", SqlDbType.VarChar, 40).Value = txtworkorderdate.Text;
        cmd.Parameters.Add("@OfficeId", SqlDbType.VarChar, 40).Value = "11";
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = "11";
        cmd.Parameters.Add("@EntryDate", SqlDbType.VarChar, 40).Value = "2017-01-01";
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = "1";
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;
        cmd.Parameters.Add("@bankName", SqlDbType.VarChar, 40).Value = txtbankname.Text;
        cmd.Parameters.Add("@AccountNo", SqlDbType.VarChar, 40).Value = txtaccountno.Text;
        cmd.Parameters.Add("@jamanatamount", SqlDbType.VarChar, 40).Value = txtjamanat.Text;
        cmd.Parameters.Add("@expirydate", SqlDbType.VarChar, 40).Value = txtexpirydate.Text;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }

    protected void btnsave_Click(object sender, EventArgs e)
    {


        //if (btnsave.Text == "Save")
        //{
        //    FxSave();
        //}
        //else if (btnsave.Text == "Update")
        //{
        //    FxUpdate();

        //}
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //GridViewRow row = GridView1.SelectedRow;
        //Session["ID"] = row.Cells[1].Text;


        //txtremarks.Text = Server.HtmlDecode(row.Cells[5].Text);
        //btnsave.Text = "Update";
        //btndelete.Enabled = true;

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        FxClear();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        FxDelete();
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        


        if (btnadd.Text == "Add")
        {
            FxAdd();
        }
        else if (btnadd.Text == "Update")
        {
            FxUpdate();

        }
    }
    protected void btnsave_Click1(object sender, EventArgs e)
    {
        FxSaveAll();
    }
    protected void drpplanning_SelectedIndexChanged(object sender, EventArgs e)
    {
        FxPlanningDetail(drpplanning.SelectedValue);
    }


    private void FxPlanningDetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning where Id= " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    txtplace.Text = myreader["Place"].ToString();
                    txtward.Text = myreader["WardNo"].ToString();
                    txtfiscalyear.Text = myreader["FiscalYear"].ToString();

                    txtremarks.Text = myreader["Remarks"].ToString();



                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }


    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView2.SelectedRow;
        Session["ID"] = row.Cells[1].Text;

        drpcostsource.SelectedItem.Text = row.Cells[2].Text;
        txtcostamount.Text = row.Cells[3].Text;
        //txtremarks.Text = Server.HtmlDecode(row.Cells[5].Text);
        btnadd.Text = "Update";
        //btndelete.Enabled = true;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        FxDelete();
    }
}