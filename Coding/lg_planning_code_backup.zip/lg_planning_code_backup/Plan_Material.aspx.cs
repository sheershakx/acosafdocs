﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class Plan_Material : System.Web.UI.Page
{
    public static string guid = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Class1 a = new Class1();
            guid = System.Guid.NewGuid().ToString();
            txtqty.Attributes.Add("Type", "Number");
            txtrate.Attributes.Add("Type", "Number");
            txttotal.Attributes.Add("Type", "Number");
           
            a.loadcombo(drpplanning, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning", "Name", "Id");
            a.loadcombo(drpcostsource, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from CostSource", "Name", "ID");
           
           
        }
    }


    private void FxClear()
    {
        txtremarks.Text = "";
        txtmaterial.Text = "";
        txtplace.Text = "";
        txtqty.Text = "";
        txtrate.Text = "";
        txtremarks.Text = "";
        txttotal.Text = "";
        txtunit.Text = "";
        txtward.Text = "";
        Session["ID"] = "";
        drpcostsource.SelectedValue = "";
        // drpsubject.SelectedValue = "0";
        //drpstatus.SelectedValue = "0";
        btnsave.Text = "Save";
        btndelete.Enabled = false;
        Class1 a = new Class1();
       
        a.loadgrid(GridView1, "select Id as '#',MaterailDetail as 'सामाग्रीको विवरण',Qty as 'परिमाण',Unit as 'इकाई',Rate as 'दर' ,Total as 'जम्मा' from PlanningMaterial where PlanningID='" + drpplanning.SelectedValue + "'");

    }



    private void FxDelete()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanHeadDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            FxClear();

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }

    private void FxUpdate()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanningMaterialUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@SourceType", SqlDbType.VarChar, 40).Value = drpcostsource.SelectedValue;
        cmd.Parameters.Add("@MaterailDetail", SqlDbType.NVarChar, 440).Value = txtmaterial.Text;
        cmd.Parameters.Add("@Qty", SqlDbType.VarChar, 40).Value = txtqty.Text;
        cmd.Parameters.Add("@Unit", SqlDbType.NVarChar, 140).Value = txtunit.Text;
        cmd.Parameters.Add("@Rate", SqlDbType.VarChar, 40).Value = txtrate.Text;
        cmd.Parameters.Add("@Total", SqlDbType.VarChar, 40).Value = txttotal.Text;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();
        cmd.Parameters.Add("@EntryDate", SqlDbType.VarChar, 40).Value = DateTime.Now;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = "1";

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Updated Successfully !')", true);


        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }


    private void FxSave()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanningMaterialInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@SourceType", SqlDbType.VarChar, 40).Value = drpcostsource.SelectedValue;
        cmd.Parameters.Add("@MaterailDetail", SqlDbType.NVarChar, 440).Value = txtmaterial.Text;
        cmd.Parameters.Add("@Qty", SqlDbType.VarChar, 40).Value = txtqty.Text;
        cmd.Parameters.Add("@Unit", SqlDbType.NVarChar, 140).Value = txtunit.Text;
        cmd.Parameters.Add("@Rate", SqlDbType.VarChar, 40).Value = txtrate.Text;
        cmd.Parameters.Add("@Total", SqlDbType.VarChar, 40).Value = txttotal.Text;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();
        cmd.Parameters.Add("@EntryDate", SqlDbType.VarChar, 40).Value = DateTime.Now;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = "1";

      //  cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = "11";

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }
    protected void btnsave_Click(object sender, EventArgs e)
    {


        if (btnsave.Text == "Add")
        {
            FxSave();
        }
        else if (btnsave.Text == "Update")
        {
            FxUpdate();

        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;
        Session["ID"] = row.Cells[1].Text;

        txtmaterial.Text = row.Cells[2].Text;
        txtqty.Text = row.Cells[3].Text;
        txtunit.Text = row.Cells[4].Text;
        txtrate.Text = row.Cells[5].Text;
        txttotal.Text = row.Cells[6].Text;

       // txtremarks.Text = Server.HtmlDecode(row.Cells[5].Text);
        btnsave.Text = "Update";
        btndelete.Enabled = true;

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        FxClear();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        FxDelete();
    }
    protected void drpplanning_SelectedIndexChanged(object sender, EventArgs e)
    {
        FxPlanningDetail(drpplanning.SelectedValue);
        Class1 a = new Class1();
        a.loadgrid(GridView1, "select Id as '#',MaterailDetail as 'सामाग्रीको विवरण',Qty as 'परिमाण',Unit as 'इकाई',Rate as 'दर' ,Total as 'जम्मा' from PlanningMaterial where PlanningID='" + drpplanning.SelectedValue + "'");
    }


    private void FxPlanningDetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning where Id= " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    txtplace.Text = myreader["Place"].ToString();
                    txtward.Text = myreader["WardNo"].ToString();
                    txtfiscalyear.Text = myreader["FiscalYear"].ToString();
                    txtremarks.Text = myreader["Remarks"].ToString();



                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }


}