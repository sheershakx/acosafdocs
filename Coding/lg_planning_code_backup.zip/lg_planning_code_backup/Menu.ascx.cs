﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IO;

public partial class Menu : System.Web.UI.UserControl
{
   // string l = "";
   // string k = "<li class= >";
   string  l =@" <ul class='nav nav-list'>";


    //


    
                  
                 
                 // <ul class="submenu">
                   //  <li class="">
                     //   <a href="stock.aspx">
                       // <i class="menu-icon fa fa-caret-right"></i>
                      // Stock
                      //  </a>
                      //  <b class="arrow"></b>
                    // </li>
                   
                 // </ul>
              // </li>



    //




    private DataTable GetData(int parentMenuId)
    {
        string query = "SELECT [MenuId], [MenuName],  [Url],H,W,L,T FROM PIS_Menu_temp where menuuser='" + Session["USERNAME"] + "' and ParentID = @ParentID order by MenuId asc";
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            DataTable dt = new DataTable();
            using (SqlCommand cmd = new SqlCommand(query))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Parameters.AddWithValue("@ParentID", parentMenuId);
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    sda.Fill(dt);
                }
            }
            return dt;
        }
    }



    private void PopulateMenu(DataTable dt, int parentMenuId)
    {
        string currentPage = Path.GetFileName(Request.Url.AbsolutePath);
        int i = 1;
        

        foreach (DataRow row in dt.Rows)
        {
            //i = dt.Rows.Count;
            //MenuItem menuItem = new MenuItem
            //{
            //  l = "<div title=" + row["MenuName"].ToString() + "About data-options=iconCls:'icon-ok' style=overflow:auto;padding:10px;><a href=dashboard.aspx>" + row["MenuName"].ToString() + "</a></div>";
            //  Value = row["MenuId"].ToString(),
            // Text = row["MenuName"].ToString(),
            // NavigateUrl = row["NavUrl"].ToString(),
            //Selected = row["NavUrl"].ToString().EndsWith(currentPage, StringComparison.CurrentCultureIgnoreCase)
            //};

            if (parentMenuId == 0)
            {
                //Menu1.Items.Add(menuItem);
                l += @"<li class=>";
              l +=@"<a href=# class='dropdown-toggle' >";
              l +=@"<i class='menu-icon fa fa-tag'></i>";
              l +=@"<span class='menu-text'>";
                l +=@"" + row["MenuName"].ToString() + "";
                l +=@"</span>";
               
                  
                l +=@"<b class='arrow fa fa-angle-down'></b>";
                l +="</a>";
                l +="<b class='arrow'></b>";
                l += @"<ul class='submenu'>";



                
               // l += @"<div title=" + h + " data-options=iconCls:'icon-ok' style=overflow:auto;padding:10px;>";
                DataTable dtChild = this.GetData(int.Parse(row["MenuId"].ToString()));

                PopulateMenu(dtChild, int.Parse(row["MenuId"].ToString()));

            }
            else
            {




               
                l += @"<li class=>";
                l += @"<a href=" + row["Url"].ToString() + ">";
                l += @"<i class='menu-icon fa fa-caret-right'></i>";
                l += @"" + row["MenuName"].ToString() + ""; // Stock
                l += @"</a>";
                l += "<b class='arrow'></b>";
                l += @"</li>";
               // l += "</ul>"; 
                 


                //string ee = "easyui-linkbutton c1";
                //string c = "\"" + ee + "\"";
                //string jj = "PromoteABCWindow";
                //string tt = "\"" + jj + "\"";
                //string size = "resizable,scrollbars,status,height=700,width=1000";
                //string ff = "\"" + size + "\"";

                //string Fh = row["H"].ToString();
                //string Fw = row["W"].ToString();
                //string Ft = row["T"].ToString();
                //string Fl = row["L"].ToString();

                //string oo = "openRequestedPopup(this.href, this.target," + Fh + "," + Fw + "," + Ft + "," + Fl + "); return false;";
                //string ll = "\"" + oo + "\"";
               


                //l += @"<a href=" + row["Url"].ToString() + " target=" + tt + " onclick=" + ll + " class=" + c + "style=width:120px>" + row["MenuName"].ToString() + "</a></br>";


                

                if (i < dt.Rows.Count)
                {
                    i = i + 1;
                }
                else if (i == dt.Rows.Count)
                {
                  l += "</ul></li>";
                }
            }

        }
    }




    private void fxmenucreation()
    {
        // NavigationMenu.Visible = false;

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_C_T_MENU", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
          //  string contractID = Convert.ToString(cmd.Parameters["@IdentitY"].Value);
          //  string contractIDd = Convert.ToString(cmd.Parameters["@result"].Value);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
        }










        ///
      
        // NavigationMenu.Visible = true;
    }





    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {

            //if (Session["Username"].ToString() != "")
           // {
                fxmenucreation();
                DataTable dt = this.GetData(0);
                //1 patini
                PopulateMenu(dt, 0);
                Literal1.Text = l + "</ul>";
           // }

        }

    }
}