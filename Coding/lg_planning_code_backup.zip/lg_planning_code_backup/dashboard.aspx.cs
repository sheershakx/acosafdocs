﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using Inventory;

public partial class assets_dashboard : System.Web.UI.Page
{
    public string ChartLabels = null;
    public string ChartData1 = null;
    public string ChartData2 = null;
    public string ChartData3 = null;

    public string recomender = null;


    private string FxRequestedDetail()
    {

        // sql1 = "";



        string sql = @"select RoleId from UserRole where UserId='" + Session["USERNAME"].ToString() + "' and RoleId='Recommender' ";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    recomender = myreader["RoleId"].ToString();
                    


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

        return recomender;

    }

    private string FxApprovedDetail()
    {

        // sql1 = "";



        string sql = @"select RoleId from UserRole where UserId='" + Session["USERNAME"].ToString() + "' and RoleId='Approver' ";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    recomender = myreader["RoleId"].ToString();



                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

        return recomender;

    }


    private string FxGetChart()
    {

        // sql1 = "";



        string sql = @"exec s_rptpllaningsummary";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;
        this.ChartLabels = "[";
        this.ChartData1 = "[";
        this.ChartData2 = "[";
        this.ChartData3 = "[";
        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                  //  recomender = myreader["RoleId"].ToString();


                    this.ChartLabels += "'" + myreader["Name"].ToString() + "'" + ",";
                    this.ChartData1 += myreader["TotalPlanning"].ToString() + ",";
                    this.ChartData2 += myreader["RemainingTotal"].ToString() + ",";
                    this.ChartData3 += myreader["FinishedTotal"].ToString() + ","; 

                    

                }


                this.ChartLabels = this.ChartLabels.Substring(0, this.ChartLabels.Length - 2);
                this.ChartData1 = this.ChartData1.Substring(0, this.ChartData1.Length - 1);
                this.ChartData2 = this.ChartData2.Substring(0, this.ChartData2.Length - 1);
                this.ChartData3 = this.ChartData3.Substring(0, this.ChartData3.Length - 1);

                this.ChartLabels += "']";
                this.ChartData1 += "]";
                this.ChartData2 += "]";
                this.ChartData3 += "]";
            }
               
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

        return recomender;

    }


    protected void Page_Load(object sender, EventArgs e)
    {


        if (!IsPostBack)
        {
            FxGetChart();
            Class1 a = new Class1();

            //a.loadforbank(drpsentforaaa, @"select distinct S.EmployeeCode,S.FirstName from Staff S INNER JOIN UserRole U                                        
            //ON s.EmployeeCode=U.UserId where U.RoleId='Approver'", "FirstName", "EmployeeCode");

          


        }
       // this.ChartLabels = "['January', 'February', 'March', 'April', 'May', 'June', 'July']";
      //  this.ChartData1 = "[65, 59, 80, 81, 56, 55, 40]";
      //  this.ChartData2 = "[28, 48, 40, 19, 86, 27, 90]";
       // this.ChartData3 = "[60, 45, 42, 7, 84, 3, 5]";

        //Call the Javascript function from C#
       // Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "DrawChart()", true);

    }
    
}