﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class UserAuthority : System.Web.UI.Page
{




    


    private void FxMainMenu()
    {

        // sql1 = "";



        string sql = @"select MenuID,MenuName from SiteMenu where ParentMenuID=0 order by ParentMenuID,MenuID ";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    //lstmainmenu.Items.Add(myreader["MenuName"].ToString());
                   // lstmainmenu.Items.add(new ListBoxItem("name", "value"));
                    //lstmainmenu
                   
                    //   lbldate.Text = System.DateTime.Now.ToString();


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }



    private void FxGetSubMenu(string parrentid)
    {

        // sql1 = "";



        string sql = @"select MenuID,MenuName from SiteMenu where ParentMenuID=" + parrentid + " order by ParentMenuID,MenuID ";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                   // listsubmenu.Items.Add(myreader["MenuName"].ToString());


                    //   lbldate.Text = System.DateTime.Now.ToString();


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            Class1 c = new Class1();

          //  FxMainMenu();


            // Class1 c = new Class1();
            c.loadgrid(grdmain, "select MenuID,MenuName from SiteMenu where ParentMenuID=0 order by ParentMenuID,MenuID");
        }
    }
    protected void listsubmenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void lstmainmenu_SelectedIndexChanged(object sender, EventArgs e)
    {
       // FxGetSubMenu(listsubmenu.SelectedItem.Value);
    }


    private void FxAddValue()
    {
        for (int i = 0; i < lstvalue.Items.Count; i++)
        {
            txtvalue.Text = txtvalue.Text + "," + lstvalue.Items[i].Text;
        
        }
    
    }

    protected void grdmain_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = grdmain.SelectedRow;
         int parrentid = Convert.ToInt32(row.Cells[1].Text);
        Class1 c = new Class1();
        lstrole.Items.Add(row.Cells[2].Text);
        lstvalue.Items.Add(row.Cells[1].Text);
        c.loadgrid(grdsub, "select MenuID,MenuName from SiteMenu where ParentMenuID=" + parrentid + " order by ParentMenuID,MenuID");
        

    }
    protected void btnsend_Click(object sender, EventArgs e)
    {
        int j = lstrole.SelectedIndex;
        lstrole.Items.Remove(lstrole.SelectedItem.Value);
        lstvalue.Items.RemoveAt(j);
    }
    protected void grdsub_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = grdsub.SelectedRow;
        int parrentid = Convert.ToInt32(row.Cells[1].Text);
        lstvalue.Items.Add(row.Cells[1].Text);
        lstrole.Items.Add(row.Cells[2].Text);
    }
    protected void lstrole_SelectedIndexChanged(object sender, EventArgs e)
    {

    }



    private void FxSave()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_UserTableInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;


        cmd.Parameters.Add("@username", SqlDbType.VarChar, 40).Value = txtusername.Text;

        cmd.Parameters.Add("@menucode", SqlDbType.VarChar, 40).Value = txtvalue.Text;
        

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            //string contractID = Convert.ToString(cmd.Parameters["@IdentitY"].Value);
            //string contractIDd = Convert.ToString(cmd.Parameters["@result"].Value);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();



        }
    }



    protected void btnsave_Click(object sender, EventArgs e)
    {
        
        FxAddValue();
        FxSave();
    }
}