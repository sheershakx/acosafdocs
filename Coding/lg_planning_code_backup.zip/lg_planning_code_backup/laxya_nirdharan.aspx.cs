﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class laxya_nirdharan : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;
        Session["ID"] = row.Cells[1].Text;

        txttype.Text = Server.HtmlDecode(row.Cells[2].Text);
        txtremarks.Text = Server.HtmlDecode(row.Cells[3].Text);
        btnsave.Text = "Update";
        btndelete.Enabled = true;

    }

}