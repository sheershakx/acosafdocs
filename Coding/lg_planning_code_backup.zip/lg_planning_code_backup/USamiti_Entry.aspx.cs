﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class USamiti_Entry : System.Web.UI.Page
{


    public static string guid = "";

    private void FxPlanningDetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning where Id= " + id +"";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    txtpplace.Text = myreader["Place"].ToString();
                    txtpward.Text = myreader["WardNo"].ToString();
                    txtfiscalyear.Text = myreader["FiscalYear"].ToString();
                 //   txtsamitiname.Text = myreader["Name"].ToString() + " उपभोक्ता समिति";
                   


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }




    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            //txttargetdalit.Attributes.Add("Type","Number");
            //txttargetfemale.Attributes.Add("Type","Number");
            //txttargethouse.Attributes.Add("Type","Number");
            //txttargetjanajati.Attributes.Add("Type","Number");
            //txttargetmadhesi.Attributes.Add("Type","Number");
            //txttargetother.Attributes.Add("Type","Number");
            //txttargettotal.Attributes.Add("Type","Number");
            //txttotalmemeber.Attributes.Add("Type", "Number");
            Class1 a = new Class1();
            guid = System.Guid.NewGuid().ToString();
            //a.loadcombo(drpsubject, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from Plansubject", "Name", "ID");
          //  a.loadgrid(GridView1, "Select * from planHead");
           // a.loadgrid(GridView2, "Select * from planHead");
            a.loadcombo(drpplanning, @"Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning where [Process]=1
                                      and Id not in (Select PlanningId from U_SamitiDetail)", "Name", "Id");
            a.loadcombo(drpPost, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from SamitiPostType", "Name", "ID");
            a.loadcombo(drpgender, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from GenderType", "Name", "ID");
            a.loadcombo(drpdistrict, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from District", "Name", "ID");


            a.loadcombo(drpapost, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from SamitiPostType", "Name", "ID");
            a.loadcombo(drpagender, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from GenderType", "Name", "ID");
        }
    }


    private void FxClear()
    {
       // txtremarks.Text = "";
        drpPost.SelectedValue = "";
        txtuname.Text = "";
        drpgender.SelectedValue = "";
        drpdistrict.SelectedValue = "";
        drpstatus.SelectedValue = "";
        txtucitizenshipno.Text = "";
        txtucontactno.Text = "";
        txtuplace.Text = "";
        txturemarks.Text = "";
        Session["ID"] = "";
        // drpsubject.SelectedValue = "0";
        drpstatus.SelectedValue = "";
        btnsavepeple.Text = "Add";
        btndelete.Enabled = false;
        Class1 a = new Class1();
        a.loadgrid(GridView1, @"select Id as '#',Name as 'नाम, थर',Post as 'पद',Gender as 'लिङ्ग',CitizenshipNo as 'नागरिकता नं.',ContactNo as 'सम्पर्क नं.' from U_Samiti_PeopleTemp
            where [Guid]='" + guid +"'");

    }

    private void FxClearAnu()
    {
        //txtremarks.Text = "";
        drpapost.SelectedValue = "";
        drpagender.SelectedValue = "";
        txtaname.Text = "";
        txtacontactno.Text = "";
        txtaplace.Text = "";
        Session["ID"] = "";
       // drpsubject.SelectedValue = "0";
        drpstatus.SelectedValue = "";
        btnsavepeple.Text = "Save";
        btndelete.Enabled = false;
        Class1 a = new Class1();
        a.loadgrid(GridView2, "select Id as '#',Name as 'नाम, थर',Post as 'पद',Place as 'स्थान',ContactNo as 'सम्पर्क नं.' from U_Samiti_AnugamanTemp where [Guid]='" + guid +"'");

    }



    private void FxDelete()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanHeadDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            FxClear();

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }

    private void FxUpdate()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanHeadUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        //cmd.Parameters.Add("@SID", SqlDbType.VarChar, 100).Value = drpsubject.SelectedValue;

        //cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 500).Value = txttype.Text;

        cmd.Parameters.Add("@Description", SqlDbType.NVarChar, 500).Value = txtremarks.Text;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 200).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Updated Successfully !')", true);


        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }


    private void FxSave()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanHeadInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

       // cmd.Parameters.Add("@SID", SqlDbType.VarChar, 100).Value = drpsubject.SelectedValue;

        //cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 300).Value = txttype.Text;

        cmd.Parameters.Add("@Description", SqlDbType.NVarChar, 500).Value = txtremarks.Text;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 200).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = "1";// Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }



    private void FxSaved()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanHeadInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        // cmd.Parameters.Add("@SID", SqlDbType.VarChar, 100).Value = drpsubject.SelectedValue;

        //cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 300).Value = txttype.Text;

        cmd.Parameters.Add("@Description", SqlDbType.NVarChar, 500).Value = txtremarks.Text;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 200).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = "1";// Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }



    private void FxSaveUPeople()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_Samiti_PeopleTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@Post", SqlDbType.VarChar, 40).Value = drpPost.SelectedValue;
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 500).Value = txtuname.Text;
        cmd.Parameters.Add("@Gender", SqlDbType.VarChar, 40).Value = drpgender.SelectedValue;
        cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 300).Value = txtuplace.Text;
        cmd.Parameters.Add("@CitizenshipNo", SqlDbType.NVarChar, 100).Value = txtucitizenshipno.Text;
        cmd.Parameters.Add("@IssuedPlace", SqlDbType.NVarChar, 40).Value = drpdistrict.SelectedValue;
        cmd.Parameters.Add("@ContactNo", SqlDbType.NVarChar, 200).Value = txtucontactno.Text;
        cmd.Parameters.Add("@Remark", SqlDbType.NVarChar, 200).Value = txturemarks.Text;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OffficeId", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 40).Value = txtfiscalyear.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();



            FxClear();
          //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void fxclearAll()
    {
        txtacontactno.Text = "";
        txtaname.Text = "";
        txtaplace.Text = "";
        txtjointdate.Text = "";
        txtpplace.Text = "";
        txtpward.Text = "";
        txtremarks.Text = "";
        txtsamitiname.Text = "";
        txtsplace.Text = "";
        txttargetdalit.Text = "";
        txttargetfemale.Text = "";
        txttargethouse.Text = "";
        txttargetjanajati.Text = "";
        txttargetmadhesi.Text = "";
        txttargetmale.Text = "";
        txttargetother.Text = "";
        txttotalmemeber.Text = "";
        txtucitizenshipno.Text = "";
        txtucontactno.Text = "";
        txtuname.Text = "";
        txtuplace.Text = "";
        txturemarks.Text = "";
        txttargettotal.Text = "";
        txtfiscalyear.Text = "";
        drpagender.SelectedValue = "";
        drpapost.SelectedValue = "";
        drpdistrict.SelectedValue = "";
        drpgender.SelectedValue = "";
        drpplanning.SelectedValue = "";
        drpPost.SelectedValue = "";
        drpstatus.SelectedValue = "";
        GridView1.DataSource = null;
        GridView1.DataBind();
        GridView2.DataSource = null;
        GridView2.DataBind();
    
    }


    private void FxSaveUAnugamn()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("usp_U_Samiti_AnugamanTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlannigId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@Post", SqlDbType.NVarChar, 240).Value = drpapost.SelectedValue;
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 240).Value = txtaname.Text;
        cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 240).Value = txtaplace.Text;
        cmd.Parameters.Add("@ContactNo", SqlDbType.NVarChar, 240).Value = txtacontactno.Text;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = "11";
        cmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 40).Value = "11";
       
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClearAnu();
          //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }



    private void FxSaveAll()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_SamitiDetailInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@TargetTotal", SqlDbType.VarChar, 40).Value = txttargettotal.Text;
        cmd.Parameters.Add("@TargetFemale", SqlDbType.VarChar, 40).Value = txttargetfemale.Text;
        cmd.Parameters.Add("@TargetMale", SqlDbType.VarChar, 40).Value = txttargetmale.Text;
        cmd.Parameters.Add("@TargetHouse", SqlDbType.VarChar, 40).Value = txttargethouse.Text;
        cmd.Parameters.Add("@TargetJanaJati", SqlDbType.VarChar, 40).Value = txttargetjanajati.Text;
        cmd.Parameters.Add("@TargetDalit", SqlDbType.VarChar, 40).Value = txttargetdalit.Text;
        cmd.Parameters.Add("@TargetMadhesi", SqlDbType.VarChar, 40).Value = txttargetmadhesi.Text;
        cmd.Parameters.Add("@TargetOther", SqlDbType.VarChar, 40).Value = txttargetother.Text;
        cmd.Parameters.Add("@SamitiName", SqlDbType.NVarChar, 440).Value = txtsamitiname.Text;
        cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 440).Value = txtsplace.Text;
        cmd.Parameters.Add("@StartDate", SqlDbType.VarChar, 40).Value = txtjointdate.Text;
        cmd.Parameters.Add("@JoinMember", SqlDbType.VarChar, 40).Value = txttotalmemeber.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

            fxclearAll();
           // FxClearAnu();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }

    protected void btnsave_Click(object sender, EventArgs e)
    {


        if (btnsavepeple.Text == "Add")
        {
            FxSaveUPeople();
        }
        else if (btnsavepeple.Text == "Update")
        {
            FxUpdate();

        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;
        Session["ID"] = row.Cells[1].Text;


        txtremarks.Text = Server.HtmlDecode(row.Cells[5].Text);
        btnsavepeple.Text = "Update";
        btndelete.Enabled = true;

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        FxClear();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        FxDelete();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        FxSaveUAnugamn();
    }
    protected void btnsaveall_Click(object sender, EventArgs e)
    {
        FxSaveAll();
    }
    protected void drpplanning_SelectedIndexChanged(object sender, EventArgs e)
    {
        FxPlanningDetail(drpplanning.SelectedValue);
    }
    protected void drpagender_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}