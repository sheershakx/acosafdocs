﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class Usamiti : System.Web.UI.Page
{
    public static string guid = "";

    protected void drpplanning_SelectedIndexChanged(object sender, EventArgs e)
    {
        FxPlanningDetail(drpplanning.SelectedValue);
    }

    private void FxPlanningDetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning where Id= " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    lbldetail.Text = " स्थान : " + myreader["Place"].ToString() + ",     वडा नं. :" + myreader["WardNo"].ToString() + ",   आर्थिक बर्ष : " + myreader["FiscalYear"].ToString();
                    //   txtpplace.Text = myreader["Place"].ToString();
                    //  txtpward.Text = myreader["WardNo"].ToString();
                    //  txtfiscalyear.Text = myreader["FiscalYear"].ToString();
                    //   txtsamitiname.Text = myreader["Name"].ToString() + " उपभोक्ता समिति";



                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            main.Visible = false;
            //txttargetdalit.Attributes.Add("Type","Number");
            //txttargetfemale.Attributes.Add("Type","Number");
            //txttargethouse.Attributes.Add("Type","Number");
            //txttargetjanajati.Attributes.Add("Type","Number");
            //txttargetmadhesi.Attributes.Add("Type","Number");
            //txttargetother.Attributes.Add("Type","Number");
            //txttargettotal.Attributes.Add("Type","Number");
            //txttotalmemeber.Attributes.Add("Type", "Number");
            Class1 a = new Class1();
            guid = System.Guid.NewGuid().ToString();
            //a.loadcombo(drpsubject, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from Plansubject", "Name", "ID");
            //  a.loadgrid(GridView1, "Select * from planHead");
            // a.loadgrid(GridView2, "Select * from planHead");
            a.loadcombo(drpplanning, @"Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning where [Process]=1
                                      and Id not in (Select PlanningId from U_SamitiDetail)", "Name", "Id");
            a.loadcombo(drpPost, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from SamitiPostType", "Name", "ID");
            a.loadcombo(drpgender, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from GenderType", "Name", "ID");
            a.loadcombo(drpdistrict, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from District", "Name", "ID");


           // a.loadcombo(drpapost, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from SamitiPostType", "Name", "ID");
           // a.loadcombo(drpagender, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from GenderType", "Name", "ID");
        }
    }
    protected void btnproceed_Click(object sender, EventArgs e)
    {
        main.Visible = true;
        btnproceed.Visible = false;
    }


    private void FxClear()
    {
        // txtremarks.Text = "";
        drpPost.SelectedValue = "";
        txtuname.Text = "";
        drpgender.SelectedValue = "";
        drpdistrict.SelectedValue = "";
        drpstatus.SelectedValue = "";
        txtucitizenshipno.Text = "";
        txtucontactno.Text = "";
        txtuplace.Text = "";
        txturemarks.Text = "";
        Session["ID"] = "";
        // drpsubject.SelectedValue = "0";
        drpstatus.SelectedValue = "";
        btnsavepeple.Text = "Add";
        btndelete.Enabled = false;
        Class1 a = new Class1();
        a.loadgrid(GridView1, @"select Id as '#',Name as 'नाम, थर',Post as 'पद',Gender as 'लिङ्ग',CitizenshipNo as 'नागरिकता नं.',ContactNo as 'सम्पर्क नं.' from U_Samiti_PeopleTemp
            where [Guid]='" + guid + "'");

    }

    private void FxSaveUPeople()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_U_Samiti_PeopleTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@Post", SqlDbType.VarChar, 40).Value = drpPost.SelectedValue;
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 500).Value = txtuname.Text;
        cmd.Parameters.Add("@Gender", SqlDbType.VarChar, 40).Value = drpgender.SelectedValue;
        cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 300).Value = txtuplace.Text;
        cmd.Parameters.Add("@CitizenshipNo", SqlDbType.NVarChar, 100).Value = txtucitizenshipno.Text;
        cmd.Parameters.Add("@IssuedPlace", SqlDbType.NVarChar, 40).Value = drpdistrict.SelectedValue;
        cmd.Parameters.Add("@ContactNo", SqlDbType.NVarChar, 200).Value = txtucontactno.Text;
        cmd.Parameters.Add("@Remark", SqlDbType.NVarChar, 200).Value = txturemarks.Text;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OffficeId", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 40).Value = ""; //txtfiscalyear.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();



            FxClear();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
          //  lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    protected void btnsave_Click(object sender, EventArgs e)
    {


        if (btnsavepeple.Text == "Add")
        {
             FxSaveUPeople();
        }
        else if (btnsavepeple.Text == "Update")
        {
            // FxUpdate();

        }
    }
}