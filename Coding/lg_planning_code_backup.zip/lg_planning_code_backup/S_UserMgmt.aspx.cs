﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class UserMgmt : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           
            Class1 a = new Class1();

            a.loadcombo(drpGroup, "select Gcode,(CONVERT(varchar(10), Gcode) + ' - ' + Gname) as Gname from UserGroup where status=1 and Gcode>0 order by ID", "Gname", "Gcode");
            
           //a.loadgrid(GridView1, "Exec sp_show_User '" + drpGroup.SelectedValue + "', '" + Session["OfficeID"].ToString() + "'");
        }
    }

    private void FxSave()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_UserInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
       
        cmd.Parameters.Add("@username", SqlDbType.NVarChar, 40).Value = txtuser.Text;
        cmd.Parameters.Add("@password", SqlDbType.VarChar, 40).Value = txtpass.Text;
        cmd.Parameters.Add("@accesscode", SqlDbType.VarChar, 40).Value = "001";
        cmd.Parameters.Add("@createddate", SqlDbType.DateTime, 40).Value = System.DateTime.Now;
        cmd.Parameters.Add("@status", SqlDbType.VarChar, 40).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@expirydate", SqlDbType.VarChar, 40).Value = txtexpire.Text;
        cmd.Parameters.Add("@menucode", SqlDbType.VarChar, 500).Value = txtmenu.Text;
        cmd.Parameters.Add("@UserGroup", SqlDbType.VarChar, 40).Value = drpGroup.SelectedValue;
        cmd.Parameters.Add("@Description", SqlDbType.VarChar, 40).Value = "";
        cmd.Parameters.Add("@StaffId", SqlDbType.VarChar, 40).Value = "123";
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@Email", SqlDbType.VarChar, 40).Value = txtemail.Text;
        cmd.Parameters.Add("@Phone", SqlDbType.NVarChar, 100).Value = txtphone.Text;
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 40).Value = txtname.Text;
        cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 40).Value = txtaddress.Text;
        cmd.Parameters.Add("@Createdby", SqlDbType.NVarChar, 100).Value = Session ["username"].ToString();
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            fxClear();

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message;
        }
        finally
        {
            con.Close();
        }


    }

    private void FxUpdate()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_UserUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@ID", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();
        cmd.Parameters.Add("@username", SqlDbType.NVarChar, 40).Value = txtuser.Text;
        cmd.Parameters.Add("@password", SqlDbType.VarChar, 40).Value = txtpass.Text;
        cmd.Parameters.Add("@accesscode", SqlDbType.VarChar, 40).Value = "001";
        cmd.Parameters.Add("@createddate", SqlDbType.DateTime, 40).Value = System.DateTime.Now;
        cmd.Parameters.Add("@status", SqlDbType.VarChar, 40).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@expirydate", SqlDbType.VarChar, 40).Value = txtexpire.Text;
        cmd.Parameters.Add("@menucode", SqlDbType.VarChar, 500).Value = txtmenu.Text;
        cmd.Parameters.Add("@UserGroup", SqlDbType.VarChar, 40).Value = drpGroup.SelectedValue;
        cmd.Parameters.Add("@Description", SqlDbType.VarChar, 40).Value = "";
        cmd.Parameters.Add("@StaffId", SqlDbType.VarChar, 40).Value = "123";
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@Email", SqlDbType.VarChar, 40).Value = txtemail.Text;
        cmd.Parameters.Add("@Phone", SqlDbType.NVarChar, 100).Value = txtphone.Text;
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 140).Value = txtname.Text;
        cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 140).Value = txtaddress.Text;
        cmd.Parameters.Add("@Createdby", SqlDbType.NVarChar, 100).Value = Session["username"].ToString();
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            fxClear();

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message;
        }
        finally
        {
            con.Close();
        }

    }

    
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (txtuser.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Please Enter UserName  !')", true);
            txtuser.Focus();
            return;
        }
        else if (txtpass.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Please Enter Password  !')", true);
            txtpass.Focus();
            return;
        }
        else if (txtrepass.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Please Re Enter Password  !')", true);
            txtrepass.Focus();
            return;
        }
        else if (txtrepass.Text != txtpass.Text)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Please Password Mismatched  !')", true);
            txtpass.Focus();
            return;
        }
        else if (drpGroup.SelectedValue=="0")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Please Select User Group  !')", true);
            drpGroup.Focus();
            return;
        }
        else if (txtmenu.Text == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Please Select User Group  !')", true);
            drpGroup.Focus();
            return;
        }
        
        if (btnsave.Text == "Save")
        {
            FxSave();
        }
        else if (btnsave.Text == "Update")
        {
            FxUpdate();

        }
    }

    private void FxGetMenucode(string Gcode)
    {

        string sql = @"select  MenuCode from UserGroup where Gcode  ='" + Gcode + "'";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {
            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    txtmenu.Text = myreader["MenuCode"].ToString();
                   

                }
            }
            else
            {

            }

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message;
        }

        finally
        {
            myconn.Close();
        }

    }

    private void fxClear()
    {
        
        Class1 a = new Class1();
        a.loadgrid(GridView1, "Exec sp_show_User '" + drpGroup.SelectedValue + "', '" + Session["OfficeID"].ToString() + "'");
        lblerror.Text = "";
        Session["ID"] = "";
        txtname.Text = "";
        txtaddress.Text = "";
        txtemail.Text = "";
        txtphone.Text = "";
        txtexpire.Text = "";
        txtmenu.Text = "";
        txtpass.Text = "";
        txtrepass.Text = "";
        txtuser.Text = "";
       // drpGroup.SelectedValue = "0";

        btnsave.Text = "Save";
        
       
       

    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

        GridViewRow row = GridView1.SelectedRow;
        Session["ID"] = row.Cells[1].Text;
        txtuser.Text = row.Cells[2].Text;
        drpGroup.Text = row.Cells[3].Text;
        txtmenu.Text = row.Cells[4].Text;
        drpstatus.SelectedValue = row.Cells[5].Text;
        txtname.Text = row.Cells[7].Text;
        txtphone.Text = row.Cells[8].Text;
        txtemail.Text = row.Cells[9].Text;
        drpstatus.SelectedValue = row.Cells[6].Text;
        btnsave.Text = "Update";
       
    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        fxClear();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        // FxDelete();
    }

    protected void drpmtcode_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        FxGetMenucode(drpGroup.SelectedValue);
        Class1 a = new Class1();
        //a.loadgrid(GridView1, "Exec sp_show_User '" + drpGroup.SelectedValue + "', '" + Session["OfficeID"].ToString() + "'");
        txtuser.Focus();
    }
}