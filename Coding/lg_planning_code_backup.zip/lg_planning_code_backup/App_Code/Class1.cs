﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Web.Configuration;
using System.Data.SqlClient;
using System.Net;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// Summary description for Class1
/// </summary>
namespace Inventory
{
    public class Class1
    {


        // parameterless constructor required for static class

        public static string seqn = string.Empty;


        public static string pensionid;
        public static string subpensionid;

        public static string trantype;
        public static string adjustmentamount;

        public static string lettertranid;
        public static string letterpensionid;
        public static string TranId;
        public static string imagecode;
        public static string viewerTable;
        public static string firstrun;

        public static string note;
        public static string note1;
        public static string note2;


        public static string cc;
        public static string cc1;
        public static string cc2;
        public static string cc3;


        static string _importantData;
        public static string mbank_code;
        public static string mbranch_code;
        public static string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        public static SqlConnection myconn = new SqlConnection(myconnection);
        public Class1()
        {
            //
            // TODO: Add constructor logic here



            // public get, and private set for strict access control


            //
        }

        public void loadcombo(DropDownList db, string sql, string tf, string vf)
        {

            string str = System.Configuration.ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
            SqlConnection myConnection = new SqlConnection(str);

            try
            {
                myConnection.Open();

                SqlDataAdapter daAuthors = new SqlDataAdapter(sql, myConnection);

                DataSet dsPubs = new DataSet("Pubs");
                daAuthors.FillSchema(dsPubs, SchemaType.Source, "Authors");
                daAuthors.Fill(dsPubs, "Authors");
                DataTable tblAuthors;
                tblAuthors = dsPubs.Tables["Authors"];
                db.DataSource = tblAuthors;
                db.DataTextField = tf;


                db.DataValueField = vf;
                db.DataBind();
                 

                db.Items.Insert(0, new ListItem("Please Select ", ""));
                
                if (db.SelectedIndex == -1)
                {
                }

            }

            catch (Exception ex)
            {
                //Usual Code
                ex.Message.ToString();
            }

            finally
            {
                myConnection.Dispose();
            }
        }


        public void loadcomboForFiscalyear(DropDownList db, string sql, string tf, string vf)
        {

            string str = System.Configuration.ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
            SqlConnection myConnection = new SqlConnection(str);

            try
            {
                myConnection.Open();

                SqlDataAdapter daAuthors = new SqlDataAdapter(sql, myConnection);

                DataSet dsPubs = new DataSet("Pubs");
                daAuthors.FillSchema(dsPubs, SchemaType.Source, "Authors");
                daAuthors.Fill(dsPubs, "Authors");
                DataTable tblAuthors;
                tblAuthors = dsPubs.Tables["Authors"];
                db.DataSource = tblAuthors;
                db.DataTextField = tf;


                db.DataValueField = vf;
                db.DataBind();


               // db.Items.Insert(0, new ListItem("Please Select ", ""));

                if (db.SelectedIndex == -1)
                {
                }

            }

            catch (Exception ex)
            {
                //Usual Code
                ex.Message.ToString();
            }

            finally
            {
                myConnection.Dispose();
            }
        }



        public static string Encrypt(string toEncrypt, bool useHashing)
        {
            byte[] keyArray;
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);

            //System.Configuration.AppSettingsReader settingsReader = "jj";// new AppSettingsReader();
            // Get the key from config file

            // string key = (string)settingsReader.GetValue("SecurityKey",
            //    typeof(String));
            string key = "pmo@admin@123#";
            //System.Windows.Forms.MessageBox.Show(key);
            //If hashing use get hashcode regards to your key
            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                //Always release the resources and flush data
                // of the Cryptographic service provide. Best Practice

                hashmd5.Clear();
            }
            else
                keyArray = UTF8Encoding.UTF8.GetBytes(key);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            //set the secret key for the tripleDES algorithm
            tdes.Key = keyArray;
            //mode of operation. there are other 4 modes.
            //We choose ECB(Electronic code Book)
            tdes.Mode = CipherMode.ECB;
            //padding mode(if any extra byte added)

            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateEncryptor();
            //transform the specified region of bytes array to resultArray
            byte[] resultArray =
              cTransform.TransformFinalBlock(toEncryptArray, 0,
              toEncryptArray.Length);
            //Release resources held by TripleDes Encryptor
            tdes.Clear();
            //Return the encrypted data into unreadable string format
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }


        public static string Decrypt(string cipherString, bool useHashing)
        {
            byte[] keyArray;
            //get the byte code of the string

            byte[] toEncryptArray = Convert.FromBase64String(cipherString);

            //System.Configuration.AppSettingsReader settingsReader =
            //    new AppSettingsReader();
            //Get your key from config file to open the lock!
            //  string key = (string)settingsReader.GetValue("SecurityKey",
            //       typeof(String));
            string key = "pmo@admin@123#";
            if (useHashing)
            {
                //if hashing was used get the hash code with regards to your key
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                //release any resource held by the MD5CryptoServiceProvider

                hashmd5.Clear();
            }
            else
            {
                //if hashing was not implemented get the byte code of the key
                keyArray = UTF8Encoding.UTF8.GetBytes(key);
            }

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            //set the secret key for the tripleDES algorithm
            tdes.Key = keyArray;
            //mode of operation. there are other 4 modes. 
            //We choose ECB(Electronic code Book)

            tdes.Mode = CipherMode.ECB;
            //padding mode(if any extra byte added)
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(
                                 toEncryptArray, 0, toEncryptArray.Length);
            //Release resources held by TripleDes Encryptor                
            tdes.Clear();
            //return the Clear decrypted TEXT
            return UTF8Encoding.UTF8.GetString(resultArray);
        }





        public bool FxDateInvalidCheck(TextBox t)
        {
            if (t.Text != "")
            {
                if (t.Text.Length < 10)
                {
                    return false;
                }

                int diffyear = 0;
                int inputmonth = Convert.ToInt16(t.Text.Substring(5, 2));
                int inputyear = Convert.ToInt16(t.Text.Substring(0, 4));




                if (inputyear > 2099 || inputyear < 1950)
                {
                    return false;

                }

                else
                {
                    if (inputmonth > 12 || inputmonth < 1)
                    {
                        return false;
                    }
                }





                int[,] ItemNumber = new int[100, 12]
	    {
        //2000
 { 30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31 },
        //bs[2001] = 
 { 31, 31, 31, 31, 31, 31, 30, 29, 30, 29, 30, 30 }, 
        //bs[2002] = 
 {31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30},
      //[2003] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2004] = 
{30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31},
    //[2005] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2006] =
{31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30},
    //[2007] =
 {31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2008] = 
{31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 29, 31},
    //[2009] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2010] = 
{31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30},
    //[2011] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2012] = 
{31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30},
    //[2013] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2014] = 
{31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30},
    //[2015] =
 {31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2016] = 
{31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30},
    //[2017] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2018] = 
{31, 32, 31, 32, 31, 30, 30, 29, 30, 29, 30, 30},
    //[2019] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31},
    //[2020] = 
{31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2021] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2022] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30},
    //[2023] =
 {31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31},
    //[2024] = 
{31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2025] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2026] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2027] = 
{30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31},
    //[2028] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2029] = 
{31, 31, 32, 31, 32, 30, 30, 29, 30, 29, 30, 30},
    //[2030] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2031] = 
{30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31},
    //[2032] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2033] = 
{31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30},
    //[2034] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2035] = 
{30, 32, 31, 32, 31, 31, 29, 30, 30, 29, 29, 31},
    //[2036] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2037] =
 {31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30},
    //[2038] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2039] =
 {31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30},
    //[2040] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2041] =
 {31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30},
    //[2042] =
 {31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2043] = 
{31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30},
    //[2044] =
 {31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2045] = 
{31, 32, 31, 32, 31, 30, 30, 29, 30, 29, 30, 30},
    //[2046] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2047] = 
{31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2048] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2049] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30},
    //[2050] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31},
    //[2051] = 
{31, 31, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2052] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2053] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 30},
    //[2054] =
{31, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31},
    //[2055] =
 {31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2056] = 
{31, 31, 32, 31, 32, 30, 30, 29, 30, 29, 30, 30},
    //[2057] =
 {31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2058] =
 {30, 32, 31, 32, 31, 30, 30, 30, 29, 30, 29, 31},
    //[2059] =
 {31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2060] = 
{31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30},
    //[2061] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2062] = 
{30, 32, 31, 32, 31, 31, 29, 30, 29, 30, 29, 31},
    //[2063] =
 {31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2064] = 
{31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30},
    //[2065] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2066] = 
{31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 29, 31},
    //[2067] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2068] = 
{31, 31, 32, 32, 31, 30, 30, 29, 30, 29, 30, 30},
    //[2069] =
 {31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2070] = 
{31, 31, 31, 32, 31, 31, 29, 30, 30, 29, 30, 30},
    //[2071] = 
{31, 31, 32, 31, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2072] = 
{31, 32, 31, 32, 31, 30, 30, 29, 30, 29, 30, 30},
    //[2073] = 
{31, 32, 31, 32, 31, 30, 30, 30, 29, 29, 30, 31},
    //[2074] = 
{31, 32, 31, 32, 31, 31, 30, 29, 30, 29, 30, 30},
    //[2075] = 
{30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30},

 //[2076] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
 //[2077] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2078] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2079] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2080] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2081] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2082] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2083] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2084] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2085] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2086] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2087] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2088] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2089] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2090] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2091] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2092] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2093] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2094] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2095] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2096] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2097] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2098] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},
//[2099] = 
{32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32},

        };

                diffyear = inputyear - 2000;

                int day = ItemNumber[diffyear, inputmonth - 1];
                int inputday = Convert.ToInt16(t.Text.Substring(8, 2));



                if (inputday > day || inputday < 1)
                {
                    return false;

                }
                else
                {
                    return true;
                }

                // Label1.Text = ItemNumber[diffyear, inputmonth - 1].ToString();

            }
            else
            {
                return true;
            }

        }










        public bool fxrecordcheck(string sql)
        {
            // string myconnection = ConfigurationManager.ConnectionSUsdtrings["CoreConnectionString"].ConnectionString;
            SqlConnection myconn = new SqlConnection(myconnection);

            //MySqlDataAdapter mydata = new MySqlDataAdapter();
            SqlDataReader myreader;

            SqlCommand SelectCommand = new SqlCommand(sql, myconn);
            try
            {

                myconn.Open();

                myreader = SelectCommand.ExecuteReader();
                //int count = 0;
                if (myreader.HasRows) //returing false but i have 4 row
                {
                    return true;

                }
                else
                {
                    // Label1.Text = "not";
                    return false;
                }

            }
            catch (Exception ex)
            {
                //Usual Code
                ex.Message.ToString();
                return true;
            }

            finally
            {
                myconn.Close();
            }
        }


        public void fxsqlcommand(string sql, Label lbl, string msg)
        {
            //string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
            SqlConnection myconn = new SqlConnection(myconnection);

            //MySqlDataAdapter mydata = new MySqlDataAdapter();
            SqlDataReader myreader;

            SqlCommand SelectCommand = new SqlCommand(sql, myconn);
            try
            {

                myconn.Open();

                myreader = SelectCommand.ExecuteReader();
                lbl.Text = msg;


            }
            catch (Exception ex)
            {
                //Usual Code
                ex.Message.ToString();
            }

            finally
            {
                myconn.Close();
            }
        }


        public static string ImportantData
        {

            get
            {
                return _importantData;
            }
            set
            {
                _importantData = value;
            }
        }


        public void MainBank(DropDownList db, string sql, string tf, string vf)
        {

            string str = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection myConnection = new SqlConnection(str);

            //SqlCommand cmd1 = new SqlCommand("select COUNT(*) as count from Pension_Main_Bank_Master", myConnection);
            //  SqlDataReader reader1 = cmd1.ExecuteReader();




            try
            {
                myConnection.Open();

                SqlDataAdapter daAuthors = new SqlDataAdapter(sql, myConnection.ConnectionString);

                DataSet dsPubs = new DataSet("Pubs");
                daAuthors.FillSchema(dsPubs, SchemaType.Source, "Authors");
                daAuthors.Fill(dsPubs, "Authors");
                DataTable tblAuthors;
                tblAuthors = dsPubs.Tables["Authors"];
                db.DataSource = tblAuthors;
                db.DataTextField = tf;


                db.DataValueField = vf;
                db.DataBind();




            }

            catch (Exception ex)
            {
                //Usual Code
                ex.Message.ToString();
            }

            finally
            {
                myConnection.Dispose();
            }
        }



        public void loadforsex(DropDownList db, string sql, string tf, string vf)
        {

            string str = System.Configuration.ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
            SqlConnection myConnection = new SqlConnection(str);
            try
            {
                myConnection.Open();

                SqlDataAdapter daAuthors = new SqlDataAdapter(sql, myConnection);

                DataSet dsPubs = new DataSet("Pubs");
                daAuthors.FillSchema(dsPubs, SchemaType.Source, "Authors");
                daAuthors.Fill(dsPubs, "Authors");
                DataTable tblAuthors;
                tblAuthors = dsPubs.Tables["Authors"];
                db.DataSource = tblAuthors;
                db.DataTextField = tf;


                db.DataValueField = vf;
                db.DataBind();
                //   db.DataTextField = "";
                ///  db.DataValueField = "0";
                ///  

                db.Items.Insert(0, new ListItem("Please select", "-1"));
                //.style.backgroundColor = 'red';

                if (db.SelectedIndex == -1)
                {
                    // db.Items[0].Attributes.Add("style", "background-color: red");
                    //db.style.backgroundColor = "red";
                    // db.BackColor = "red";
                }


                //  ddSubCat.Items.Insert(0, new ListItem("--Select--", "-1"));

            }

            catch (Exception ex)
            {
                //Usual Code
                ex.Message.ToString();
            }

            finally
            {
                myConnection.Dispose();
            }
        }

        public void loadforbank(DropDownList db, string sql, string tf, string vf)
        {

            string str = System.Configuration.ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
            SqlConnection myConnection = new SqlConnection(str);

            try
            {
                myConnection.Open();

                SqlDataAdapter daAuthors = new SqlDataAdapter(sql, myConnection);

                DataSet dsPubs = new DataSet("Pubs");
                daAuthors.FillSchema(dsPubs, SchemaType.Source, "Authors");
                daAuthors.Fill(dsPubs, "Authors");
                DataTable tblAuthors;
                tblAuthors = dsPubs.Tables["Authors"];
                db.DataSource = tblAuthors;
                db.DataTextField = tf;


                db.DataValueField = vf;
                db.DataBind();
                //   db.DataTextField = "";
                ///  db.DataValueField = "0";
                ///  

                db.Items.Insert(0, new ListItem("Please Select ", "0"));
                //.style.backgroundColor = 'red';

                if (db.SelectedIndex == -1)
                {
                    // db.Items[0].Attributes.Add("style", "background-color: red");
                    //db.style.backgroundColor = "red";
                    // db.BackColor = "red";
                }


                //  ddSubCat.Items.Insert(0, new ListItem("--Select--", "-1"));

            }

            catch (Exception ex)
            {
                //Usual Code
                ex.Message.ToString();
            }

            finally
            {
                myConnection.Dispose();
            }
        }



        public void loadforlist(ListBox db, string sql, string tf, string vf)
        {

            string str = System.Configuration.ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
            SqlConnection myConnection = new SqlConnection(str);

            try
            {
                myConnection.Open();

                SqlDataAdapter daAuthors = new SqlDataAdapter(sql, myConnection);

                DataSet dsPubs = new DataSet("Pubs");
                daAuthors.FillSchema(dsPubs, SchemaType.Source, "Authors");
                daAuthors.Fill(dsPubs, "Authors");
                DataTable tblAuthors;
                tblAuthors = dsPubs.Tables["Authors"];
                db.DataSource = tblAuthors;
                db.DataTextField = tf;
               


                db.DataValueField = vf;
                
                db.DataBind();
                //   db.DataTextField = "";
                ///  db.DataValueField = "0";
                ///  

             //   db.Items.Insert(0, new ListItem("Please Select ", "0"));
                //.style.backgroundColor = 'red';

              //  if (db.SelectedIndex == -1)
              //  {
                    // db.Items[0].Attributes.Add("style", "background-color: red");
                    //db.style.backgroundColor = "red";
                    // db.BackColor = "red";
              //  }


                //  ddSubCat.Items.Insert(0, new ListItem("--Select--", "-1"));

            }

            catch (Exception ex)
            {
                //Usual Code
                ex.Message.ToString();
            }

            finally
            {
                myConnection.Dispose();
            }
        }



        public void load(DropDownList db, string sql, string tf, string vf)
        {

            string str = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection myConnection = new SqlConnection(str);


            try
            {
                myConnection.Open();

                SqlDataAdapter daAuthors = new SqlDataAdapter(sql, myConnection.ConnectionString);

                DataSet dsPubs = new DataSet("Pubs");
                daAuthors.FillSchema(dsPubs, SchemaType.Source, "Authors");
                daAuthors.Fill(dsPubs, "Authors");
                DataTable tblAuthors;
                tblAuthors = dsPubs.Tables["Authors"];
                db.DataSource = tblAuthors;
                db.DataTextField = tf;


                db.DataValueField = vf;
                db.DataBind();
                //   db.DataTextField = "";
                ///  db.DataValueField = "0";
                ///  

                db.Items.Insert(0, new ListItem("Please select", "0"));
                //.style.backgroundColor = 'red';

                if (db.SelectedIndex == -1)
                {
                    // db.Items[0].Attributes.Add("style", "background-color: red");
                    //db.style.backgroundColor = "red";
                    // db.BackColor = "red";
                }


                //  ddSubCat.Items.Insert(0, new ListItem("--Select--", "-1"));

            }

            catch (Exception ex)
            {
                //Usual Code
                ex.Message.ToString();
            }

            finally
            {
                myConnection.Dispose();
            }
        }






        public void loadforReport(DropDownList db, string sql, string tf, string vf)
        {

            string str = System.Configuration.ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
            SqlConnection myConnection = new SqlConnection(str);
            SqlCommand ADDCmd = new SqlCommand(sql, myConnection);

            try
            {
                myConnection.Open();

                SqlDataAdapter daAuthors = new SqlDataAdapter(ADDCmd);

                DataSet dsPubs = new DataSet("Pubs");
                daAuthors.FillSchema(dsPubs, SchemaType.Source, "Authors");
                daAuthors.Fill(dsPubs, "Authors");
                DataTable tblAuthors;
                tblAuthors = dsPubs.Tables["Authors"];
                db.DataSource = tblAuthors;
                db.DataTextField = tf;


                db.DataValueField = vf;
                db.DataBind();
                //   db.DataTextField = "";
                ///  db.DataValueField = "0";
                ///  

                db.Items.Insert(0, new ListItem("All", "0"));
                //.style.backgroundColor = 'red';

                if (db.SelectedIndex == -1)
                {
                    // db.Items[0].Attributes.Add("style", "background-color: red");
                    //db.style.backgroundColor = "red";
                    // db.BackColor = "red";
                }


                //  ddSubCat.Items.Insert(0, new ListItem("--Select--", "-1"));

            }

            catch (Exception ex)
            {
                //Usual Code
                ex.Message.ToString();
            }

            finally
            {
                myConnection.Dispose();
            }
        }



        public void FxSingleField(TextBox tt,string sql)
        {

            // sql1 = "";



            //string sql = sql;

            string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
            SqlConnection myconn = new SqlConnection(myconnection);

            //MySqlDataAdapter mydata = new MySqlDataAdapter();
            SqlDataReader myreader;

            SqlCommand SelectCommand = new SqlCommand(sql, myconn);
            try
            {

                myconn.Open();

                myreader = SelectCommand.ExecuteReader();
                // int count = 0;
                if (myreader.HasRows) //returing false but i have 4 row
                {
                    while (myreader.Read()) //returing false 
                    {

                       // lblrequestedby.Text = myreader["Name"].ToString();
                       // lbldate.Text = System.DateTime.Now.ToString();
                        tt.Text = myreader["Count"].ToString();

                    }
                }
                else
                {

                    // P_No.Focus();
                }

            }
            catch (Exception ex)
            {

            }

            finally
            {
                myconn.Close();
            }

        }







        public void loadgrid2(GridView db, string sql)
        {

            string str = System.Configuration.ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
            SqlConnection myConnection = new SqlConnection(str);

            try
            {
                myConnection.Open();

                SqlDataAdapter daAuthors = new SqlDataAdapter(sql, myConnection);

                DataSet dsPubs = new DataSet("Pubs");
                daAuthors.FillSchema(dsPubs, SchemaType.Source, "Authors");
                daAuthors.Fill(dsPubs, "Authors");
                DataTable tblAuthors;
                tblAuthors = dsPubs.Tables["Authors"];
                db.DataSource = tblAuthors;
                //db.DataTextField = tf;

                db.AutoGenerateColumns = true;
                // db.AutoGenerateSelectButton = true;
                //db.DataValueField = vf;
                db.DataBind();
            }

            catch (Exception ex)
            {
                //Usual Code
                ex.Message.ToString();
            }

            finally
            {
                myConnection.Dispose();
            }
        }




        public void loadgrid(GridView db, string sql)
        {

            string str = System.Configuration.ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
            SqlConnection myConnection = new SqlConnection(str);

            try
            {
                myConnection.Open();

                SqlDataAdapter daAuthors = new SqlDataAdapter(sql, myConnection);

                DataSet dsPubs = new DataSet("Pubs");
                daAuthors.FillSchema(dsPubs, SchemaType.Source, "Authors");
                daAuthors.Fill(dsPubs, "Authors");
                DataTable tblAuthors;
                tblAuthors = dsPubs.Tables["Authors"];
                db.DataSource = tblAuthors;
                //db.DataTextField = tf;

                db.AutoGenerateColumns = true;
                db.AutoGenerateSelectButton = true;
                //db.DataValueField = vf;
                db.DataBind();
            }

            catch (Exception ex)
            {
                //Usual Code
                ex.Message.ToString();
            }

            finally
            {
                myConnection.Dispose();
            }
        }

    }
}