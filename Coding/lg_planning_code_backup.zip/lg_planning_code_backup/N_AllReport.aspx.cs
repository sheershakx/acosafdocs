﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;

public partial class N_AllReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }




    

    


    protected void btnshow_Click(object sender, EventArgs e)
    {
        Class1 a = new Class1();
        if (drpreporttype.SelectedValue == "1")
        {
            a.loadgrid2(GridView1, "exec s_RptTotalStock");
            lblreporttitle.Text = "Opening Stock of Item Detail";
        }

        else if (drpreporttype.SelectedValue == "2")
        {
            a.loadgrid2(GridView1, "exec s_RptTotalPurchase");
            lblreporttitle.Text = "Purchase detail of Item";
        }
        else if (drpreporttype.SelectedValue == "3")
        {
            a.loadgrid2(GridView1, "exec s_RptRequest");
            lblreporttitle.Text = "Total Item Request";
        }
        else if (drpreporttype.SelectedValue == "4")
        {
            a.loadgrid2(GridView1, "exec s_RptRecomeded");
            lblreporttitle.Text = "Item recommendaton";
        }
        else if (drpreporttype.SelectedValue == "5")
        {
            a.loadgrid2(GridView1, "exec s_RptApprovalList");
            lblreporttitle.Text = "Approval List";
        }

        else if (drpreporttype.SelectedValue == "6")
        {
            a.loadgrid(GridView1, "exec s_RptTotalStock '" + Session["USERNAME"].ToString() + "'");
            lblreporttitle.Text = "Total Stock";
        }
        else if (drpreporttype.SelectedValue == "7")
        {
            a.loadgrid2(GridView1, "exec s_RptPayBook '" + Session["USERNAME"].ToString() + "'");
            lblreporttitle.Text = "Paybook of Person";
        }

        else if (drpreporttype.SelectedValue == "8")
        {
            a.loadgrid2(GridView1, "exec s_RptTotalStockAll");
            lblreporttitle.Text = "Unitwise Stock";
        }

        else if (drpreporttype.SelectedValue == "9")
        {
            a.loadgrid2(GridView1, "exec s_RptGroupwise");
            lblreporttitle.Text = "Group Wise";
        }

        else if (drpreporttype.SelectedValue == "10")
        {
            a.loadgrid(GridView1, "exec s_RptGroupwiseCountMain");
            lblreporttitle.Text = "Group Wise Number";
            Session["ReportType"] = "Group Wise Number1";
        }
        else if (drpreporttype.SelectedValue == "11")
        {
            a.loadgrid(GridView1, "exec s_RptGroupwiseCountSub");
            lblreporttitle.Text = "Group Wise Number With Sub";
            Session["ReportType"] = "Group Wise Number";
        }

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;

        // In this example, the first column (index 0) contains
        Session["ID"]= row.Cells[1].Text;
        
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "newWindow", "window.open('./SubReport.aspx','_blank','top=0,left=250,menubar=no,toolbar=no,location=no, resizable=yes,height=550,width=950,status=no,scrollbars=no,minimizable=no,maxmizable=no,resizable=0,titlebar=no;');", true);
    }
}