﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class Plan_Maintenance : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Class1 a = new Class1();
            txtcost.Attributes.Add("Type", "Number");
            txtlabourunit.Attributes.Add("Type", "Number");
            txtother.Attributes.Add("Type", "Number");
            txtservicetax.Attributes.Add("Type", "Number");
          
            txtchanda.Attributes.Add("Type", "Number");

            a.loadcombo(drpplanning, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning", "Name", "Id");
            //a.loadcombo(drpcostsource, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from CostSource", "Name", "ID");
            //a.loadgrid(GridView1, "Select * from planHead");
           // Class1 a = new Class1();
            a.loadgrid(GridView1, "select id,Firm,Labour,ServiceTax,Chanda,Cost,Other from PlanningMaintance");

        }
    }


    private void FxClear()
    {
        txtremarks.Text = "";
        txtchanda.Text = "";
        txtcost.Text = "";
        txtfirmname.Text = "";
        txtfiscalyear.Text = "";
        txtlabourunit.Text = "";
        txtother.Text = "";
        txtplace.Text = "";
        txtservicetax.Text = "";
        txtward.Text = "";


        Session["ID"] = "";
        // drpsubject.SelectedValue = "0";
        //drpstatus.SelectedValue = "0";
        btnsave.Text = "Save";
        btndelete.Enabled = false;
        Class1 a = new Class1();
        a.loadgrid(GridView1, @"select id as '#',Firm as 'जिम्मा लिने संस्था',Labour as 'श्रम शक्ति संख्या',ServiceTax as 'सेवा शुल्कबाट',Chanda as 'दस्तुर चन्दाबाट ',
                                Cost as 'लागत सहभागिता',Other as 'अन्य बचत' from PlanningMaintance where PlanningID='" + drpplanning.SelectedValue + "'");

    }



    private void FxDelete()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanHeadDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            FxClear();

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }

    private void FxUpdate()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("usp_PlanningMaintanceUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.Text;
        cmd.Parameters.Add("@Firm", SqlDbType.VarChar, 40).Value = txtfirmname.Text;
        cmd.Parameters.Add("@Labour", SqlDbType.VarChar, 40).Value = txtlabourunit.Text;
        cmd.Parameters.Add("@ServiceTax", SqlDbType.VarChar, 40).Value = txtservicetax.Text;
        cmd.Parameters.Add("@Chanda", SqlDbType.VarChar, 40).Value = txtchanda.Text;
        cmd.Parameters.Add("@Cost", SqlDbType.VarChar, 40).Value = txtcost.Text;
        cmd.Parameters.Add("@Other", SqlDbType.VarChar, 40).Value = txtother.Text;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();
        cmd.Parameters.Add("@EntryDate", SqlDbType.VarChar, 40).Value = DateTime.Now;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = "1";

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Updated Successfully !')", true);


        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }


    private void FxSave()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanningMaintanceInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.Text;
        cmd.Parameters.Add("@Firm", SqlDbType.NVarChar, 440).Value = txtfirmname.Text;
        cmd.Parameters.Add("@Labour", SqlDbType.VarChar, 40).Value = txtlabourunit.Text;
        cmd.Parameters.Add("@ServiceTax", SqlDbType.VarChar, 40).Value = txtservicetax.Text;
        cmd.Parameters.Add("@Chanda", SqlDbType.VarChar, 40).Value = txtchanda.Text;
        cmd.Parameters.Add("@Cost", SqlDbType.VarChar, 40).Value = txtcost.Text;
        cmd.Parameters.Add("@Other", SqlDbType.VarChar, 40).Value = txtother.Text;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();
        cmd.Parameters.Add("@EntryDate", SqlDbType.VarChar, 40).Value = DateTime.Now;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = "1";

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }
    protected void btnsave_Click(object sender, EventArgs e)
    {


        if (btnsave.Text == "Save")
        {
            FxSave();
        }
        else if (btnsave.Text == "Update")
        {
            FxUpdate();

        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
       
        btnsave.Text = "Update";
        btndelete.Enabled = true;

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        FxClear();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        FxDelete();
    }
    protected void drpplanning_SelectedIndexChanged(object sender, EventArgs e)
    {
        FxPlanningDetail(drpplanning.SelectedValue);

        Class1 a = new Class1();
        a.loadgrid(GridView1, @"select id as '#',Firm as 'जिम्मा लिने संस्था',Labour as 'श्रम शक्ति संख्या',ServiceTax as 'सेवा शुल्कबाट',Chanda as 'दस्तुर चन्दाबाट ',
                                Cost as 'लागत सहभागिता',Other as 'अन्य बचत' from PlanningMaintance where PlanningID='" + drpplanning.SelectedValue + "'");

    }

    private void FxPlanningDetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning where Id= " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    txtplace.Text = myreader["Place"].ToString();
                    txtward.Text = myreader["WardNo"].ToString();
                    txtfiscalyear.Text = myreader["FiscalYear"].ToString();
                    txtremarks.Text = myreader["Remarks"].ToString();



                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }



    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;
        Session["ID"] = row.Cells[1].Text;


        txtfirmname.Text = row.Cells[1].Text;
        txtlabourunit.Text = row.Cells[2].Text;
        txtservicetax.Text = row.Cells[3].Text;
        txtchanda.Text = row.Cells[4].Text;
        txtcost.Text = row.Cells[5].Text;
        txtother.Text = row.Cells[6].Text;

        btnsave.Text = "Update";
        btndelete.Enabled = true;

        
    }
}