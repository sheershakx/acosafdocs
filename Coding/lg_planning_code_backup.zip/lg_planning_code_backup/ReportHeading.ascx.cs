﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

public partial class ReportHeading : System.Web.UI.UserControl
{

    private void FxGetCompanyName()
    {

        // sql1 = "";



        string sql = @"select * from ControlTable";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    lblheading1.Text =myreader["Head1"].ToString();
                  //  lblheading2.Text = myreader["Head2"].ToString();
                    lblheading3.Text = myreader["Address"].ToString();
                    lblheading.Text = myreader["OfficeName"].ToString();

                   // lblcompanyname.Text = myreader["CompanyName"].ToString();
                   // Session["CompanyName"] = myreader["CompanyName"].ToString();
                    // string logo = myreader["LogoPath"].ToString();
                    // lbldate.Text = System.DateTime.Now.ToString();


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }


    protected void Page_Load(object sender, EventArgs e)
    {
        FxGetCompanyName();
    }
}