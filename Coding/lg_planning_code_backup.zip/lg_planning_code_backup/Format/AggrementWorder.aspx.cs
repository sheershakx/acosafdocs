﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class Format_AggrementWorder : System.Web.UI.Page
{
    public static string id = "";
    public static string date = "";
    public static string status = "";

    private void FxGetUpabhokta(string id)
    {

        // sql1 = "";



        string sql = @"select * from dbo.U_SamitiDetail where PlanningId=" + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {


                    lblusamiti.Text = "श्री " +  myreader["SamitiName"].ToString() + ", " + myreader["Place"].ToString();
                    //lblusamitiplace.Text = myreader["Place"].ToString();
                    //lblusamitiname.Text = myreader["JoinMember"].ToString();





                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();



                }

                Class1 a = new Class1();
               

            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }
    private void FxGetTippaniDetailView(string id)
    {

        // sql1 = "";



        string sql = @"exec s_RptTippaniView " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    // lblamount2.Text = myreader["CompanyName"].ToString();
                    // lblcost.Text = myreader["CompanyName"].ToString();
                    lblenddate.Text = myreader["EndDate"].ToString();
                    lblhead.Text = myreader["HName"].ToString();
                    //  lbllevel.Text = myreader["CompanyName"].ToString();
                    lblplanningname.Text = myreader["PName"].ToString();
                    lblpplace.Text = myreader["Place"].ToString();
                    lblstartdate.Text = myreader["StartDate"].ToString();
                    lblsubhead.Text = myreader["NName"].ToString();
                    lblsubject.Text = myreader["BName"].ToString();
                    lbluanme.Text = myreader["SamitiName"].ToString();
                    lblcost.Text = myreader["Total"].ToString();
                    lbllevel.Text = myreader["lname"].ToString();
                    lblamount2.Text = myreader["WorkOrderAmount"].ToString();
                    //lblContigency.Text = myreader["ContigencyAmount"].ToString();
                    //lblCostEstimate.Text = myreader["Total"].ToString();

                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();



                }

                Class1 a = new Class1();
               
                a.loadgrid2(GridView2, @"select P.Name as 'रकम व्यह्रोर्ने स्रोतको नाम',Amount as 'रकम'from CostEstimationSource C
                                    inner join CostSource P
                                    on C.Source=P.Id where C.PlanningID='" + id + "'");
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

    private void FxCreate(string id, string date)
    {
        string num = "";
        if (status == "C")
        {
            num = "8";
        }
        else if (status == "A")
        {
            num = "9";
        }

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_PlanningLog", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = id;
        cmd.Parameters.Add("@step", SqlDbType.VarChar, 40).Value = num;
        cmd.Parameters.Add("@createdate", SqlDbType.VarChar, 40).Value = date;

        cmd.Parameters.Add("@status", SqlDbType.VarChar, 40).Value = status;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

            // string contractID = Convert.ToString(cmd.Parameters["@IdentitY"].Value);
            // string contractIDd = Convert.ToString(cmd.Parameters["@result"].Value);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
        }




    }


    private string Fxgetdate(string id)
    {

        // sql1 = "";

        string date1 = "";

        string sql = @"exec s_FxGetDateAggrementWorder " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    date1 = myreader["CreateDate"].ToString();


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

        return date1;

    }



    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Class1 a = new Class1();
            //a.loadcombo(drpsubject, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from Plansubject", "Name", "ID");
           
            lbldetail.Text = "यस कार्यालयको स्वीकृत बार्षिक कार्यक्रम अनुसार तपसिलको विवरण उल्लेख बमोजिमको योजना संचालन गर्न यस नगरपालिकासंग भएको सम्झौता अनुसार योजनाको काम शुरु गर्न यो कार्यादेश दिइएको छ | तोकिएको समयमा काम सम्पन्न गरि योजनाको प्राबिधिक मुल्यांकन गराई उक्त योजनामा भएको यथार्थ खर्चको विवरण उपभोक्ता समिति तथा अनुगमन समितिको बैठकबाट अनुमोदन गराई खर्चको बिल भर्पाइ र योजनाको फोटो सहित यस कार्यालयमा पेश गरि भुक्तानी लिनुहुन जानकारी गराइन्छ |";
            id = Request.QueryString["id"].ToString();
            date = Request.QueryString["date"].ToString();
            status = Request.QueryString["S"].ToString();
            FxGetTippaniDetailView(id);
            FxGetUpabhokta(id);

            if (status == "V")
            {
                date = Fxgetdate(id);
                if (date == "")
                {
                    date = "No Work order";
                }

            }


            if (status == "A")
            {

                btnapproved.Visible = true;
            }
            Label21.Text = date;//Session["TodayDate"].ToString();
            this.Button2.Attributes.Add("onclick", "javascript:printDiv('printme')");
            FxCreate(id, date);
        }
    }
}