﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

public partial class Format_AdvanceTippani : System.Web.UI.Page
{

    private string FxGetplanid(string id)
    {

        // sql1 = "";
        string name = "";


        string sql = @"select PlanningId from BillPayment where Id=" + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    // lblamount2.Text = myreader["CompanyName"].ToString();
                    // lblcost.Text = myreader["CompanyName"].ToString();
                    //lblenddate.Text = myreader["EndDate"].ToString();
                    //lblhead.Text = myreader["EName"].ToString();
                    ////  lbllevel.Text = myreader["CompanyName"].ToString();
                    //lblplanningname.Text = myreader["PName"].ToString();
                    //lblpplace.Text = myreader["Place"].ToString();
                    //lblstartdate.Text = myreader["StartDate"].ToString();
                    //lblsubhead.Text = myreader["HName"].ToString();
                    //lblsubject.Text = myreader["BName"].ToString();
                    //lbluanme.Text = myreader["SamitiName"].ToString();
                    //lblcost.Text = myreader["BudgetAmount"].ToString();
                    //lbllevel.Text = myreader["lname"].ToString();
                    //lblamount2.Text = myreader["WorkOrderAmount"].ToString();

                    // lblbillamount.Text = myreader["BillAmount"].ToString();
                    //   lblpaymentamount.Text = myreader["PaymentAmount"].ToString();

                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();
                    //  Label22.Text = "कार्यप्रगतिका आधारमा प्राविधिकबाट नापजाँच गरी प्राविधिक मूल्याङ्कनका आधारमा रकम भुक्तानी दिने निर्णय भए अनुसार हाल प्राविधिकबाट मूल्याङ्कन भई सोको विल, भर्पाइ, नापी किताब, उपभोक्ता समिति निर्णय, समेत प्राप्त हुन आएकाले " + myreader["PaymentAmount"].ToString() + " रनिङ्ग विल वापत नियमानुसार कट्टा गर्नु पर्ने रकम कट्टा गरी तपसिल अनुसार रनिङ्ग विल भुक्तानी हुन निर्णयार्थ पेश गरेको छु ।";

                    name = myreader["PlanningId"].ToString();
                }


            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }
        return name;
    }


    private void FxGetTippaniDetailView(string id)
    {

        // sql1 = "";



        string sql = @"exec s_RptTippaniView " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    // lblamount2.Text = myreader["CompanyName"].ToString();
                    // lblcost.Text = myreader["CompanyName"].ToString();
                    lblenddate.Text = myreader["EndDate"].ToString();
                    lblhead.Text = myreader["HName"].ToString();
                    //  lbllevel.Text = myreader["CompanyName"].ToString();
                    lblplanningname.Text = myreader["PName"].ToString();
                    lblpplace.Text = myreader["Place"].ToString();
                    lblstartdate.Text = myreader["StartDate"].ToString();
                    lblsubhead.Text = myreader["NName"].ToString();
                    lblsubject.Text = myreader["BName"].ToString();
                    lbluanme.Text = myreader["SamitiName"].ToString();
                    lblcost.Text = myreader["Total"].ToString();
                    lbllevel.Text = myreader["lname"].ToString();
                    lblamount2.Text = myreader["WorkOrderAmount"].ToString();
                  //  lblstartdate.Text = myreader["StartDate"].ToString();

                    Label10.Text = @"चालु आ.व.को स्वीकृत कार्यक्रम अन्तर्गत विनियोजित बजेट को प्राविधिक स्टीमेट बमोजिम मिति " + myreader["StartDate"].ToString()+" मा उपभोक्तासँग सम्झौता भएकोमा उक्त उ.स.ले निर्माण कार्य शुरु गर्न कारण देखाई उपभोक्ता समितिबाट पेश्की माँग हुन आएको देखिन्छ ।";
                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();



                }

              //  Class1 a = new Class1();
//                a.loadgrid2(GridView2, @"select P.Name as Source,Amount from CostEstimationSource C
//                                    inner join CostSource P
//                                    on C.Source=P.Id");
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

    private void FxGetpeskideail(string id)
    {

        // sql1 = "";



        string sql = @"select SUM(paymentAmount) as Amount from BillPayment where id=" + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    // lblamount2.Text = myreader["CompanyName"].ToString();
                    // lblcost.Text = myreader["CompanyName"].ToString();
                    lblpeski.Text = myreader["Amount"].ToString();


                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();



                }

                //  Class1 a = new Class1();
                //                a.loadgrid2(GridView2, @"select P.Name as Source,Amount from CostEstimationSource C
                //                                    inner join CostSource P
                //                                    on C.Source=P.Id");
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string id = Request.QueryString["id"].ToString();
        FxGetTippaniDetailView(FxGetplanid(id));
        FxGetpeskideail(id);
        Label21.Text = Session["TodayDate"].ToString();
        this.Button1.Attributes.Add("onclick", "javascript:printDiv('printme')");
    }
}