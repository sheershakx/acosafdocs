﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

public partial class Format_Suchana : System.Web.UI.Page
{


    private void FxGetTippaniDetailView(string id)
    {

        // sql1 = "";



        string sql = @"select A.OtherDetail,P.Name,A.AggrementAmountt,A.BankName,A.AccountNo,A.JamanatAmount,A.ExpiryDate from Planning P
                                                    inner join PlanningOtherActivity A
                                                    on P.Id=A.PlanningId where A.PlanningId = " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    lbldetail.Text = @"उपयुक्त सम्बन्धमा यस कार्यालयको ठेक्का नम्बर " + myreader["OtherDetail"].ToString() + "को " + myreader["OtherDetail"].ToString() + " का लागि तय फर्म/ कम्पनिले पेस गरेको सिलबन्दी बोलपत्र स्वीकृत भएकोले आजको मितिले १५ दिन भित्र कबोल रकम रु " + myreader["AggrementAmountt"].ToString() + " (मु अ कर समेत) को ५%  जमानत बापतको रकम र सार्बजानिक खरिद ऐन २०६३(सम्सोधन सहित)को दफा १३ को उपदफा २(ढ) १ मा व्यवस्था भए बमोजिम थप रकम समेत एस कार्यालयको नाममा रहेको " + myreader["BankName"].ToString() +   " " + myreader["AccountNo"].ToString() + " धरौटी खातामा नगद जम्मा गरेको सक्कलै भौचर वा यस कार्यालयको नाममा जारि गरेको मिति valid date सम्म म्याद रहेको परफरमेन्स बंड लिई सम्झौताका लागि उपस्थित हुन जानकारी गराइन्छ | अन्यथा नियमानुसार जाने व्योहोरा जानकारी गराइन्छ | ";
                    lblcobolamount.Text = myreader["AggrementAmountt"].ToString();
                    lblexpirydate.Text = myreader["ExpiryDate"].ToString();
                    lbljamanatamount.Text = myreader["JamanatAmount"].ToString();
                    // lblamount2.Text = myreader["OtherDetail"].ToString();
                    // lblcost.Text = myreader["CompanyName"].ToString();
                  //  lblenddate.Text = myreader["EndDate"].ToString();
                  //  lblhead.Text = myreader["EName"].ToString();
                    //  lbllevel.Text = myreader["CompanyName"].ToString();
                  //  lblplanningname.Text = myreader["PName"].ToString();
                  //  lblpplace.Text = myreader["Place"].ToString();
                  //  lblstartdate.Text = myreader["StartDate"].ToString();
                  //  lblsubhead.Text = myreader["HName"].ToString();
                  //  lblsubject.Text = myreader["BName"].ToString();
                  //  lbluanme.Text = myreader["SamitiName"].ToString();
                   // lblcost.Text = myreader["BudgetAmount"].ToString();


                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();



                }

              
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }



    protected void Page_Load(object sender, EventArgs e)
    {
        string id = Request.QueryString["Id"].ToString();
        FxGetTippaniDetailView(id);
        this.Button2.Attributes.Add("onclick", "javascript:printDiv('printme')");
    }
}