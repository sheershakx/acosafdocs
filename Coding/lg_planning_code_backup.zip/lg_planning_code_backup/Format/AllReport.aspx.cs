﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using Inventory;

public partial class Format_AllReport : System.Web.UI.Page
{
    private void FxGetTippaniDetailView(string id)
    {

        // sql1 = "";



        string sql = @"exec s_RptTippaniView " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    // lblamount2.Text = myreader["CompanyName"].ToString();
                    // lblcost.Text = myreader["CompanyName"].ToString();
                    lblenddate.Text = myreader["EndDate"].ToString();
                    lblhead.Text = myreader["HName"].ToString();
                    //  lbllevel.Text = myreader["CompanyName"].ToString();
                    lblplanningname.Text = myreader["PName"].ToString();
                    lblpplace.Text = myreader["Place"].ToString();
                    lblstartdate.Text = myreader["StartDate"].ToString();
                    lblsubhead.Text = myreader["NName"].ToString();
                    lblsubject.Text = myreader["BName"].ToString();
                    lbluanme.Text = myreader["SamitiName"].ToString();
                    lblcost.Text = myreader["Total"].ToString();
                    lbllevel.Text = myreader["lname"].ToString();
                    lblamount2.Text = myreader["WorkOrderAmount"].ToString();

                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();



                }

                Class1 a = new Class1();
                a.loadgrid2(GridView2, @"select P.Name as 'रकम व्यह्रोर्ने स्रोत',Amount as 'रकम' from CostEstimationSource C
                                    inner join CostSource P
                                    on C.Source=P.Id where C.PlanningId=" + id + " ");
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }


    private void FxGetPlanningDetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from dbo.U_SamitiOtherDetail where PlanningId=" + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {




                    lbltargettotal.Text = myreader["TargetTotal"].ToString();
                    lbldalit.Text = myreader["TargetDalit"].ToString();
                    lblfemale.Text = myreader["TargetFemale"].ToString();
                    lblmadhesi.Text = myreader["TargetMadhesi"].ToString();
                    lblother.Text = myreader["TargetOther"].ToString();
                    lblhousehold.Text = myreader["TargetHouse"].ToString();
                    lbljanajati.Text = myreader["TargetJanaJati"].ToString();
                    lblmale.Text = myreader["TargetMale"].ToString();

                    // lblamount2.Text = myreader["CompanyName"].ToString();
                    // lblcost.Text = myreader["CompanyName"].ToString();
                    lblenddate.Text = myreader["EndDate"].ToString();



                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();



                }

               
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }


    private void FxGetUpabhokta(string id)
    {

        // sql1 = "";



        string sql = @"select * from dbo.U_SamitiDetail where PlanningId=" + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {


                    c.Text = myreader["JoinMember"].ToString();
                    lblusamitiplace.Text = myreader["Place"].ToString();
                    lblusamitiname.Text = myreader["SamitiName"].ToString(); 





                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();



                }

                Class1 a = new Class1();
                a.loadgrid2(GridView3, @"select P.Name as 'नाम',T.Name as 'पद',G.Name as 'लिङ्ग',Place as 'ठेगाना',ContactNo as 'सम्पर्क नं' from dbo.U_Samiti_People P
                                        inner join SamitiPostType T
                                        on P.Post=T.Id
                                        inner join GenderType G
                                        on P.Gender=G.ID where P.PlanningId=" + id + " ");

                a.loadgrid2(GridView4, @"select P.Name as 'पद',T.Name as 'नाम',Place as 'ठेगाना',ContactNo as 'सम्पर्क नं'	 from dbo.U_Samiti_Anugaman P
                                        inner join SamitiPostType T
                                        on P.Post=T.Id where P.PlannigId=" + id + " ");

                a.loadgrid2(GridView5, @"select SN as 'सि.नं.',Details as 'सम्झौता सर्तहरु' from dbo.AggrementCondition where Status=1");

               
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string id = Request.QueryString["id"].ToString();
        FxGetTippaniDetailView(id);
        FxGetUpabhokta(id);
        FxGetPlanningDetail(id);
        //Label21.Text = Session["TodayDate"].ToString();
        Label33.Text = Session["TodayDate"].ToString();
        this.Button2.Attributes.Add("onclick", "javascript:printDiv('printme')");
    }
}