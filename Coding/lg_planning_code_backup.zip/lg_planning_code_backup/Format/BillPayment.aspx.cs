﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using Inventory;

public partial class Format_BillPayment : System.Web.UI.Page
{
    public static string firstkista, secondkista, nokista,kistatype,paymenttype;
    public static double firstd, secondd, finald, workorderd, contingencyd, nod;




    private void FxGetpeskideail(string id)
    {

        // sql1 = "";



        string sql = @"select PaymentAmount as Amount,P.Name as PName from BillPayment  B
                        inner join PaymentTypeSetup P
                        on B.PaymentType=P.Id where B.Id=" + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    // lblamount2.Text = myreader["CompanyName"].ToString();
                    // lblcost.Text = myreader["CompanyName"].ToString();
                    lblpeski.Text = myreader["Amount"].ToString();
                    Label22.Text = "कार्यप्रगतिका आधारमा प्राविधिकबाट नापजाँच गरी प्राविधिक मूल्याङ्कनका आधारमा रकम भुक्तानी दिने निर्णय भए अनुसार हाल प्राविधिकबाट मूल्याङ्कन भई सोको विल, भर्पाइ, नापी किताब, उपभोक्ता समिति निर्णय, समेत प्राप्त हुन आएकाले विल वापत नियमानुसार कट्टा गर्नु पर्ने रकम कट्टा गरी तपसिल अनुसार " + myreader["PName"].ToString() + " विल भुक्तानी हुन निर्णयार्थ पेश गरेको छु ।";
                    Label33.Text = "प्रस्तुत योजनाको अनुसार सम्झौता भइ योजना संचालन भएकोमा बराह्क्षेत्र नगरपालिकाको कार्यालय चक्रघट्टीबाट निम्न अनुसारको प्रथम/दोस्रो/अन्तिम मुल्यांकन संलग्न पेश गरेको छु | हाल सम्मको भुक्तानी विवरण निम्नानुसार रहेको छ |";
                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();



                }

                //  Class1 a = new Class1();
                //                a.loadgrid2(GridView2, @"select P.Name as Source,Amount from CostEstimationSource C
                //                                    inner join CostSource P
                //                                    on C.Source=P.Id");
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }


    private void FxGetTippaniDetailView(string id)
    {

        // sql1 = "";



        string sql = @"exec s_RptTippaniView " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    // lblamount2.Text = myreader["CompanyName"].ToString();
                    // lblcost.Text = myreader["CompanyName"].ToString();
                    lblenddate.Text = myreader["EndDate"].ToString();
                    lblhead.Text = myreader["HName"].ToString();
                    //  lbllevel.Text = myreader["CompanyName"].ToString();
                    lblplanningname.Text = myreader["PName"].ToString();
                    lblpplace.Text = myreader["Place"].ToString();
                    lblstartdate.Text = myreader["StartDate"].ToString();
                    lblsubhead.Text = myreader["NName"].ToString();
                    lblsubject.Text = myreader["BName"].ToString();
                    lbluanme.Text = myreader["SamitiName"].ToString();
                    lblcost.Text = myreader["Total"].ToString();
                    lbllevel.Text = myreader["lname"].ToString();
                    lblamount2.Text = myreader["WorkOrderAmount"].ToString();

                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();

                    Label10.Text = "चालु आ.व.को स्वीकृत योजना ‍‍‍‍‍‍‍" + myreader["PName"].ToString() + " मिति " + myreader["StartDate"].ToString() + " मा सम्झौता भएको देखिन्छ ।";

                }

                //                Class1 a = new Class1();
                //                a.loadgrid2(GridView2, @"select P.Name as 'सोत',Amount as 'रकम' from CostEstimationSource C
                //                                    inner join CostSource P
                //                                    on C.Source=P.Id");
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

    // kina malai dherai mauka ma anxiety le xunxa ra ma anxious hunxu; attinxu, darauxu ra mutu ko dhadkan ekdamai tej sanga le dhankina suru hunxa?? ; kina ma mutu ko chaal badera nai behos hunxu jasto lagxa malai , khai mata esko uttar kai khoji ma xu ; lamo lamo swas ferda ni kei niko hunna, physical exercise haru garda ni kei effective dekhinna, ma ekdamai kind xu ra aru lai kada sabda ya uniharuko galti dekhauna man lagdaina chahe tyo jaruru nai 

    private string FxGetplanid(string id)
    {

        // sql1 = "";
        string name = "";


        string sql = @"select PlanningId from BillPayment where Id=" + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    // lblamount2.Text = myreader["CompanyName"].ToString();
                    // lblcost.Text = myreader["CompanyName"].ToString();
                    //lblenddate.Text = myreader["EndDate"].ToString();
                    //lblhead.Text = myreader["EName"].ToString();
                    ////  lbllevel.Text = myreader["CompanyName"].ToString();
                    //lblplanningname.Text = myreader["PName"].ToString();
                    //lblpplace.Text = myreader["Place"].ToString();
                    //lblstartdate.Text = myreader["StartDate"].ToString();
                    //lblsubhead.Text = myreader["HName"].ToString();
                    //lblsubject.Text = myreader["BName"].ToString();
                    //lbluanme.Text = myreader["SamitiName"].ToString();
                    //lblcost.Text = myreader["BudgetAmount"].ToString();
                    //lbllevel.Text = myreader["lname"].ToString();
                    //lblamount2.Text = myreader["WorkOrderAmount"].ToString();

                    // lblbillamount.Text = myreader["BillAmount"].ToString();
                    //   lblpaymentamount.Text = myreader["PaymentAmount"].ToString();

                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();
                    //  Label22.Text = "कार्यप्रगतिका आधारमा प्राविधिकबाट नापजाँच गरी प्राविधिक मूल्याङ्कनका आधारमा रकम भुक्तानी दिने निर्णय भए अनुसार हाल प्राविधिकबाट मूल्याङ्कन भई सोको विल, भर्पाइ, नापी किताब, उपभोक्ता समिति निर्णय, समेत प्राप्त हुन आएकाले " + myreader["PaymentAmount"].ToString() + " रनिङ्ग विल वापत नियमानुसार कट्टा गर्नु पर्ने रकम कट्टा गरी तपसिल अनुसार रनिङ्ग विल भुक्तानी हुन निर्णयार्थ पेश गरेको छु ।";

                    name = myreader["PlanningId"].ToString();
                   
                }


            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }
        return name;
    }


    private void FxGetOtherDetail(string id)
    {

        string sql = @"select TechnicalAmount as BillAmount,SheduleType as SheduleType,PaymentType as PaymentType,PaymentAmount as PaymentAmount,DeductionAmount as deductionamount,
                        PeopleInvolveGross, PeopleInvolvePer, PeopleInvolveNet, PanBillGross, PanBillPer, PanBillNet, VatBillGross, VatBillPer, VatBillNet, 
                      TransportGross, TransportPer, TransportNet, TechnicalSuggestion
                     from BillPayment where Id= " + id + "";
        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {
            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    lblbillamount.Text = myreader["BillAmount"].ToString();
                    lblpaymentamount.Text = myreader["PaymentAmount"].ToString();
                    Label23.Text = myreader["deductionamount"].ToString();
                    kistatype = myreader["SheduleType"].ToString();
                    paymenttype = myreader["PaymentType"].ToString();
                  


                    //new commented
                    //lblwage.Text = myreader["PeopleInvolveGross"].ToString();
                    //lblwagetax.Text = myreader["PeopleInvolveNet"].ToString();
                    //lblpan.Text = myreader["PanBillGross"].ToString();
                    //lblpantax.Text = myreader["PanBillNet"].ToString();
                    //lblVat.Text = myreader["VatBillGross"].ToString();
                    //lblVattax.Text = myreader["VatBillNet"].ToString();
                    //lbltransport.Text = myreader["TransportGross"].ToString();
                    //lbltansportTax.Text = myreader["TransportNet"].ToString();
                    lbltechnicalsuggession.Text = myreader["TechnicalSuggestion"].ToString();
                }

                //                Class1 a = new Class1();
                //                a.loadgrid2(GridView2, @"select P.Name as Source,Amount from CostEstimationSource C
                //                                    inner join CostSource P
                //                                    on C.Source=P.Id");
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

    private void FxGetPaymentScheduleDetail_next(string id)     // antim kista get data
    {

        string sql = @"select SUM(PaymentAmount) as nokista from BillPayment where PlanningId= " + id + " and SheduleType= '1'";



        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;


        SqlCommand SelectCommand = new SqlCommand(sql, myconn);


        try
        {
            myconn.Open();

            myreader = SelectCommand.ExecuteReader();

            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    nokista = myreader["nokista"].ToString();

                    nod = Convert.ToDouble(nokista);
                    lbl_kista3.Text = nod.ToString();
                  



                }

                //                Class1 a = new Class1();
                //                a.loadgrid2(GridView2, @"select P.Name as Source,Amount from CostEstimationSource C
                //                                    inner join CostSource P
                //                                    on C.Source=P.Id");
            }
            else
            {

                // P_No.Focus();
            }


        }
        catch (Exception ex)
        {

        }


        finally
        {
            myconn.Close();
        }

    }
    private void FxGetPaymentScheduleDetail(string id)  // geting first kista data
    {

        string sql = @"select SUM(PaymentAmount) as firstkista from BillPayment where PlanningId= " + id + " and SheduleType= '2'";



        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;


        SqlCommand SelectCommand = new SqlCommand(sql, myconn);


        try
        {
            myconn.Open();

            myreader = SelectCommand.ExecuteReader();

            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    firstkista = myreader["firstkista"].ToString();

                    firstd = Convert.ToDouble(firstkista);
                    lbl_kista1.Text = firstd.ToString();



                }

                //                Class1 a = new Class1();
                //                a.loadgrid2(GridView2, @"select P.Name as Source,Amount from CostEstimationSource C
                //                                    inner join CostSource P
                //                                    on C.Source=P.Id");
            }
            else
            {

                // P_No.Focus();
            }


        }
        catch (Exception ex)
        {

        }


        finally
        {
            myconn.Close();
        }

    }
    private void FxgetSecondkista(string id)        //getting second kista data
    {


        string sql = @"select SUM(PaymentAmount) as secondkista from BillPayment where PlanningId= " + id + " and SheduleType= '3' ";


        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;


        SqlCommand SelectCommand = new SqlCommand(sql, myconn);


        try
        {
            myconn.Open();

            myreader = SelectCommand.ExecuteReader();

            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {


                    secondkista = myreader["secondkista"].ToString();
                    secondd = Convert.ToDouble(secondkista);

                    lbl_kista2.Text = secondd.ToString();





                }

                //                Class1 a = new Class1();
                //                a.loadgrid2(GridView2, @"select P.Name as Source,Amount from CostEstimationSource C
                //                                    inner join CostSource P
                //                                    on C.Source=P.Id");
            }
            else
            {

                // P_No.Focus();
            }


        }
        catch (Exception ex)
        {

        }


        finally
        {
            myconn.Close();
        }

    }
    private void FxSheershak(string id)  // fetchs upobhokta samiti rs aand contengincy and otthers from dbo.CostEstimation
    {

        string sql = @"select US as upobhokta_amount,ContigencyAmount as contigency,ContigencyPercent as contigencypercent,WorkOrderAmount as workorder,CostTotal as sumtotal from CostEstimation where PlanningId = " + id + "  ";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;


        SqlCommand SelectCommand = new SqlCommand(sql, myconn);


        try
        {
            myconn.Open();

            myreader = SelectCommand.ExecuteReader();

            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returning false 
                {
                    finald = firstd + secondd + nod;
                    lbl_kistatotal.Text = finald.ToString();
                    workorderd = Convert.ToDouble(myreader["workorder"].ToString());
                    contingencyd = Convert.ToDouble(myreader["contigency"].ToString());
                    double contigencypercent = Convert.ToDouble(myreader["contigencypercent"].ToString());
                  
                    double thiscontigency = (contigencypercent / 100) * finald;

                    //  Double giveamount = (finaldd - workorderd - contingencyd);
                    LabelPublicRs.Text = myreader["upobhokta_amount"].ToString();
                    if (kistatype == "2") {

                        lbl_kista2.Text = "0";
                        lbl_kista3.Text = "0";
                        lbl_kistatotal.Text = lbl_kista1.Text;
                    
                    }
      
                   if (paymenttype=="2" && kistatype=="2")  //i.e pratham kista
                    {
                       
                        Label55.Text = "रु  " + myreader["workorder"].ToString() + "/-    मा हालसम्म रु   " + "0" + "/-    लिएको | साथै कन्टिजेंसी वापतको रकम रु   " + "0" + "/-    काटिएको हुदा न. पा. बाट हाल रु   " + lbl_kista1.Text + "/-    मात्र   उपभोक्ता समितिको खातामा निकासा हुनको लागि निर्णयार्थ पेश गर्दछु |";
                    }


                   else if ( paymenttype=="2" && kistatype=="3")  // dosro kista, payment 2 means running kista
                    {
                        lbl_kista3.Text = "0";
                        if (contigencypercent != null && !contigencypercent.Equals(0))
                        {
                            Label55.Text = "रु  " + myreader["workorder"].ToString() + "/-    मा हालसम्म रु   " + lbl_kista1.Text + "/-    लिएको | साथै कन्टिजेंसी वापतको रकम रु   " + thiscontigency + "/-    काटिएको हुदा न. पा. बाट हाल रु   " + (Convert.ToDouble(lbl_kista2.Text.ToString())-thiscontigency) + "/-    मात्र   उपभोक्ता समितिको खातामा निकासा हुनको लागि निर्णयार्थ पेश गर्दछु |";
                        }
                        else if (contigencypercent != null && contigencypercent.Equals(0))
                        {
                            Label55.Text = "रु  " + myreader["workorder"].ToString() + "/-    मा हालसम्म रु   " + lbl_kista1.Text + "/-    लिएको | साथै कन्टिजेंसी वापतको रकम रु   " + contingencyd + "/-    काटिएको हुदा न. पा. बाट हाल रु   " + (Convert.ToDouble(lbl_kista2.Text.ToString()) - contingencyd) + "/-    मात्र   उपभोक्ता समितिको खातामा निकासा हुनको लागि निर्णयार्थ पेश गर्दछु |";
                        }
                    }
                   else if (paymenttype=="3")  //payment 3 means antim kista
                    {
                        if (contigencypercent != null && !contigencypercent.Equals(0))
                        {
                            Label55.Text = "रु  " + myreader["workorder"].ToString() + "/-    मा हालसम्म रु   " + (Convert.ToDouble(lbl_kista1.Text.ToString()) + Convert.ToDouble(lbl_kista2.Text.ToString())) + "/-    लिएको | साथै कन्टिजेंसी वापतको रकम रु   " + thiscontigency + "/-    काटिएको हुदा न. पा. बाट हाल रु   " + (nod - thiscontigency) + "/-    मात्र   उपभोक्ता समितिको खातामा निकासा हुनको लागि निर्णयार्थ पेश गर्दछु |";
                          
                       //  old  // Label55.Text = "रु  " + myreader["workorder"].ToString() + "/-    मा हालसम्म रु   " + (Convert.ToDouble(lbl_kista1.Text.ToString())+Convert.ToDouble(lbl_kista2.Text.ToString())) + "/-    लिएको | साथै कन्टिजेंसी वापतको रकम रु   " + thiscontigency + "/-    काटिएको हुदा न. पा. बाट हाल रु   " + ( Convert.ToDouble(myreader["workorder"].ToString())-Convert.ToDouble(lbl_kista1.Text.ToString())+ Convert.ToDouble(lbl_kista2.Text.ToString())- thiscontigency) + "/-    मात्र   उपभोक्ता समितिको खातामा निकासा हुनको लागि निर्णयार्थ पेश गर्दछु |";
                        }
                        else if (contigencypercent != null && contigencypercent.Equals(0))
                        {
                            Label55.Text = "रु  " + myreader["workorder"].ToString() + "/-    मा हालसम्म रु   " + (Convert.ToDouble(lbl_kista1.Text.ToString()) + Convert.ToDouble(lbl_kista2.Text.ToString())) + "/-    लिएको | साथै कन्टिजेंसी वापतको रकम रु   " + contingencyd + "/-    काटिएको हुदा न. पा. बाट हाल रु   " + (nod- contingencyd) + "/-    मात्र   उपभोक्ता समितिको खातामा निकासा हुनको लागि निर्णयार्थ पेश गर्दछु |";
                           
                        // old  //  Label55.Text = "रु  " + myreader["workorder"].ToString() + "/-    मा हालसम्म रु   " + (Convert.ToDouble(lbl_kista1.Text.ToString())+Convert.ToDouble(lbl_kista2.Text.ToString())) + "/-    लिएको | साथै कन्टिजेंसी वापतको रकम रु   " + contingencyd + "/-    काटिएको हुदा न. पा. बाट हाल रु   " + (Convert.ToDouble(myreader["workorder"].ToString())-Convert.ToDouble(lbl_kista1.Text.ToString()) + Convert.ToDouble(lbl_kista2.Text.ToString())- contingencyd) + "/-    मात्र   उपभोक्ता समितिको खातामा निकासा हुनको लागि निर्णयार्थ पेश गर्दछु |";
                        }

                      
                    }

                }

                //                Class1 a = new Class1();
                //                a.loadgrid2(GridView2, @"select P.Name as Source,Amount from CostEstimationSource C
                //                                    inner join CostSource P
                //                                    on C.Source=P.Id");
            }
            else
            {

                // P_No.Focus();
            }


        }
        catch (Exception ex)
        {

        }


        finally
        {
            myconn.Close();
        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {

        //clearing the label each time page loads new
        Label55.Text = "";
        lbl_kista1.Text = "0";
        lbl_kistatotal.Text = "0";
        lbl_kista2.Text = "0";
        lbl_kista3.Text = "0";

        firstkista = "0";
        secondkista = "0";
        firstd = 0;
        secondd = 0;
        finald = 0;
        workorderd = 0;
        contingencyd = 0;


        string id = Request.QueryString["id"].ToString();

        FxGetTippaniDetailView(FxGetplanid(id));
        FxGetpeskideail(id);
        FxGetOtherDetail(id);
        //added by sheershak

        FxGetPaymentScheduleDetail_next(FxGetplanid(id));
        FxGetPaymentScheduleDetail(FxGetplanid(id));
        FxgetSecondkista(FxGetplanid(id));
        FxSheershak(FxGetplanid(id));


        //addded closed




        this.Button2.Attributes.Add("onclick", "javascript:printDiv('printme')");
        Label21.Text = Session["TodayDate"].ToString();
    }
}