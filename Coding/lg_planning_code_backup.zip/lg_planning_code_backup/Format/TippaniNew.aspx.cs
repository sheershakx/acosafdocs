﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using Inventory;
using System.Data;

public partial class Format_TippaniNew : System.Web.UI.Page
{
    public static string id = "";
    public static string date = "";
    public static string status = "";

    private void FxGetTippaniDetailView(string id)
    {

        // sql1 = "";



        string sql = @"exec s_RptTippaniView " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    // lblamount2.Text = myreader["CompanyName"].ToString();
                    // lblcost.Text = myreader["CompanyName"].ToString();
                    lblenddate.Text = myreader["EndDate"].ToString();
                    lblhead.Text = myreader["HName"].ToString();
                    //  lbllevel.Text = myreader["CompanyName"].ToString();
                    lblplanningname.Text = myreader["PName"].ToString();
                    lblpplace.Text = myreader["Place"].ToString();
                    lblstartdate.Text = myreader["StartDate"].ToString();
                    lblsubhead.Text = myreader["NName"].ToString();
                    lblsubject.Text = myreader["BName"].ToString();
                    lbluanme.Text = myreader["SamitiName"].ToString();
                    lblcost.Text = myreader["BudgetAmount"].ToString();
                    lbllevel.Text = myreader["lname"].ToString();
                    lblamount2.Text = myreader["WorkOrderAmount"].ToString();
                    lblContigency.Text = myreader["ContigencyAmount"].ToString();
                    lblCostEstimate.Text = myreader["Total"].ToString();
                    
                    //  lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();



                }

                Class1 a = new Class1();
                a.loadgrid2(GridView2, @"select P.Name as 'रकम व्यह्रोर्ने स्रोतको नाम',Amount as 'रकम'from CostEstimationSource C
                                    inner join CostSource P
                                    on C.Source=P.Id where C.PlanningID='" + id + "'");
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }




    private string Fxgetdate(string id)
    {

        // sql1 = "";

        string date1 = "";

        string sql = @"exec s_FxGetDateTippani " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    date1 = myreader["CreateDate"].ToString();
                   

                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

        return date1;

    }





    protected void Page_Load(object sender, EventArgs e)
    {
         id = Request.QueryString["id"].ToString();
         date = Request.QueryString["date"].ToString();
         status = Request.QueryString["S"].ToString();
        FxGetTippaniDetailView(id);

        if (status == "V")
        {
            date = Fxgetdate(id);
        
        }


        Label21.Text = date;//Session["TodayDate"].ToString();
        Label10.Text = "यस कार्यालयको स्वीकृत बार्षिक कार्यक्रम अनुसार देहायको उपभोक्ता समितिसंग सम्झौता गरि योजनाको कार्यादेश दिनका लागि श्रीमान समक्ष यो टिप्पणी पेश गरेको छु |";

        if (status == "A")
        {

            btnapproved.Visible = true;
        }
        
        this.Button2.Attributes.Add("onclick", "javascript:printDiv('printme')");
        FxCreate(id, date);
    }


    private void FxCreate(string id,string date)
    {
      //
        string num = "";
        if (status=="C")
        {
            num = "4";
        }
        else if (status == "A")
        {
            num = "5";
        }

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_PlanningLog", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = id;
        cmd.Parameters.Add("@step", SqlDbType.VarChar, 40).Value = num;
        cmd.Parameters.Add("@createdate", SqlDbType.VarChar, 40).Value = date;
        cmd.Parameters.Add("@status", SqlDbType.VarChar, 40).Value = status;


        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

            // string contractID = Convert.ToString(cmd.Parameters["@IdentitY"].Value);
            // string contractIDd = Convert.ToString(cmd.Parameters["@result"].Value);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
        }




    }



    protected void Button2_Click(object sender, EventArgs e)
    {
        
    }
}