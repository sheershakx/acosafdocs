﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class ListForTippani : System.Web.UI.Page
{
    public static string btntype = "";

    private void GetData()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select distinct P.Id,P.Name,P.Place,W.Name,F.Fiscalyear,P.Remarks,Status=dbo.f_GetPlanStatusNext(P.PlanCode)
                                            from Planning P
                                            inner join WardName W 
                                            on P.WardNo=W.Id
                                            inner join Fiscalyear F 
                                            on F.Fiscalyear=P.FiscalYear 
                                            inner join U_SamitiDetail U
                                            on P.Id=U.PlanningId
                                            inner join CostEstimation C
                                            on P.Id=C.PlanningId
                                            where P.Process=" + drpProcess.SelectedValue + " and  P.FiscalYear='" + drpfiscalyear.SelectedValue + "' and P.WardNo='" + drpwardno.SelectedValue + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptTable.DataSource = ds;
            rptTable.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }

//        btntype = @"<a  href='javascript:window.open('Format/TippaniNew.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-primary btn-sm'>Tippani</a>
//                                         &nbsp;
//                                          <a  href='javascript:window.open('Format/Aggrement.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-danger btn-sm'>Aggrement</a>
//                                          &nbsp;
//                                          <a  href='javascript:window.open('Format/AggrementWorder.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-warning btn-sm'>WorkOrder</a>
//                                        &nbsp;";

        

    }

    
    private void GetData1()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select distinct P.Id,P.Name,P.Place,W.Name,F.Fiscalyear,P.Remarks from Planning P
                                            inner join WardName W 
                                            on P.WardNo=W.Id
                                            inner join Fiscalyear F 
                                            on F.Id=P.FiscalYear 
                                            inner join U_SamitiDetail U
                                            on P.Id=U.PlanningId
                                            inner join CostEstimation C
                                            on P.Id=C.PlanningId
                                            where P.Process=" + drpProcess.SelectedValue + " and P.Id not in (Select PlanningId from BillPayment where PaymentType<>3) and P.FiscalYear='" + drpfiscalyear.SelectedValue + "' and P.WardNo='" + drpwardno.SelectedValue + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rpttable2.DataSource = ds;
            rpttable2.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }

        //        btntype = @"<a  href='javascript:window.open('Format/TippaniNew.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-primary btn-sm'>Tippani</a>
        //                                         &nbsp;
        //                                          <a  href='javascript:window.open('Format/Aggrement.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-danger btn-sm'>Aggrement</a>
        //                                          &nbsp;
        //                                          <a  href='javascript:window.open('Format/AggrementWorder.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-warning btn-sm'>WorkOrder</a>
        //                                        &nbsp;";



    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            Class1 a = new Class1();

           // GetData();
            a.loadcomboForFiscalyear(drpfiscalyear, "select * from Fiscalyear order by Id desc ", "FiscalYear", "FiscalYear");
            a.loadcomboForFiscalyear(drpwardno, "select * from WardName order by Id asc ", "Name", "Name");
            a.loadcombo(drpProcess, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from ImplementProcess", "Name", "Id");

           






        }
    }





    protected void btnsave_Click(object sender, EventArgs e)
    {

        FxSave();
    }



    protected void btnapproved_Click(object sender, EventArgs e)
    {

       // FxSave();
    }


    protected void btncreate_Click(object sender, EventArgs e)
    {
        //FxCreate();

        Page.ClientScript.RegisterStartupScript(this.GetType(), "Script", "openform('2','2')", true);
        // FxSave();
    }


    private void FxSave()
    {


        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanningDetailInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningCode", SqlDbType.VarChar, 40).Value = txtcode.Text;
        cmd.Parameters.Add("@Name", SqlDbType.VarChar, 40).Value = txtname.Text;
        cmd.Parameters.Add("@Address", SqlDbType.VarChar, 40).Value = txtaddress.Text;
        // cmd.Parameters.Add("@JoinDate", SqlDbType.VarChar, 40).Value = txtjoindate.Text;
        cmd.Parameters.Add("@Remark", SqlDbType.VarChar, 40).Value = txtremark.Text;


        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            GetData();
            // string contractID = Convert.ToString(cmd.Parameters["@IdentitY"].Value);
            // string contractIDd = Convert.ToString(cmd.Parameters["@result"].Value);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
        }




    }

    private void FxCreate()
    {


        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_PlanningLog", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = txtcode.Text;
        cmd.Parameters.Add("@step", SqlDbType.VarChar, 40).Value = "5";
        cmd.Parameters.Add("@createdate", SqlDbType.VarChar, 40).Value = txtcreatedate.Text;
     


        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
           
            // string contractID = Convert.ToString(cmd.Parameters["@IdentitY"].Value);
            // string contractIDd = Convert.ToString(cmd.Parameters["@result"].Value);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
        }




    }





















    protected void btnshow_Click(object sender, EventArgs e)
    {
        if (drpProcess.SelectedValue == "1")
        {
            rptTable.Visible = true;
            rpttable2.Visible = false;
            GetData();
        }
        else if ( Convert.ToInt32(drpProcess.SelectedValue) >= 2)
        {
            rptTable.Visible = false;
            rpttable2.Visible = true;
            GetData1();
        }

        //GetData1();
        
    }

    
}