﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class UpabhoktaListForGathan : System.Web.UI.Page
{
    private void GetData()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from Planning", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptTable.DataSource = ds;
            rptTable.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            Class1 a = new Class1();

            GetData();










        }
    }





    protected void btnsave_Click(object sender, EventArgs e)
    {

        FxSave();
    }


    private void FxSave()
    {


        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanningDetailInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningCode", SqlDbType.VarChar, 40).Value = txtcode.Text;
        cmd.Parameters.Add("@Name", SqlDbType.VarChar, 40).Value = txtname.Text;
        cmd.Parameters.Add("@Address", SqlDbType.VarChar, 40).Value = txtaddress.Text;
        // cmd.Parameters.Add("@JoinDate", SqlDbType.VarChar, 40).Value = txtjoindate.Text;
        cmd.Parameters.Add("@Remark", SqlDbType.VarChar, 40).Value = txtremark.Text;


        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            GetData();
            // string contractID = Convert.ToString(cmd.Parameters["@IdentitY"].Value);
            // string contractIDd = Convert.ToString(cmd.Parameters["@result"].Value);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
        }




    }





















}