﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Tippani : System.Web.UI.Page
{
    public string gu = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            gu=Guid.NewGuid().ToString();
            Class1 a = new Class1();
            a.loadforbank(drpplanning, "select PlanningCode,(Name +  '(' + Address + ' )') as Name from dbo.PlanningDetail", "Name", "PlanningCode");
            a.loadforbank(drpsamiti, "select SamitiCode,(Name +  '(' + Address + ' )') as Name from dbo.Samiti", "Name", "SamitiCode");
            a.loadforbank(drpbiniyotype, "select * from dbo.BiniyojanType", "BType", "Code");
            a.loadforbank(drpplansubtype, "select * from  dbo.PlanningSubType", "PlanningSubType", "Code");




           
        }
    }



    private void FxAdd()
    {
         //gu=
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_InsertTippaniDetailTemp", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Desc1", SqlDbType.VarChar, 40).Value = txtdes.Text;
        cmd.Parameters.Add("@Amount", SqlDbType.VarChar, 40).Value = txtamount.Text;
        cmd.Parameters.Add("@guid", SqlDbType.VarChar, 40).Value = gu;
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            Class1 a = new Class1();
            a.loadgrid(GridView1, "select * from TippaniDetailTemp where Guid='" + gu + "'");
           // fxClear();
            //string contractID = Convert.ToString(cmd.Parameters["@IdentitY"].Value);
            //string contractIDd = Convert.ToString(cmd.Parameters["@result"].Value);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
        }


    }

    private void FxSave()
    {
        //gu=
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_InsertTippaniSummary", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@PlaningID", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@PlanningSubTypeId", SqlDbType.VarChar, 40).Value = drpplansubtype.SelectedValue;
        cmd.Parameters.Add("@SamitiId", SqlDbType.VarChar, 40).Value = drpsamiti.SelectedValue;
        cmd.Parameters.Add("@BiniyojanType", SqlDbType.VarChar, 40).Value = drpbiniyotype.SelectedValue;
        cmd.Parameters.Add("@StartDate", SqlDbType.VarChar, 40).Value = txtstartdate.Text;
        cmd.Parameters.Add("@EndDate", SqlDbType.VarChar, 40).Value = txtendate.Text;
        cmd.Parameters.Add("@guid", SqlDbType.VarChar, 40).Value = gu;
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
           // Class1 a = new Class1();
          //  a.loadgrid(GridView1, "select * from TippaniDetailTemp where Guid='" + gu + "'");
            // fxClear();
            //string contractID = Convert.ToString(cmd.Parameters["@IdentitY"].Value);
            //string contractIDd = Convert.ToString(cmd.Parameters["@result"].Value);
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
        }


    }


    protected void btnadd_Click(object sender, EventArgs e)
    {
        FxAdd();
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        FxSave();
    }
}