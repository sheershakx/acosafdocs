﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Plan_Status : System.Web.UI.Page
{



    private void FxGetPlannigDetail(string Id)
    {

        // sql1 = "";



        string sql = @"select * from PlanningActivity where Id=" + Id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    Class1 a = new Class1();


                    txtactivity.Text = myreader["ActivityDetail"].ToString();
                    txtdocumentname.Text = myreader["DocumentDetail"].ToString();
                    txtotherDetail.Text = myreader["OtherDetail"].ToString();
                   // txtremarks.Text = myreader["PlanSubject"].ToString();
                    

                  


                    // lblcompanyname.Text = myreader["CompanyName"].ToString();
                    // Session["CompanyName"] = myreader["CompanyName"].ToString();
                    // string logo = myreader["LogoPath"].ToString();
                    // lbldate.Text = System.DateTime.Now.ToString();


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Class1 a = new Class1();
            a.loadcombo(drpplanning, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning", "Name", "Id");
           // a.loadcombo(drpcostsource, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from CostSource", "Name", "ID");
            
             
           // a.loadgrid(GridView2, "Select * from planHead");
        }
    }


    private void FxClear()
    {
        txtactivity.Text = "";
        txtdate.Text = "";
        txtdocumentname.Text = "";
        txtfiscalyear.Text = "";
        txtotherDetail.Text = "";
        txtplace.Text = "";
        txtremarks.Text = "";
        txtward.Text = "";
        
        Class1 a = new Class1();
        a.loadgrid(GridView2, "select Id as '#',ActivityDetail as 'क्रियाकलापको विवरण',OtherDetail as 'अन्य विवरण',DocumentDetail as 'कागजातको विवरण' from PlanningActivity where PlanningID='" + drpplanning.SelectedValue + "'");
    }



    private void FxDelete()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanHeadDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            FxClear();

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }

    private void FxUpdate()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("usp_PlanningActivityUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        //cmd.Parameters.Add("@SID", SqlDbType.VarChar, 100).Value = drpsubject.SelectedValue;

        //cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 500).Value = txttype.Text;

        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@ActivityDetail", SqlDbType.VarChar, 40).Value = txtactivity.Text;
        cmd.Parameters.Add("@Date", SqlDbType.VarChar, 40).Value = txtdate.Text;
        cmd.Parameters.Add("@OtherDetail", SqlDbType.VarChar, 40).Value = txtotherDetail.Text;
        cmd.Parameters.Add("@DocumentDetail", SqlDbType.VarChar, 40).Value = txtdocumentname.Text;
        cmd.Parameters.Add("@DocumentFile", SqlDbType.VarChar, 40).Value = "11";
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();
        cmd.Parameters.Add("@EntryDate", SqlDbType.VarChar, 40).Value = DateTime.Now;
        //cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = "1";


        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            Class1 a = new Class1();

            a.loadgrid(GridView2, "select Id,ActivityDetail,OtherDetail,DocumentDetail from PlanningActivity");

            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Updated Successfully !')", true);


        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }


    private void FxSave()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("usp_PlanningActivityInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@ActivityDetail", SqlDbType.VarChar, 40).Value = txtactivity.Text;
        cmd.Parameters.Add("@Date", SqlDbType.VarChar, 40).Value = txtdate.Text;
        cmd.Parameters.Add("@OtherDetail", SqlDbType.VarChar, 40).Value = txtotherDetail.Text;
        cmd.Parameters.Add("@DocumentDetail", SqlDbType.VarChar, 40).Value = txtdocumentname.Text;
        cmd.Parameters.Add("@DocumentFile", SqlDbType.VarChar, 40).Value = "11";
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();
        cmd.Parameters.Add("@EntryDate", SqlDbType.VarChar, 40).Value = DateTime.Now;
       // cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = "1";


        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            Class1 a = new Class1();

            a.loadgrid(GridView2, "select Id,ActivityDetail,OtherDetail,DocumentDetail from PlanningActivity");
            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }
    protected void btnsave_Click(object sender, EventArgs e)
    {

        //FxSave();
        if (btnsave.Text == "Save")
        {
            FxSave();
        }
        else if (btnsave.Text == "Update")
        {
            FxUpdate();

        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //GridViewRow row = GridView1.SelectedRow;
        //Session["ID"] = row.Cells[1].Text;


        //txtremarks.Text = Server.HtmlDecode(row.Cells[5].Text);
        //btnsave.Text = "Update";
        //btndelete.Enabled = true;

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        FxClear();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        FxDelete();
    }
    protected void btnsave_Click1(object sender, EventArgs e)
    {
        if (btnsave.Text == "Save")
        {
            FxSave();
        }
        else if (btnsave.Text == "Update")
        {
            FxUpdate();

        }
    }
    protected void drpplanning_SelectedIndexChanged(object sender, EventArgs e)
    {
        FxPlanningDetail(drpplanning.SelectedValue);
        Class1 a = new Class1();
        a.loadgrid(GridView2, "select Id as '#',ActivityDetail as 'क्रियाकलापको विवरण',OtherDetail as 'अन्य विवरण',DocumentDetail as 'कागजातको विवरण' from PlanningActivity where PlanningID='" + drpplanning.SelectedValue + "'");
    }



    private void FxPlanningDetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning where Id= " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    txtplace.Text = myreader["Place"].ToString();
                    txtward.Text = myreader["WardNo"].ToString();
                    txtfiscalyear.Text = myreader["FiscalYear"].ToString();
                    txtremarks.Text = myreader["Remarks"].ToString();



                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }


    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView2.SelectedRow;
        Session["ID"] = row.Cells[1].Text;
        FxGetPlannigDetail(row.Cells[1].Text);

        //txtremarks.Text = Server.HtmlDecode(row.Cells[5].Text);
        btnsave.Text = "Update";
        //btndelete.Enabled = true;
    }
}