﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

public partial class MasterSetup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        FxGetDetail();
    }


    private void FxGetDetail()
    {

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);
        SqlDataReader myreader;
        SqlCommand SelectCommand = new SqlCommand(@"select * from ControlTable", myconn);
        try
        {
            myconn.Open();

            myreader = SelectCommand.ExecuteReader();

            if (myreader.HasRows)
            {


                while (myreader.Read()) //returing false 
                {
                    // txtname.Text = myreader["Name"].ToString();
                    txtFiscalYear.Text = myreader["FiscalYear"].ToString();
                    txtVat.Text = myreader["Vat"].ToString();


                }


            }
        }
        catch (Exception ex)
        {
            //Usual Code
            // lblmessage.Text = ex.Message.ToString();
        }

        finally
        {
            myconn.Close();
        }
    }

 


}