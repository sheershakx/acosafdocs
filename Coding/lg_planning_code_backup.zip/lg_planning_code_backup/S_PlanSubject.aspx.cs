﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class PlanSubject : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Class1 a = new Class1();
            a.loadgrid(GridView1, @"SELECT     Id as '#', Name as 'विवरण', Description as 'कैफियत', Status as 'अवस्था'
                                FROM         PlanSubject");
           
        }
    }


    private void FxClear()
    {
        txtremarks.Text = "";
        txttype.Text = "";
        drpstatus.SelectedValue = "0";
        lblerror.Text = "";
        Session["ID"] = "";
        btnsave.Text = "Save";
        btndelete.Enabled = false;
        Class1 a = new Class1();
        a.loadgrid(GridView1, @"SELECT     Id as '#', Name as 'विवरण', Description as 'कैफियत', Status as 'अवस्था'
                                FROM         PlanSubject");
    }



    private void FxDelete()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanSubjectDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            FxClear();

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }


    }

    private void FxUpdate()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanSubjectUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();
   
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 100).Value = txttype.Text;

        cmd.Parameters.Add("@Description", SqlDbType.NVarChar, 200).Value = txtremarks.Text;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 200).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();


        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Updated Successfully !')", true);


        }
        catch (Exception ex)

        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }


    private void FxSave()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanSubjectInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 100).Value = txttype.Text;

        cmd.Parameters.Add("@Description", SqlDbType.NVarChar, 200).Value = txtremarks.Text;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 200).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        
        if (txttype.Text != "")
        {
            Boolean datay = false;
            Class1 a = new Class1();
            datay = a.fxrecordcheck("Select Name from PlanSubject where Name=N'" + txttype.Text + "'");
            if (datay == true)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Duplicate name found !')", true);
                txttype.Focus();
                return;
            }
        }
        if (drpstatus.SelectedValue == "0")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Please Select Status !')", true);
            drpstatus.Focus();
            return;
        }

        if (btnsave.Text == "Save")
        {
            FxSave();
        }
        else if (btnsave.Text == "Update")
        {
            FxUpdate();

        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;
        Session["ID"] = row.Cells[1].Text;
     
        txttype.Text = Server.HtmlDecode(row.Cells[2].Text);
        txtremarks.Text = Server.HtmlDecode(row.Cells[3].Text);
        btnsave.Text = "Update";
        btndelete.Enabled = true;

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        FxClear();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        FxDelete();
    }
}