﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Inventory;

public partial class RptPlanning : System.Web.UI.Page
{

    private void GetData()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select ROW_NUMBER() OVER(ORDER BY P.Name ASC) AS a, P.Id as b,P.Name as c  ,Place AS  d,WardNo AS e,L.Name as f,H.Name as g,
                                    A.Name as h,E.Name as i,P.BudgetAmount AS j,P.StartDate AS k,
                                    P.EndDate AS l,dbo.f_GetPlanStatus(P.PlanCode) as m
                                    
                                   
                                     from Planning P
                                    inner join PlanSubject L
                                    on P.PlanSubject=L.Id
                                    inner join PlanHead H
                                    on P.PlanHead=H.Id
                                    inner join PlanSubHead A
                                    on P.PlanSubHead = A.Id 
                                    inner join PlanSource E
                                    on E.Id=P.PlanSource and P.FiscalYear='" + drphead.SelectedValue + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptTable.DataSource = ds;
            rptTable.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }

        //        btntype = @"<a  href='javascript:window.open('Format/TippaniNew.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-primary btn-sm'>Tippani</a>
        //                                         &nbsp;
        //                                          <a  href='javascript:window.open('Format/Aggrement.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-danger btn-sm'>Aggrement</a>
        //                                          &nbsp;
        //                                          <a  href='javascript:window.open('Format/AggrementWorder.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-warning btn-sm'>WorkOrder</a>
        //                                        &nbsp;";



    }

    protected void Page_Load(object sender, EventArgs e)
    {
       // Class1 a = new Class1();
//        a.loadgrid2(mytable, @"select ROW_NUMBER() OVER(ORDER BY P.Name ASC) AS 'नं', P.Id as 'योजना नं',P.Name as 'योजनाको नाम '  ,Place AS  'ठेगाना',WardNo AS 'वडा नं',L.Name as 'विषयगत क्षेत्र',H.Name as 'शिर्षक',
//                                    A.Name as 'उपशिर्षक',E.Name as 'स्रोत',P.BudgetAmount AS 'बजेट रकम',P.StartDate AS 'शुरु मिति',
//                                    P.EndDate AS 'सम्पन्न हुने मिति',
//                                    Status= case when B.PaymentType=3 then 'Finished' else 'Nott' end
//                                     from Planning P
//                                    inner join PlanSubject L
//                                    on P.PlanSubject=L.Id
//                                    inner join PlanHead H
//                                    on P.PlanHead=H.Id
//                                    inner join PlanSubHead A
//                                    on P.PlanSubHead = A.Id 
//                                    inner join PlanSource E
//                                    on E.Id=P.PlanSource
//                                    inner join BillPayment B
//                                    on B.PlanningId=P.Id");
       // GetData();
       // this.Button1.Attributes.Add("onclick", "javascript:printDiv('printme')");

        if (!IsPostBack)
        {
            Class1 a = new Class1();
            a.loadcomboForFiscalyear(drphead, "select * from Fiscalyear order by Id desc ", "FiscalYear", "FiscalYear");
            this.Button1.Attributes.Add("onclick", "javascript:printDiv('printme')");
        }

    }
    protected void btnexport_Click(object sender, EventArgs e)
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=ApprovePlanning.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        Response.Output.Write(Request.Form[hfGridHtml.UniqueID]);
        Response.Flush();
        Response.End();
    }
    protected void btnshow_Click(object sender, EventArgs e)
    {
        GetData();
    }
}