﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class Format_TippaniFormat : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    public string getStudentData()
    {
        string data = "";

        // con = new SqlConnection(ConnectionString);
        // SqlConnection con = 
        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"exec s_RptTippani";
                cmd.Connection.Open();
                using (SqlDataReader sqlRdr = cmd.ExecuteReader())
                {
                    // table = new DataTable();  
                    // table.Load(reader);  
                    if (sqlRdr.HasRows)
                    {
                        while (sqlRdr.Read())
                        {
                            string A1 = sqlRdr["a1"].ToString(); //sqlRdr.GetString(0);
                            string A11 = sqlRdr["a2"].ToString(); //sqlRdr.GetString(0);
                            
                            // lblrequest.Text = sqlRdr["PORequest"].ToString();
                            // lblrecomender.Text = sqlRdr["PORecomonder"].ToString();
                            // lblapprover.Text = sqlRdr["POApprover"].ToString();

                            data += "<tr><td>" + A1 + "</td><td>" + A11 + "</td></tr>";
                        }
                    }
                }
            }
            return data;
        }
    }





    private void FxGenerate()
    {


        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_GenerateTippani", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = "";
        


        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
           
        }
        catch (Exception ex)
        {
        }
        finally
        {
            con.Close();
        }




    }


    protected void btngenerate_Click(object sender, EventArgs e)
    {
        FxGenerate();
    }
}