﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Bill_Payment_New : System.Web.UI.Page
{

    public static string openform = "";
    public static string planningido = "0";



    private void GetData()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select distinct B.Id, B.PaymentDate,P.Name as PName,T.Name as TName,
                                        B.PaymentAmount,
                                        PStatus=case when Pstatus=2 then N'स्विकृती' else N'स्विकृती बाकी' end  from BillPayment B
                                        inner join dbo.PaymentTypeSetup P
                                        on B.PaymentType=P.Id
                                        inner join dbo.ScheduleType T
                                        on B.SheduleType=T.Id
                                       
                                            where B.PlanningId=" + drpplanning.SelectedValue + " order by Id desc", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptTable.DataSource = ds;
            rptTable.DataBind();
            planningido = drpplanning.SelectedValue;
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }



    private void FxPlanningDetailOther(string id)
    {

        // sql1 = "";



        string sql = @"select distinct 
                                        B.PaymentAmount
                                        from BillPayment B
                                        inner join dbo.PaymentTypeSetup P
                                        on B.PaymentType=P.Id
                                        inner join dbo.ScheduleType T
                                        on B.SheduleType=T.Id
                                            where B.PlanningId= " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    // lbldetail.Text = " स्थान : " + myreader["Place"].ToString() + ",     वडा नं. :" + myreader["WardNo"].ToString() + ",   आर्थिक बर्ष : " + myreader["FiscalYear"].ToString() + ", समितिको नाम : " + myreader["SamitiName"].ToString();
                    txttotalpayment.Text = myreader["PaymentAmount"].ToString();
                    //   txtpplace.Text = myreader["Place"].ToString();
                    //  txtpward.Text = myreader["WardNo"].ToString();
                    //  txtfiscalyear.Text = myreader["FiscalYear"].ToString();
                    //   txtsamitiname.Text = myreader["Name"].ToString() + " उपभोक्ता समिति";



                }
            }
            else
            {
                lbldetail.Text = "";
                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

    private void FxPlanningDetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning P
                        inner join U_SamitiDetail U on P.Id = U.PlanningId where P.Id= " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    lbldetail.Text = " स्थान : " + myreader["Place"].ToString() + ",     वडा नं. :" + myreader["WardNo"].ToString() + ",   आर्थिक बर्ष : " + myreader["FiscalYear"].ToString() + ", समितिको नाम : " + myreader["SamitiName"].ToString();
                    txtbudgetamount.Text = myreader["BudgetAmount"].ToString();
                    //   txtpplace.Text = myreader["Place"].ToString();
                    //  txtpward.Text = myreader["WardNo"].ToString();
                    //  txtfiscalyear.Text = myreader["FiscalYear"].ToString();
                    //   txtsamitiname.Text = myreader["Name"].ToString() + " उपभोक्ता समिति";



                }
            }
            else
            {
                lbldetail.Text = "";
                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }


    private void FxPlanningDetailNew(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning P
                         where P.Id= " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    // lbldetail.Text = " स्थान : " + myreader["Place"].ToString() + ",     वडा नं. :" + myreader["WardNo"].ToString() + ",   आर्थिक बर्ष : " + myreader["FiscalYear"].ToString() + ", समितिको नाम : " + myreader["SamitiName"].ToString();
                    txtbudgetamount.Text = myreader["BudgetAmount"].ToString();
                    //   txtpplace.Text = myreader["Place"].ToString();
                    //  txtpward.Text = myreader["WardNo"].ToString();
                    //  txtfiscalyear.Text = myreader["FiscalYear"].ToString();
                    //   txtsamitiname.Text = myreader["Name"].ToString() + " उपभोक्ता समिति";



                }
            }
            else
            {
                lbldetail.Text = "";
                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

    protected void btncosting_Click(object sender, EventArgs e)
    {
         FxSave();

    }

  



    protected void btnothersave_Click(object sender, EventArgs e)
    {

         FxOtherSave();

    }

   




    protected void btndelete_Click(object sender, EventArgs e)
    {
        // FxSave();
        FxApproved();

    }



    protected void drpplanning_SelectedIndexChanged(object sender, EventArgs e)
    {
        FxPlanningDetail(drpplanning.SelectedValue);

        GetData();
    }

    protected void btnproceed1_Click(object sender, EventArgs e)
    {
        view.Visible = true;
        GetData();
        FxPlanningDetailOther(drpplanning.SelectedValue);
        FxPlanningDetailNew(drpplanning.SelectedValue);
    }






    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {




            view.Visible = false;
            txtdate.Text = Session["TodayDate"].ToString();
            txtotherdate.Text = Session["TodayDate"].ToString();
            // view1.Visible = false;
            //    btnproceed.Visible = false;
            //txttargetdalit.Attributes.Add("Type","Number");
            //txttargetfemale.Attributes.Add("Type","Number");
            //txttargethouse.Attributes.Add("Type","Number");
            //txttargetjanajati.Attributes.Add("Type","Number");
            //txttargetmadhesi.Attributes.Add("Type","Number");
            //txttargetother.Attributes.Add("Type","Number");
            //txttargettotal.Attributes.Add("Type","Number");
            //txttotalmemeber.Attributes.Add("Type", "Number");
            // targettotal =Convert.ToDouble(txttargettotal.Text);

            Class1 a = new Class1();
            a.loadcomboForFiscalyear(drpfiscalyear, "select * from Fiscalyear order by Id desc ", "FiscalYear", "FiscalYear");
            a.loadcombo(drpwardno, "select * from WardName order by Id asc ", "Name", "Name");
            drpfiscalyear_SelectedIndexChanged(sender, e);
            // guid = System.Guid.NewGuid().ToString();
            // a.loadcombo(drpcostsource, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from CostSource", "Name", "ID");
            //txttargettotal.Text = "56";
            //a.loadcombo(drpsubject, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from Plansubject", "Name", "ID");
            // a.loadgrid(GridView1, "Select * from planHead");
            // a.loadgrid(GridView2, "Select * from planHead");
            // a.loadcombo(drpplanning, @"select P.ID,(convert(nvarchar(10),P.ID) + ' - ' + Name) as Name from Planning P
            //   ", "Name", "Id");
            a.loadcombo(drpschedule, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from ScheduleType", "Name", "Id");
            a.loadcombo(drpotherschedule, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from ScheduleType", "Name", "Id");




        }
    }


    private void FxOtherSave()
    {


        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_BillPaymentInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;



        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@PaymentType", SqlDbType.VarChar, 40).Value = drptest.SelectedValue;

        // Control divcontrol = (Control)FindControl("kista_div");
        if (txtpayment.Text == "अन्तिम बिल भुक्तानी")
        {
            cmd.Parameters.Add("@SheduleType", SqlDbType.VarChar, 40).Value = "1";
        }
        else
        {
            cmd.Parameters.Add("@SheduleType", SqlDbType.VarChar, 40).Value = drpotherschedule.SelectedValue;
        }







        cmd.Parameters.Add("@TechnicalAmount", SqlDbType.VarChar, 40).Value = txtothertechnicalamount.Text;
        cmd.Parameters.Add("@DeductionAmount", SqlDbType.VarChar, 40).Value = txtdeductionamount.Text;
        cmd.Parameters.Add("@PaymentAmount", SqlDbType.VarChar, 40).Value = txtnetamount.Text;
        cmd.Parameters.Add("@TechnicalPerson", SqlDbType.NVarChar, 440).Value = txtothertechnicalperson.Text;
        cmd.Parameters.Add("@Remark", SqlDbType.NVarChar, 440).Value = txtremark.Text;
        cmd.Parameters.Add("@PaymentDate", SqlDbType.VarChar, 40).Value = txtdate.Text;
        cmd.Parameters.Add("@OfficeId", SqlDbType.VarChar, 40).Value = "1";
        cmd.Parameters.Add("@EnteredBy", SqlDbType.VarChar, 40).Value = "1";
        cmd.Parameters.Add("@TranDate", SqlDbType.VarChar, 40).Value = "2018-01-01";
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = "1";
        cmd.Parameters.Add("@PStatus", SqlDbType.VarChar, 40).Value = "1";

        if (checkbox.Checked == false)
        {
            cmd.Parameters.Add("@PeopleInvolveGross", SqlDbType.VarChar, 40).Value = "0";
            cmd.Parameters.Add("@PeopleInvolvePer", SqlDbType.VarChar, 40).Value = "0";
            cmd.Parameters.Add("@PeopleInvolveNet", SqlDbType.VarChar, 40).Value = "0";

            cmd.Parameters.Add("@PanBillGross", SqlDbType.VarChar, 40).Value = "0";
            cmd.Parameters.Add("@PanBillPer", SqlDbType.VarChar, 40).Value = "0";
            cmd.Parameters.Add("@PanBillNet", SqlDbType.VarChar, 40).Value = "0";

            cmd.Parameters.Add("@VatBillGross", SqlDbType.VarChar, 40).Value = "0";
            cmd.Parameters.Add("@VatBillPer", SqlDbType.VarChar, 40).Value = "0";
            cmd.Parameters.Add("@VatBillNet", SqlDbType.VarChar, 40).Value = "0";

            cmd.Parameters.Add("@TransportGross", SqlDbType.VarChar, 40).Value = "0";
            cmd.Parameters.Add("@TransportPer", SqlDbType.VarChar, 40).Value = "0";
            cmd.Parameters.Add("@TransportNet", SqlDbType.VarChar, 40).Value = "0";
        }
        else if (checkbox.Checked == true)
        {
            cmd.Parameters.Add("@PeopleInvolveGross", SqlDbType.VarChar, 40).Value = txtpeopleinvolvedgross.Text;
            cmd.Parameters.Add("@PeopleInvolvePer", SqlDbType.VarChar, 40).Value = txtpeopleinvolvedper.Text;
            cmd.Parameters.Add("@PeopleInvolveNet", SqlDbType.VarChar, 40).Value = txtpeopleinvolvednet.Text;

            cmd.Parameters.Add("@PanBillGross", SqlDbType.VarChar, 40).Value = txtpanbillgross.Text;
            cmd.Parameters.Add("@PanBillPer", SqlDbType.VarChar, 40).Value = txtpanbillper.Text;
            cmd.Parameters.Add("@PanBillNet", SqlDbType.VarChar, 40).Value = txtpanbillnet.Text;

            cmd.Parameters.Add("@VatBillGross", SqlDbType.VarChar, 40).Value = txtothervatgross.Text;
            cmd.Parameters.Add("@VatBillPer", SqlDbType.VarChar, 40).Value = txtothervatper.Text;
            cmd.Parameters.Add("@VatBillNet", SqlDbType.VarChar, 40).Value = txtothervatnet.Text;

            cmd.Parameters.Add("@TransportGross", SqlDbType.VarChar, 40).Value = txtothertransportgross.Text;
            cmd.Parameters.Add("@TransportPer", SqlDbType.VarChar, 40).Value = txtothertransportper.Text;
            cmd.Parameters.Add("@TransportNet", SqlDbType.VarChar, 40).Value = txtothertransportnet.Text;
        }

        cmd.Parameters.Add("@TechnicalSuggestion", SqlDbType.NVarChar, 440).Value = txttechnicalsuggest.Text;



        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

            GetData();
            txtamount.Text = "";
            txtapprovedid.Text = "";
            txtdate.Text = "";
            txtdeduction.Text = "";
            txtremark.Text = "";
            txttechnical.Text = "";
            txttechnicalamount.Text = "";
            // FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !');", true);
            Class1 a = new Class1();
            a.fxsqlcommand("update Planning set ActualQty='" + txtactulaqty.Text + "' ,ActualUnit='" + txtactualunit.Text + "' where Id='" + drpplanning.SelectedValue + "'", lbldetail, "");


        }
        catch (Exception ex)
        {
            //  lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }


    }

    private void FxSave()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_BillPaymentInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;



        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@PaymentType", SqlDbType.VarChar, 40).Value = drptest.SelectedValue;
        cmd.Parameters.Add("@SheduleType", SqlDbType.VarChar, 40).Value = drpschedule.SelectedValue;
        cmd.Parameters.Add("@TechnicalAmount", SqlDbType.VarChar, 40).Value = txttechnicalamount.Text;
        cmd.Parameters.Add("@DeductionAmount", SqlDbType.VarChar, 40).Value = txtdeductionamount.Text;
        cmd.Parameters.Add("@PaymentAmount", SqlDbType.VarChar, 40).Value = txtamount.Text;
        cmd.Parameters.Add("@TechnicalPerson", SqlDbType.VarChar, 40).Value = txttechnical.Text;
        cmd.Parameters.Add("@Remark", SqlDbType.NVarChar, 440).Value = txtremark.Text;
        cmd.Parameters.Add("@PaymentDate", SqlDbType.VarChar, 40).Value = txtdate.Text;
        cmd.Parameters.Add("@OfficeId", SqlDbType.VarChar, 40).Value = "1";
        cmd.Parameters.Add("@EnteredBy", SqlDbType.VarChar, 40).Value = "1";
        cmd.Parameters.Add("@TranDate", SqlDbType.VarChar, 40).Value = "2018-01-01";
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = "1";
        cmd.Parameters.Add("@PStatus", SqlDbType.VarChar, 40).Value = "1";
        cmd.Parameters.Add("@PeopleInvolveGross", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@PeopleInvolvePer", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@PeopleInvolveNet", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@PanBillGross", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@PanBillPer", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@PanBillNet", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@VatBillGross", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@VatBillPer", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@VatBillNet", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@TransportGross", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@TransportPer", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@TransportNet", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@TechnicalSuggestion", SqlDbType.NVarChar, 440).Value = "";



        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

            GetData();
            txtamount.Text = "";
            txtapprovedid.Text = "";
            txtdate.Text = "";
            txtdeduction.Text = "";
            txtremark.Text = "";
            txttechnical.Text = "";
            txttechnicalamount.Text = "";
            // FxClear();
            // ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !');", true);



        }
        catch (Exception ex)
        {
            //  lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }

    protected void drpfiscalyear_SelectedIndexChanged(object sender, EventArgs e)
    {
        Class1 a = new Class1();
        a.loadcombo(drpplanning, @"Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning where [Process]=1 and FiscalYear='" + drpfiscalyear.SelectedValue + "' and Wardno='" + drpwardno.SelectedValue + "'", "Name", "Id");
    }

    private void FxApproved()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_Approved", con);
        cmd.CommandType = CommandType.StoredProcedure;



        cmd.Parameters.Add("@id", SqlDbType.VarChar, 40).Value = txtapprovedid.Text;




        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

            GetData();
            // FxClear();
            // ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !');", true);



        }
        catch (Exception ex)
        {
            //  lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }
}