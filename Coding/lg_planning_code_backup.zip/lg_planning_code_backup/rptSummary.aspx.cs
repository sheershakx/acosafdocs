﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class rptSummary : System.Web.UI.Page
{


    private void GetData()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"exec s_rptpllaningsummary", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptTable.DataSource = ds;
            rptTable.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }

        //        btntype = @"<a  href='javascript:window.open('Format/TippaniNew.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-primary btn-sm'>Tippani</a>
        //                                         &nbsp;
        //                                          <a  href='javascript:window.open('Format/Aggrement.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-danger btn-sm'>Aggrement</a>
        //                                          &nbsp;
        //                                          <a  href='javascript:window.open('Format/AggrementWorder.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-warning btn-sm'>WorkOrder</a>
        //                                        &nbsp;";



    }


    protected void btnexport_Click(object sender, EventArgs e)
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=Summary.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        Response.Output.Write(Request.Form[hfGridHtml.UniqueID]);
        Response.Flush();
        Response.End();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        GetData();
        this.Button1.Attributes.Add("onclick", "javascript:printDiv('printme')");
    }
}