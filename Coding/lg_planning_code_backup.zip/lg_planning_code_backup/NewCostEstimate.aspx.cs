﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class NewCostEstimate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Class1 a = new Class1();
        a.loadcombo(drpplanning, @"select P.Id,('Plan Name :'  + P.Name + ' Place : ' + Place + ' Ward Name : ' + W.Name + ' Fiscal Yearr :'
                                + F.Fiscalyear) as Name from Planning P
                                inner join WardName W 
                                on P.WardNo=W.Id
                                inner join Fiscalyear F 
                                on F.Id=P.FiscalYear", "Name", "Id");
    }
}