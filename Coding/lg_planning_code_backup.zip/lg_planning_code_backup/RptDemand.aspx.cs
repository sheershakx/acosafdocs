﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using Inventory;

public partial class RptDemand : System.Web.UI.Page
{

    private void GetData()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select ROW_NUMBER() OVER(ORDER BY P.Name ASC) AS Row,P.Name as PName ,Place ,WardNo,L.Name as LName,H.Name as HName,
                                    A.Name as AName,E.Name EName,P.BudgetAmount,P.StartDate ,
                                    P.EndDate 
                                     from PlanningDemand P
                                    inner join PlanSubject L
                                    on P.PlanSubject=L.Id
                                    inner join PlanHead H
                                    on P.PlanHead=H.Id
                                    inner join PlanSubHead A
                                    on P.PlanSubHead = A.Id 
                                    inner join PlanSource E
                                    on E.Id=P.PlanSource where P.FiscalYear='" + drphead.SelectedValue + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptTable.DataSource = ds;
            rptTable.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }

        //        btntype = @"<a  href='javascript:window.open('Format/TippaniNew.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-primary btn-sm'>Tippani</a>
        //                                         &nbsp;
        //                                          <a  href='javascript:window.open('Format/Aggrement.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-danger btn-sm'>Aggrement</a>
        //                                          &nbsp;
        //                                          <a  href='javascript:window.open('Format/AggrementWorder.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-warning btn-sm'>WorkOrder</a>
        //                                        &nbsp;";



    }



    protected void btnexport_Click(object sender, EventArgs e)
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=Demand.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        Response.Output.Write(Request.Form[hfGridHtml.UniqueID]);
        Response.Flush();
        Response.End();
    }

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            Class1 a = new Class1();
            a.loadcomboForFiscalyear(drphead, "select * from Fiscalyear order by Id desc ", "FiscalYear", "FiscalYear");

            this.Button1.Attributes.Add("onclick", "javascript:printDiv('printme')");
        }
    }
    protected void btnshow_Click(object sender, EventArgs e)
    {
        GetData();
    }
}