﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class ViewGenerateTippani : System.Web.UI.Page
{


    private void GetData()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select P.Name as PlanningName,U.Name as SamitiName,T.StartDate,T.EndDate from TipaniSummary T
                                            inner join PlanningDetail P
                                            on T.PlaningID=P.PlanningCode
                                            inner join Samiti U
                                            on T.SamitiId=U.SamitiCode", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptTable.DataSource = ds;
            rptTable.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        GetData();
    }
}