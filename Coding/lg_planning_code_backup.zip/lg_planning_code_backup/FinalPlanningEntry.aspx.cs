﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using Inventory;
using System.Data;

public partial class FinalPlanningEntry : System.Web.UI.Page
{


    private void GetData()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from Planning where Id="+ drplanning.SelectedValue+ "", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptTable.DataSource = ds;
            rptTable.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }

        //        btntype = @"<a  href='javascript:window.open('Format/TippaniNew.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-primary btn-sm'>Tippani</a>
        //                                         &nbsp;
        //                                          <a  href='javascript:window.open('Format/Aggrement.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-danger btn-sm'>Aggrement</a>
        //                                          &nbsp;
        //                                          <a  href='javascript:window.open('Format/AggrementWorder.aspx?Id=<%# Eval('Id')%>', 'yourWindowName', 'width=900,height=700,Left=200');' class='btn btn-warning btn-sm'>WorkOrder</a>
        //                                        &nbsp;";



    }


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            show.Visible = false;
        
            Class1 a = new Class1();

            a.loadcombo(drplanning, @"Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning where [Process]=1", "Name", "Id");
        }
    }
    protected void drplanning_SelectedIndexChanged(object sender, EventArgs e)
    {
        show.Visible = true;
        GetData();
        Class1 a = new Class1();
        a.loadgrid(GridView1, @"select N'अवस्था'=case when EntryType=1 then N'लगत' else N'कार्य सम्पन' end ,Qty as N'थान'
,Unit as N'इकए' ,Remark as N'कैफियत' from FinalEntry where PlanningId=" + drplanning.SelectedValue + "");
    }



    private void FxClear()
    {
        txtremark.Text = "";
        txtunit.Text = "";
        txtqty.Text = "";
       
      
        lblerror.Text = "";
        Session["ID"] = "";
        btnsave.Text = "Save";
        btndelete.Enabled = false;
        Class1 a = new Class1();
        a.loadgrid(GridView1, @"select EntryType,Qty,Unit,Remark from FinalEntry where PlanningId=" + drplanning.SelectedValue +"");
    }



    private void FxDelete()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("usp_FinalEntryDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = drplanning.SelectedValue;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            FxClear();

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }


    }

    private void FxUpdate()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("usp_FinalEntryUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@PlanningId", SqlDbType.NVarChar, 100).Value = drplanning.SelectedValue;

        cmd.Parameters.Add("@EntryType", SqlDbType.NVarChar, 200).Value = drpplanstatus.SelectedValue;
        cmd.Parameters.Add("@Qty", SqlDbType.VarChar, 200).Value = txtqty.Text;
        cmd.Parameters.Add("@Unit", SqlDbType.VarChar, 40).Value = txtunit.Text;
        cmd.Parameters.Add("@Remark", SqlDbType.VarChar, 40).Value = txtremark.Text;


        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Updated Successfully !')", true);


        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }


    private void FxSave()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("usp_FinalEntryInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanningId", SqlDbType.NVarChar, 100).Value = drplanning.SelectedValue;

        cmd.Parameters.Add("@EntryType", SqlDbType.NVarChar, 200).Value = drpplanstatus.SelectedValue;
        cmd.Parameters.Add("@Qty", SqlDbType.VarChar, 200).Value = txtqty.Text;
        cmd.Parameters.Add("@Unit", SqlDbType.VarChar, 40).Value = txtunit.Text;
        cmd.Parameters.Add("@Remark", SqlDbType.VarChar, 40).Value = txtremark.Text;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }
    protected void btnsave_Click(object sender, EventArgs e)
    {

       
       

        if (btnsave.Text == "Save")
        {
            FxSave();
        }
        else if (btnsave.Text == "Update")
        {
            FxUpdate();

        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;
        Session["ID"] = row.Cells[1].Text;

        drpplanstatus.SelectedValue = row.Cells[1].Text;
        txtqty.Text = Server.HtmlDecode(row.Cells[2].Text);
        txtunit.Text = Server.HtmlDecode(row.Cells[3].Text);
        txtremark.Text = Server.HtmlDecode(row.Cells[4].Text);
        btnsave.Text = "Update";
        btndelete.Enabled = true;

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        FxClear();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        FxDelete();
    }

}