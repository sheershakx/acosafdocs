﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Costing_new : System.Web.UI.Page
{
    public static string guid = "";
    public static double workorder = 0;
    public static double costingtotal = 0;
    public static double sourcetotal = 0;
    public static double UsamitiTotal = 0;



    private double  FxGetcost(string guid)
    {

        // sql1 = "";



        string sql = @"select SUM(Total) as Total from dbo.CostEstimationTemp where [Guid]= '" + guid + "'";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    costingtotal = Convert.ToDouble(myreader["Total"].ToString());
                   // txtUsamiti.Text = myreader["Us"].ToString();
                   // txtcontigencyamount.Text = myreader["ContigencyAmount"].ToString();
                   // lblworkorder.Text = myreader["WorkOrderAmount"].ToString();



                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
            
        }
        return costingtotal;

    }


    private double FxGetsource(string guid)
    {

        // sql1 = "";



        string sql = @"select SUM(Amount) as Total from dbo.CostEstimationSourceTemp where [Guid]= '" + guid + "'";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    sourcetotal = Convert.ToDouble(myreader["Total"].ToString());
                    // txtUsamiti.Text = myreader["Us"].ToString();
                    // txtcontigencyamount.Text = myreader["ContigencyAmount"].ToString();
                    // lblworkorder.Text = myreader["WorkOrderAmount"].ToString();



                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();

        }
        return sourcetotal;

    }



    private void GetData()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"exec s_rptGetTotalcosting '" + guid + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptTable.DataSource = ds;
            rptTable.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }


    private void GetData11()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from PersonEntryDetail where Remark= '" + guid + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptperson.DataSource = ds;
            rptperson.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }


    private void GetData11live()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"select * from PersonEntryDetail where PlanningId= '" + drpplanning.SelectedValue + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptperson.DataSource = ds;
            rptperson.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }

    private void GetDataLive()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"exec s_rptGetTotalcostingLive '" + drpplanning.SelectedValue + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptTable.DataSource = ds;
            rptTable.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }

    private void GetData2()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"exec s_rptgetsourcetotal'" + guid + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptother.DataSource = ds;
            rptother.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }


    private void GetData2Live()
    {
        string constr = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cmd = new SqlCommand(@"exec s_rptgetsourcetotalLive'" + drpplanning.SelectedValue + "'", con);

        try
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            rptother.DataSource = ds;
            rptother.DataBind();
        }
        catch (Exception ex)
        {
            //...
        }
        finally
        {
            con.Close();
        }
    }


    private void FxCostAdd()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("usp_CostEstimationTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        //
        cmd.Parameters.Add("@Particular", SqlDbType.NVarChar, 440).Value = "ल.ई. जम्मा मूल्य";
        cmd.Parameters.Add("@Qty", SqlDbType.VarChar, 40).Value = "0";
        cmd.Parameters.Add("@Unit", SqlDbType.NVarChar, 140).Value = "0";
        cmd.Parameters.Add("@Rate", SqlDbType.VarChar, 40).Value = "0";
        //
        cmd.Parameters.Add("@Estimator", SqlDbType.NVarChar, 140).Value = drpcost.SelectedItem.Text;
        cmd.Parameters.Add("@Visitor", SqlDbType.VarChar, 40).Value =drpsite.SelectedItem.Text ;
        cmd.Parameters.Add("@Total", SqlDbType.VarChar, 40).Value =txttotal.Text;
       
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            costingtotal = costingtotal + Convert.ToDouble(txttotal.Text);
            txtwork.Text = costingtotal.ToString();
            txttotal.Text = "";
            //txtqty.Text = "";
            //txtrate.Text = "";
           // txttotal.Text = "";
            
            //lblcosting.Text = costingtotal.ToString();
            GetData();
            txtlagat.Text = costingtotal.ToString();
            txtwork.Text=costingtotal.ToString();
            lblworkorder.Text = "0.00";
            lbltotal.Text = costingtotal.ToString();
            txtUsamiti.Text = "0.00";
            txtcontigencyamount.Text = "0";
           // workorder = 
           
          //  txtcontigencyamount.Text = costingtotal.ToString();
           // Class1 a = new Class1();
           // a.loadgrid(GridView1, @"select Id as '#',Particular as 'विवरण',Qty as 'परिमाण',Unit as 'इकाई',Rate as 'दर',Total as 'जम्मा' from CostEstimationTemp where [Guid]='" + guid + "'");

            //double amount = 0;
            //for (int i = 0; i < GridView1.Rows.Count; i++)
            //{
            //    amount = amount + Convert.ToDouble(GridView1.Rows[i].Cells[6].Text);
            //    //  txttotalanugam.Text = Convert.ToDouble(GridView1.Rows[i].Cells[6].Text).ToString();

            //}
            //txttotalanugam.Text = amount.ToString();
            // FxClear();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
           // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void FxCostdel()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_CostEstimationTempDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = he1.Value;
        

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
          //  costingtotal = costingtotal + Convert.ToDouble(txttotal.Text);
            txtwork.Text = costingtotal.ToString();
            txttotal.Text = "";
            //txtqty.Text = "";
            //txtrate.Text = "";
            // txttotal.Text = "";

            //lblcosting.Text = costingtotal.ToString();
            GetData();
            txtlagat.Text = costingtotal.ToString();
            txtwork.Text = costingtotal.ToString();
            lblworkorder.Text = "0.00";
            lbltotal.Text = costingtotal.ToString();
            txtUsamiti.Text = "0.00";
            txtcontigencyamount.Text = "0";
            // workorder = 

            //  txtcontigencyamount.Text = costingtotal.ToString();
            // Class1 a = new Class1();
            // a.loadgrid(GridView1, @"select Id as '#',Particular as 'विवरण',Qty as 'परिमाण',Unit as 'इकाई',Rate as 'दर',Total as 'जम्मा' from CostEstimationTemp where [Guid]='" + guid + "'");

            //double amount = 0;
            //for (int i = 0; i < GridView1.Rows.Count; i++)
            //{
            //    amount = amount + Convert.ToDouble(GridView1.Rows[i].Cells[6].Text);
            //    //  txttotalanugam.Text = Convert.ToDouble(GridView1.Rows[i].Cells[6].Text).ToString();

            //}
            //txttotalanugam.Text = amount.ToString();
            // FxClear();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }



    private void FxCostSourceAdd()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_CostEstimationSourceTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@Source", SqlDbType.VarChar, 40).Value = drpcostsource.SelectedValue;
        cmd.Parameters.Add("@Amount", SqlDbType.VarChar, 40).Value = txtcostsourceamount.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

            sourcetotal = sourcetotal + Convert.ToDouble(txtcostsourceamount.Text);
           
            if (drpcostsource.SelectedValue == "7")
            {
                UsamitiTotal = UsamitiTotal + Convert.ToDouble(txtcostsourceamount.Text);
            }
            if (drpcostsource.SelectedValue == "8")
            {
                UsamitiTotal = UsamitiTotal + Convert.ToDouble(txtcostsourceamount.Text);
            }

            txtUsamiti.Text = UsamitiTotal.ToString();

            lblworkorder.Text = (Convert.ToDouble(lbltotal.Text) - UsamitiTotal - Convert.ToDouble(txtcontigencyamount.Text)).ToString();

            drpcostsource.Text = "";
            txtcostsourceamount.Text = "";
            GetData2();

          //  view1.Visible = true;
           // Class1 a = new Class1();
//            a.loadgrid(GridView2, @"select C.Id as '#',P.Name as 'स्रोतको विवरण',Amount as 'रकम' from CostEstimationSourceTemp C
//                                    inner join CostSource P
//                                    on C.Source=P.Id where [Guid]='" + guid + "'");



            //double amount = 0;
            //for (int i = 0; i < GridView2.Rows.Count; i++)
            //{
            //    amount = amount + Convert.ToDouble(GridView2.Rows[i].Cells[3].Text);
            //    //  txttotalanugam.Text = Convert.ToDouble(GridView1.Rows[i].Cells[6].Text).ToString();

            //}
            //txttotalshrotamount.Text = amount.ToString();


            // FxClear();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
           // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }



    private void FxCostPersonAdd()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PersonEntryDetailInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 40).Value = "";
        cmd.Parameters.Add("@PersonId", SqlDbType.VarChar, 40).Value = drpsiteperson1.SelectedValue;
        cmd.Parameters.Add("@PersonId2", SqlDbType.VarChar, 40).Value = drpsiteperson2.SelectedValue;
        cmd.Parameters.Add("@Remark", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

           
           
           
            GetData11();

            //  view1.Visible = true;
            // Class1 a = new Class1();
            //            a.loadgrid(GridView2, @"select C.Id as '#',P.Name as 'स्रोतको विवरण',Amount as 'रकम' from CostEstimationSourceTemp C
            //                                    inner join CostSource P
            //                                    on C.Source=P.Id where [Guid]='" + guid + "'");



            //double amount = 0;
            //for (int i = 0; i < GridView2.Rows.Count; i++)
            //{
            //    amount = amount + Convert.ToDouble(GridView2.Rows[i].Cells[3].Text);
            //    //  txttotalanugam.Text = Convert.ToDouble(GridView1.Rows[i].Cells[6].Text).ToString();

            //}
            //txttotalshrotamount.Text = amount.ToString();


            // FxClear();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void FxCostPersonEdit()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PersonEntryDetailUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = he11.Value;
        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 40).Value = "";
        cmd.Parameters.Add("@PersonId", SqlDbType.VarChar, 40).Value = drpsiteperson1.SelectedValue;
        cmd.Parameters.Add("@PersonId2", SqlDbType.VarChar, 40).Value = drpsiteperson2.SelectedValue;
        cmd.Parameters.Add("@Remark", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            GetData11();

            //  GetData2();

            //  view1.Visible = true;
            // Class1 a = new Class1();
            //            a.loadgrid(GridView2, @"select C.Id as '#',P.Name as 'स्रोतको विवरण',Amount as 'रकम' from CostEstimationSourceTemp C
            //                                    inner join CostSource P
            //                                    on C.Source=P.Id where [Guid]='" + guid + "'");



            //double amount = 0;
            //for (int i = 0; i < GridView2.Rows.Count; i++)
            //{
            //    amount = amount + Convert.ToDouble(GridView2.Rows[i].Cells[3].Text);
            //    //  txttotalanugam.Text = Convert.ToDouble(GridView1.Rows[i].Cells[6].Text).ToString();

            //}
            //txttotalshrotamount.Text = amount.ToString();


            // FxClear();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }

    private void FxCostPersondelete()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PersonEntryDetailDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = he11.Value;
       

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            GetData11();


            //  GetData2();

            //  view1.Visible = true;
            // Class1 a = new Class1();
            //            a.loadgrid(GridView2, @"select C.Id as '#',P.Name as 'स्रोतको विवरण',Amount as 'रकम' from CostEstimationSourceTemp C
            //                                    inner join CostSource P
            //                                    on C.Source=P.Id where [Guid]='" + guid + "'");



            //double amount = 0;
            //for (int i = 0; i < GridView2.Rows.Count; i++)
            //{
            //    amount = amount + Convert.ToDouble(GridView2.Rows[i].Cells[3].Text);
            //    //  txttotalanugam.Text = Convert.ToDouble(GridView1.Rows[i].Cells[6].Text).ToString();

            //}
            //txttotalshrotamount.Text = amount.ToString();


            // FxClear();
            //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void FxCostSourcedel()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_CostEstimationSourceTempDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = he2.Value;
        

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

            sourcetotal = sourcetotal + Convert.ToDouble(txtcostsourceamount.Text);

            if (drpcostsource.SelectedValue == "7")
            {
                UsamitiTotal = UsamitiTotal + Convert.ToDouble(txtcostsourceamount.Text);
            }
            if (drpcostsource.SelectedValue == "8")
            {
                UsamitiTotal = UsamitiTotal + Convert.ToDouble(txtcostsourceamount.Text);
            }

            txtUsamiti.Text = UsamitiTotal.ToString();

            lblworkorder.Text = (Convert.ToDouble(lbltotal.Text) - UsamitiTotal - Convert.ToDouble(txtcontigencyamount.Text)).ToString();

            drpcostsource.Text = "";
            txtcostsourceamount.Text = "";
            GetData2();

          



        }
        catch (Exception ex)
        {
            // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           view.Visible = false;
          //  view1.Visible = false;
        //    btnproceed.Visible = false;
            //txttargetdalit.Attributes.Add("Type","Number");
            //txttargetfemale.Attributes.Add("Type","Number");
            //txttargethouse.Attributes.Add("Type","Number");
            //txttargetjanajati.Attributes.Add("Type","Number");
            //txttargetmadhesi.Attributes.Add("Type","Number");
            //txttargetother.Attributes.Add("Type","Number");
            //txttargettotal.Attributes.Add("Type","Number");
            //txttotalmemeber.Attributes.Add("Type", "Number");
            // targettotal =Convert.ToDouble(txttargettotal.Text);
            Class1 a = new Class1();
            a.loadcomboForFiscalyear(drpfiscalyear, "select * from Fiscalyear order by Id desc ", "FiscalYear", "FiscalYear");
            a.loadcombo(drpwardno, "select * from WardName order by Id asc ", "Name", "Name");
           // guid = System.Guid.NewGuid().ToString();
            a.loadcombo(drpcostsource, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from CostSource", "Name", "ID");

            drpfiscalyear_SelectedIndexChanged(sender, e);
            //txttargettotal.Text = "56";
            //a.loadcombo(drpsubject, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from Plansubject", "Name", "ID");
            // a.loadgrid(GridView1, "Select * from planHead");
            // a.loadgrid(GridView2, "Select * from planHead");
           // a.loadcombo(drpplanning, @"select P.ID,(convert(nvarchar(10),P.ID) + ' - ' + Name) as Name from Planning P
                                    //  ", "Name", "Id");
            a.loadcombo(drpsiteperson1, "select * from dbo.Cost_PersonDetail where PersonType=1", "Name", "Id");
            a.loadcombo(drpsiteperson2, "select *  from Cost_PersonDetail where PersonType=2", "Name", "Id");
            costingtotal = 0;
            UsamitiTotal = 0;

            if (drpplanning.Items.Count > 1)
            {
                //btnproceed.Visible = true;
            }
            else
            {
              //  btnproceed.Visible = false;
            }

        }
    }

    protected void btnproceed1_Click(object sender, EventArgs e)
    {
        Class1 a = new Class1();
        guid = System.Guid.NewGuid().ToString();
        a.loadcombo(drpcostsource, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from CostSource", "Name", "ID");
        view.Visible = true;

        lbltotal.Text = "0.00";
        txtUsamiti.Text = "0.00";
        txtcontigencyamount.Text = "0.00";
        lblworkorder.Text = "0.00";

        GetDataLive();
        GetData2Live();

        GetData11();
        GetData11live();
       // GetData1Live();
        FxGetTotal(drpplanning.SelectedValue);

    }

    protected void btncosting_Click(object sender, EventArgs e)
    {
        

        if (h1.Value == "Save")
        {

            FxCostAdd();
        }
        else if (h1.Value == "Edit")
        {
          //  FxUpdateOtherDetail();

        }

        else if (h1.Value == "Delete")
        {
            FxCostdel();
           // FxDeleteOtherDetail();
        }

    }


    private void FxCostSaveAll()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_CostEstimationAll", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;
        cmd.Parameters.Add("@costTotal", SqlDbType.VarChar, 40).Value = lbltotal.Text;
        cmd.Parameters.Add("@US", SqlDbType.VarChar, 40).Value = txtUsamiti.Text;
        cmd.Parameters.Add("@WorkOrderAmount", SqlDbType.VarChar, 40).Value = lblworkorder.Text;
        cmd.Parameters.Add("@ContigencyAmount", SqlDbType.VarChar, 40).Value = txtcontigencyamount.Text;
        cmd.Parameters.Add("@ContigencyPercent", SqlDbType.VarChar, 40).Value = txtcontigencypercent.Text;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
           // FxClearAll();
            rptTable.DataSource = null;
            rptTable.DataBind();
            rptother.DataSource = null;
            rptother.DataBind();
            // FxClear();
            txtwork.Text = "";
            lblworkorder.Text = "0.00";
            txtcontigencyamount.Text = "0";
            txtUsamiti.Text = "0.00";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
           // lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    protected void btnsource_Click(object sender, EventArgs e)
    {
        



        if (h2.Value == "Save")
        {

            FxCostSourceAdd();
        }
        else if (h2.Value == "Edit")
        {
           // FxUpdateOtherDetail();

        }

        else if (h2.Value == "Delete")
        {
            FxCostSourcedel();
           // FxDeleteOtherDetail();
        }

    }


    protected void btnpersonadd_Click(object sender, EventArgs e)
    {




        if (h11.Value == "Save")
        {

            FxCostPersonAdd();
        }
        else if (h11.Value == "Edit")
        {
            FxCostPersonEdit();

        }

        else if (h11.Value == "Delete")
        {
            FxCostPersondelete();
           // FxDeleteOtherDetail();
        }

    }



    


    protected void btnproceed_Click(object sender, EventArgs e)
    {
        
      
       //if ( FxGetcost(guid) != FxGetsource(guid) )
       // {
       //   ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Cost Estimation Amount not Equal to Source Details  !');", true);
       //}

       //new commtned
        if (costingtotal == 0)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('No data !');", true);
        }
        else
        {

            FxCostSaveAll();
            costingtotal = 0;
            sourcetotal = 0;
            UsamitiTotal = 0;
            //view1.Visible = false;
            view.Visible = false;
            btnproceed.Visible = false;
        }
    }

    





    private void FxPlanningDetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning where Id= " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {
                    lbldetail.Text = " स्थान : " + myreader["Place"].ToString() + ",     वडा नं. :" + myreader["WardNo"].ToString() + ",   आर्थिक बर्ष : " + myreader["FiscalYear"].ToString();

                    txtbudgetamount.Text = myreader["BudgetAmount"].ToString();
                    txtbudgetamount1.Text = myreader["BudgetAmount"].ToString();

                    Class1 a = new Class1();
                    a.loadcombo(drpcost, " Select ID,CostEstimator as Name  from CostEstimator", "Name", "ID");
                    a.loadcombo(drpsite, " Select  ID,SiteVisitor as Name  from SiteVisitor", "Name", "ID");
                    
                    //   txtpplace.Text = myreader["Place"].ToString();
                    //  txtpward.Text = myreader["WardNo"].ToString();
                    //  txtfiscalyear.Text = myreader["FiscalYear"].ToString();
                    //   txtsamitiname.Text = myreader["Name"].ToString() + " उपभोक्ता समिति";
                   
                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

    private void FxGetTotal(string id)
    {

        // sql1 = "";



        string sql = @"select * from CostEstimation where PlanningID= '" + id + "'";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    lbltotal.Text = myreader["costTotal"].ToString();
                     txtUsamiti.Text = myreader["Us"].ToString();
                     txtcontigencyamount.Text = myreader["ContigencyAmount"].ToString();
                     lblworkorder.Text = myreader["WorkOrderAmount"].ToString();



                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }
    protected void drpplanning_SelectedIndexChanged(object sender, EventArgs e)
    {
        FxPlanningDetail(drpplanning.SelectedValue);
    }
    protected void txtcontigencyamount_TextChanged(object sender, EventArgs e)
    {

    }


    protected void drpfiscalyear_SelectedIndexChanged(object sender, EventArgs e)
    {
        Class1 a = new Class1();
        a.loadcombo(drpplanning, @"Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning where [Process]=1 and FiscalYear='" + drpfiscalyear.SelectedValue + "' and WardNo='" + drpwardno.SelectedValue + "'", "Name", "Id");
    }
    protected void txtcontigencyamount_TextChanged1(object sender, EventArgs e)
    {
        double total = 0;
        double total1 = Convert.ToDouble(lbltotal.Text);
        double total2 = Convert.ToDouble(txtUsamiti.Text);
        double total3 = Convert.ToDouble(txtcontigencypercent.Text);
        //added by sheershak___input percentage instead of comtingeny amomunt and calculate the amount through inputed percentage
        double total3_perc = (total3 / 100) * Convert.ToDouble(lblworkorder.Text);
        txtcontigencyamount.Text = Convert.ToString(total3_perc);
        //  double total4 = total1 - total2 - total3;
        double total4 = total1 - total2 - total3_perc;
        lblworkorder.Text = total4.ToString();

    }
}


