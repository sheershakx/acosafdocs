﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            lblfooter.Text = Session["OfficeName"].ToString();
            lblcompanyname.Text = Session["OfficeName"].ToString();
            
            lblname.Text = Session["@Name"].ToString();

            FxGetNotification();
        }
    }



    

    private void FxGetNotification()
    {
        string l = "";
        string sql = @"select [Subject] from MessageTable where Receiver='" + Session["USERNAME"].ToString() + "'";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    
                    l += @"<li><a href='./notification.aspx' target=''  class='clearfix'   > ";
                    l += myreader["Subject"];
                    l += @" </a></li>";
                   


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            Literal1.Text = l;
            myconn.Close();
        }

    
    
    }
}
