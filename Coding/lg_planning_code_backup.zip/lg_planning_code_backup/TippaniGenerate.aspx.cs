﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;

public partial class TippaniGenerate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
            Class1 a = new Class1();
            a.loadgrid(GridView1, @"select T.Id, P.Name as PlanningName,U.Name as SamitiName,T.StartDate,T.EndDate from TipaniSummary T
                                    inner join PlanningDetail P
                                    on T.PlaningID=P.PlanningCode
                                    inner join Samiti U
                                    on T.SamitiId=U.SamitiCode");





        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;

        Session["IDPrint"] = row.Cells[1].Text;
        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "newWindow", "window.open('./Format/TippaniFormat.aspx','_blank','top=0,left=250,menubar=no,toolbar=no,location=no, resizable=yes,height=700,width=700,status=no,scrollbars=no,minimizable=no,maxmizable=no,resizable=0,titlebar=no;');", true);
    }
}