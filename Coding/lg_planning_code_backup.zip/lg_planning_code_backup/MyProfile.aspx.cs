﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;
using System.Web.Script.Serialization;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class MyProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

       // FxInsert();
        FxGet();
    }



    private void FxInsert()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        

        HttpWebRequest http = (HttpWebRequest)HttpWebRequest.Create("http://hrservice.nepcloud.com/api/employee/");
        HttpWebResponse response = (HttpWebResponse)http.GetResponse();
        using (StreamReader sr = new StreamReader(response.GetResponseStream()))
        {
            string responseJson = sr.ReadToEnd();
            JavaScriptSerializer js = new JavaScriptSerializer();
            dynamic data = js.Deserialize(responseJson, typeof(object));


            foreach (var row in data)
            {
              //  string code1 = row["FirstName"];

              //  Label1.Text = code1;
               
                // insert here
                SqlCommand cmd = new SqlCommand("sp_StaffInsertALL", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@EmployeeCode", SqlDbType.VarChar, 40).Value = row["EmployeeCode"];
                cmd.Parameters.Add("@FirstName", SqlDbType.VarChar, 40).Value = row["FirstName"];
                cmd.Parameters.Add("@MiddleName", SqlDbType.VarChar, 40).Value = row["MiddleName"];
                cmd.Parameters.Add("@LastName", SqlDbType.VarChar, 40).Value = row["LastName"];
                cmd.Parameters.Add("@MobileNo", SqlDbType.VarChar, 40).Value = row["MobileNo"];
                cmd.Parameters.Add("@Email", SqlDbType.VarChar, 40).Value = row["Email"];
                cmd.Parameters.Add("@Department", SqlDbType.VarChar, 40).Value = row["Department"];
                cmd.Parameters.Add("@Designation", SqlDbType.VarChar, 40).Value = row["Designation"];
                cmd.Parameters.Add("@Grade", SqlDbType.VarChar, 40).Value = row["Grade"];
                cmd.Parameters.Add("@Description", SqlDbType.VarChar, 40).Value = "test";

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                }
                finally
                {
                    con.Close();



                }
    

                // finished



            }

        }




        
    
    }



    private void FxGet()
    {
        try
        {
            string url = "http://hrservice.nepcloud.com/api/employee/" + Session["USERNAME"].ToString();
            HttpWebRequest http = (HttpWebRequest)HttpWebRequest.Create(url);
            HttpWebResponse response = (HttpWebResponse)http.GetResponse();
            using (StreamReader sr = new StreamReader(response.GetResponseStream()))
            {
                string responseJson = sr.ReadToEnd();
                JavaScriptSerializer js = new JavaScriptSerializer();
                dynamic data = js.Deserialize(responseJson, typeof(object));


                foreach (var row in data)
                {
                   // string code1 = row["FirstName"];
                    lblcode.Text = row["EmployeeCode"];
                     lblname.Text = row["FirstName"] + " " +  row["MiddleName"] +  " " + row["LastName"];
                     lblmobile.Text = row["MobileNo"];
                     lblemail.Text = row["Email"];
                     lbldepartment.Text = row["Department"];
                     lbldesignation.Text = row["Designation"];
                     lblgrade.Text = row["Grade"];

                    

                }

            }
        }
        catch (Exception ex)
        {
        
        }
    
    }

}