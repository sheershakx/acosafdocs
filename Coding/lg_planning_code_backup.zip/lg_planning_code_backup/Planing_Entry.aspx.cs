﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Planing_Entry : System.Web.UI.Page
{
    public static string guid = "";

    private void FxGetPlannigDetail(string Id)
    {

        // sql1 = "";



        string sql = @"select * from Planning where Id=" + Id +"";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    Class1 a = new Class1();
                    drpsubject.SelectedValue = myreader["PlanSubject"].ToString();
                    a.loadcombo(drpHead, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from PlanHead where [SID]=" + drpsubject.SelectedValue + "", "Name", "Id");
                    a.loadcombo(drpsubhead, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from PlanSubHead where HID =" + myreader["PlanHead"].ToString() + "", "Name", "Id");

                    txtbudget.Text = myreader["BudgetAmount"].ToString();
                    txtendate.Text = myreader["EndDate"].ToString();
                    txtplace.Text = myreader["Place"].ToString();
                    txtplanname.Text = myreader["Name"].ToString();
                    txtremarks.Text = myreader["Remarks"].ToString();
                    txtstartdate.Text = myreader["StartDate"].ToString();
                    drplevel.SelectedValue = myreader["PlanLevelCode"].ToString();
                    drpfiscalyear.SelectedValue = myreader["FiscalYear"].ToString();
                    drpHead.SelectedValue = myreader["PlanHead"].ToString();
                    drpProcess.SelectedValue = myreader["Process"].ToString();
                    drpsource.SelectedValue = myreader["PlanSource"].ToString();
                    drpstatus.SelectedValue = myreader["Status"].ToString();
                    drpsubhead.SelectedValue = myreader["PlanSubHead"].ToString();
                    drpward.SelectedValue = myreader["WardNo"].ToString();
                    txttargetqty.Text = myreader["TargetQty"].ToString();
                    txttargetunit.Text = myreader["TargetUnit"].ToString();
                   

                   // lblcompanyname.Text = myreader["CompanyName"].ToString();
                   // Session["CompanyName"] = myreader["CompanyName"].ToString();
                    // string logo = myreader["LogoPath"].ToString();
                    // lbldate.Text = System.DateTime.Now.ToString();


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }



    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Class1 a = new Class1();

      
          

           // txtbudget.Attributes.Add("Type", "Number");
            guid = System.Guid.NewGuid().ToString();
            a.loadcombo(drpsubject, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from Plansubject", "Name", "ID");

            a.loadcomboForFiscalyear(drpfiscalyear, "Select Id,(FiscalYear) as Name  from FiscalYear order by Id desc", "Name", "Name");

           // a.loadcombo(drpHead, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from PlanHead", "Name", "Id");

          //  a.loadcombo(drpsubhead, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from PlanSubHead", "Name", "Id");

          //  a.loadcombo(drpsubhead, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from PlanSource", "Name", "Id");
            //a.loadcombo(dr, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from PlanBiniyojan", "Name", "Id");

            a.loadcombo(drpsource, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from PlanSource", "Name", "Id");

            a.loadcombo(drplevel, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from PlanBiniyojan", "Name", "Id");

            a.loadcombo(drpProcess, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from ImplementProcess", "Name", "Id");

            a.loadcombo(drpward, "Select Id,(Name) as Name  from WardName", "Name", "Name");

          //  a.loadcombo(drp, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from ImplementProcess", "Name", "Id");


            a.loadgrid(GridView1, @"select P.Id as 'योजना नं',P.Name as 'योजनाको नाम '  ,Place AS  'ठेगाना',WardNo AS 'वडा नं',L.Name as 'विषयगत क्षेत्र',H.Name as 'शिर्षक',
                                    A.Name as 'उपशिर्षक',E.Name as 'स्रोत',P.BudgetAmount AS 'बजेट रकम',P.StartDate AS 'शुरु मिति',
                                    P.EndDate AS 'सम्पन्न मिति' 
                                     from Planning P
                                    inner join PlanSubject L
                                    on P.PlanSubject=L.Id
                                    inner join PlanHead H
                                    on P.PlanHead=H.Id
                                    inner join PlanSubHead A
                                    on P.PlanSubHead = A.Id 
                                    inner join PlanSource E
                                    on E.Id=P.PlanSource");

        }
    }


    private void FxClear()
    {


        


       // txtremarks.Text = "";
       
        Session["ID"] = "";
        drpsubject.SelectedValue = "";
        drpstatus.SelectedValue = "";
        txtbudget.Text = "";
        txtendate.Text = "";
        txtplace.Text = "";
        txtplanname.Text = "";
        txtremarks.Text = "";
        txtstartdate.Text = "";
        drplevel.SelectedValue = "";
        drpProcess.SelectedValue = "";
        drpsource.SelectedValue = "";
        drpsubject.SelectedValue = "";
        drpsubhead.SelectedValue = "";
        drpHead.SelectedValue = "";
        drpward.SelectedValue = "";
        txttargetqty.Text = "";
        txttargetunit.Text = "";
       // drpfiscalyear.SelectedValue = "";
        

        btnsave.Text = "Save";
        btndelete.Enabled = false;
        Class1 a = new Class1();
        a.loadgrid(GridView1, @"select P.Id as 'योजना नं',P.Name as 'योजनाको नाम '  ,Place AS  'ठेगाना',WardNo AS 'वडा नं',L.Name as 'विषयगत क्षेत्र',H.Name as 'शिर्षक',
                                    A.Name as 'उपशिर्षक',E.Name as 'स्रोत',P.BudgetAmount AS 'बजेट रकम',P.StartDate AS 'शुरु मिति',
                                    P.EndDate AS 'सम्पन्न मिति' 
                                     from Planning P
                                    inner join PlanSubject L
                                    on P.PlanSubject=L.Id
                                    inner join PlanHead H
                                    on P.PlanHead=H.Id
                                    inner join PlanSubHead A
                                    on P.PlanSubHead = A.Id 
                                    inner join PlanSource E
                                    on E.Id=P.PlanSource where P.FiscalYear='" + drpfiscalyear.SelectedValue + "'");

    }



    private void FxDelete()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_PlanningDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            FxClear();

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }

    private void FxUpdate()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanningUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        cmd.Parameters.Add("@PlanCode", SqlDbType.VarChar, 40).Value = "11";
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 200).Value = txtplanname.Text;
        cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 40).Value = txtplace.Text;
        cmd.Parameters.Add("@WardNo", SqlDbType.VarChar, 40).Value = drpward.SelectedValue;
        cmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 40).Value = drpfiscalyear.SelectedValue;
        cmd.Parameters.Add("@PlanSubject", SqlDbType.VarChar, 40).Value = drpsubject.SelectedValue;
        cmd.Parameters.Add("@PlanHead", SqlDbType.VarChar, 40).Value = drpHead.SelectedValue;
        cmd.Parameters.Add("@PlanSubHead", SqlDbType.VarChar, 40).Value = drpsubhead.SelectedValue;
        cmd.Parameters.Add("@PlanSource", SqlDbType.VarChar, 40).Value = drpsource.SelectedValue;
        cmd.Parameters.Add("@PlanLevelCode", SqlDbType.VarChar, 40).Value = drplevel.SelectedValue;
        cmd.Parameters.Add("@BudgetAmount", SqlDbType.VarChar, 40).Value = txtbudget.Text;
        cmd.Parameters.Add("@StartDate", SqlDbType.VarChar, 40).Value = txtstartdate.Text;
        cmd.Parameters.Add("@EndDate", SqlDbType.VarChar, 40).Value = txtendate.Text;
        cmd.Parameters.Add("@Remarks", SqlDbType.NVarChar, 440).Value = txtremarks.Text;
        cmd.Parameters.Add("@Process", SqlDbType.VarChar, 40).Value = drpProcess.SelectedValue;
        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 40).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OfficeId", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();
        cmd.Parameters.Add("@EntryDate", SqlDbType.VarChar, 40).Value = "2018-01-01";
        cmd.Parameters.Add("@TargetQty", SqlDbType.NVarChar, 40).Value = txttargetqty.Text;
        cmd.Parameters.Add("@TargetUnit", SqlDbType.NVarChar, 40).Value = txttargetunit.Text;
        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Updated Successfully !')", true);


        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }


    private void FxSave()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanningInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@PlanCode", SqlDbType.VarChar, 40).Value = System.Guid.NewGuid().ToString();
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 300).Value = txtplanname.Text;
        cmd.Parameters.Add("@Place", SqlDbType.NVarChar, 300).Value = txtplace.Text;
        cmd.Parameters.Add("@WardNo", SqlDbType.NVarChar, 40).Value = drpward.SelectedValue;
        cmd.Parameters.Add("@FiscalYear", SqlDbType.NVarChar, 40).Value = drpfiscalyear.SelectedValue;
        cmd.Parameters.Add("@PlanSubject", SqlDbType.NVarChar, 40).Value = drpsubject.SelectedValue;
        cmd.Parameters.Add("@PlanHead", SqlDbType.NVarChar, 300).Value = drpHead.SelectedValue;
        cmd.Parameters.Add("@PlanSubHead", SqlDbType.NVarChar, 40).Value = drpsubhead.SelectedValue;
        cmd.Parameters.Add("@PlanSource", SqlDbType.NVarChar, 40).Value = drpsource.SelectedValue;
        cmd.Parameters.Add("@PlanLevelCode", SqlDbType.NVarChar, 40).Value = drplevel.SelectedValue;
        cmd.Parameters.Add("@BudgetAmount", SqlDbType.NVarChar, 40).Value = txtbudget.Text;
        cmd.Parameters.Add("@StartDate", SqlDbType.NVarChar, 40).Value = txtstartdate.Text;
        cmd.Parameters.Add("@EndDate", SqlDbType.NVarChar, 40).Value = txtendate.Text;
        cmd.Parameters.Add("@Remarks", SqlDbType.NVarChar, 40).Value = txtremarks.Text;
        cmd.Parameters.Add("@Process", SqlDbType.NVarChar, 40).Value = drpProcess.SelectedValue;
        cmd.Parameters.Add("@Status", SqlDbType.NVarChar, 40).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OfficeId", SqlDbType.NVarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.NVarChar, 40).Value = Session["USERNAME"].ToString();
        cmd.Parameters.Add("@EntryDate", SqlDbType.NVarChar, 40).Value = "2018-01-01";
        cmd.Parameters.Add("@TargetQty", SqlDbType.NVarChar, 40).Value = txttargetqty.Text;
        cmd.Parameters.Add("@TargetUnit", SqlDbType.NVarChar, 40).Value = txttargetunit.Text;

      //  cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !');", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (drpward.SelectedValue == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Select Ward No !')", true);
            drpward.Focus();
            return;
        }
        if (drpfiscalyear.SelectedValue == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Select Fiscal Year !')", true);
            drpfiscalyear.Focus();
            return;
        }
        if (drpsubject.SelectedValue == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Select Plan Subject Area !')", true);
            drpsubject.Focus();
            return;
        }
        if (drpHead.SelectedValue == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Select Plan Head !')", true);
            drpHead.Focus();
            return;
        }
        if (drpsubhead.SelectedValue == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Select Plan SubHead !')", true);
            drpsubhead.Focus();
            return;
        }
        if (drpsource.SelectedValue == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Select Plan Source !')", true);
            drpsource.Focus();
            return;
        }
        if (drplevel.SelectedValue == "0")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Select Plan Level !')", true);
            drplevel.Focus();
            return;
        }
        if (drpProcess.SelectedValue == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Select Plan Process !')", true);
            drpProcess.Focus();
            return;
        }
        if (drpstatus.SelectedValue == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Select Plan Status !')", true);
            drpstatus.Focus();
            return;
        }

        if (btnsave.Text == "Save")
        {

            FxSave();
        }
        else if (btnsave.Text == "Update")
        {
            FxUpdate();
            // FxUpdate();

        }
    }



    // ikai modal Save button OnClick method call
   


  
    
    

   


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;
        Session["ID"] = row.Cells[1].Text;
        FxGetPlannigDetail(Session["ID"].ToString());
       
       // txtremarks.Text = Server.HtmlDecode(row.Cells[5].Text);
        btnsave.Text = "Update";
        btndelete.Enabled = true;

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        FxClear();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        
   
        
        FxDelete();
    }
    protected void drpsubject_SelectedIndexChanged(object sender, EventArgs e)
    {
        Page.ClientScript.RegisterStartupScript(this.GetType(), "CallMyFunction", "nepdate()", true);

        Class1 a = new Class1();
        a.loadcombo(drpHead, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from PlanHead where [SID]=" + drpsubject.SelectedValue +"", "Name", "Id");
    }
    protected void drpHead_SelectedIndexChanged(object sender, EventArgs e)
    {
        Class1 a = new Class1();
        a.loadcombo(drpsubhead, "Select Id,(convert(nvarchar(10),Id) + ' - ' + Name) as Name  from PlanSubHead where HID =" + drpHead.SelectedValue + "", "Name", "Id");
    }
    protected void drpsubhead_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void drpfiscalyear_SelectedIndexChanged(object sender, EventArgs e)
    {
        Class1 a = new Class1();
        a.loadgrid(GridView1, @"select P.Id as 'योजना नं',P.Name as 'योजनाको नाम '  ,Place AS  'ठेगाना',WardNo AS 'वडा नं',L.Name as 'विषयगत क्षेत्र',H.Name as 'शिर्षक',
                                    A.Name as 'उपशिर्षक',E.Name as 'स्रोत',P.BudgetAmount AS 'बजेट रकम',P.StartDate AS 'शुरु मिति',
                                    P.EndDate AS 'सम्पन्न मिति' 
                                     from Planning P
                                    inner join PlanSubject L
                                    on P.PlanSubject=L.Id
                                    inner join PlanHead H
                                    on P.PlanHead=H.Id
                                    inner join PlanSubHead A
                                    on P.PlanSubHead = A.Id 
                                    inner join PlanSource E
                                    on E.Id=P.PlanSource where P.FiscalYear='" + drpfiscalyear.SelectedValue + "'");
    }
}