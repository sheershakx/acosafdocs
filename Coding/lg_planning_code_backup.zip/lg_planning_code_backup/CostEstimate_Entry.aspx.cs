﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Inventory;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class CostEstimate_Entry : System.Web.UI.Page
{
    public static string guid = "";

    private void FxPlanningDetail(string id)
    {

        // sql1 = "";



        string sql = @"select * from Planning where Id= " + id + "";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    txtplace.Text = myreader["Place"].ToString();
                    txtward.Text = myreader["WardNo"].ToString();
                    txtfiscalyear.Text = myreader["FiscalYear"].ToString();
                    txtremarks.Text = myreader["Remarks"].ToString();



                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }





    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


          // txttargetdalit.Attributes.Add("Type", "Number");


         //   txtqty.Attributes.Add("Type", "Number");
        //    txtrate.Attributes.Add("Type", "Number");
          //  txttotal.Attributes.Add("Type", "Number");
            

            guid = System.Guid.NewGuid().ToString();
            Class1 a = new Class1();
            a.loadcombo(drpcostsource, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name  from CostSource", "Name", "ID");
          //  a.loadgrid(GridView1, "Select * from planHead");
           // a.loadgrid(GridView2, "Select * from planHead");
            a.loadcombo(drpplanning, "Select ID,(convert(nvarchar(10),ID) + ' - ' + Name) as Name from Planning", "Name", "Id");
        }
    }


    private void FxClear()
    {
        txtremarks.Text = "";

        Session["ID"] = "";
        // drpsubject.SelectedValue = "0";
        //drpstatus.SelectedValue = "0";
        btncostadd.Text = "Save";
        btndelete.Enabled = false;
        Class1 a = new Class1();
        a.loadgrid(GridView1, "Select * from planHead");

    }



    private void FxDelete()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_AnugamDelete", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
           // FxClear();
            Class1 a = new Class1();
            a.loadgrid(GridView1, @"select Id,Particular,Qty,Unit,Rate,Total from CostEstimationTemp where [Guid]='" + guid + "'");

        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }

    private void FxUpdate()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanHeadUpdate", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        //cmd.Parameters.Add("@SID", SqlDbType.VarChar, 100).Value = drpsubject.SelectedValue;

        //cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 500).Value = txttype.Text;

        cmd.Parameters.Add("@Description", SqlDbType.NVarChar, 500).Value = txtremarks.Text;
        //cmd.Parameters.Add("@Status", SqlDbType.VarChar, 200).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Updated Successfully !')", true);


        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }

    }


    private void FxSave()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_PlanHeadInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;

        // cmd.Parameters.Add("@SID", SqlDbType.VarChar, 100).Value = drpsubject.SelectedValue;

        //cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 300).Value = txttype.Text;

        cmd.Parameters.Add("@Description", SqlDbType.NVarChar, 500).Value = txtremarks.Text;
        //cmd.Parameters.Add("@Status", SqlDbType.VarChar, 200).Value = drpstatus.SelectedValue;
        cmd.Parameters.Add("@OfficeID", SqlDbType.VarChar, 40).Value = "1";// Session["OfficeID"].ToString();
        cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 40).Value = Session["USERNAME"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }
    protected void btnsave_Click(object sender, EventArgs e)
    {


        if (btncostadd.Text == "Save")
        {
            FxSave();
        }
        else if (btncostadd.Text == "Update")
        {
            FxUpdate();

        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView1.SelectedRow;
        Session["ID"] = row.Cells[1].Text;


        txtparticular.Text = row.Cells[1].Text;
        txtqty.Text = row.Cells[2].Text;
        txtunit.Text = row.Cells[3].Text;
        txtrate.Text = row.Cells[4].Text;
        txttotal.Text = row.Cells[5].Text;
        

      //  txtremarks.Text = Server.HtmlDecode(row.Cells[5].Text);
        btncostadd.Text = "Update";
        btndelete.Enabled = true;

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        FxClear();
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        FxDelete();
    }




    private void FxCostAdd()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("usp_CostEstimationTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@Particular", SqlDbType.VarChar, 40).Value = txtparticular.Text;
        cmd.Parameters.Add("@Qty", SqlDbType.VarChar, 40).Value = txtqty.Text;
        cmd.Parameters.Add("@Unit", SqlDbType.VarChar, 40).Value = txtunit.Text;
        cmd.Parameters.Add("@Rate", SqlDbType.VarChar, 40).Value = txtrate.Text;
        cmd.Parameters.Add("@Total", SqlDbType.VarChar, 40).Value = txttotal.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            Class1 a = new Class1();
            a.loadgrid(GridView1, @"select Id,Particular,Qty,Unit,Rate,Total from CostEstimationTemp where [Guid]='" + guid + "'");

           // FxClear();
          //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void FxCostSourceAdd()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("sp_CostEstimationSourceTempInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@PlanningId", SqlDbType.VarChar, 40).Value = drpplanning.SelectedValue;
        cmd.Parameters.Add("@Source", SqlDbType.VarChar, 40).Value = drpcostsource.SelectedValue;
        cmd.Parameters.Add("@Amount", SqlDbType.VarChar, 40).Value = txtcostsourceamount.Text;
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();

            Class1 a = new Class1();
            a.loadgrid(GridView2, @"select C.Id,P.Name as Source,Amount from CostEstimationSourceTemp C
                                    inner join CostSource P
                                    on C.Source=P.Id where [Guid]='" + guid + "'");

            // FxClear();
          //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    private void FxCostSaveAll()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_CostEstimationAll", con);
        cmd.CommandType = CommandType.StoredProcedure;
        
        cmd.Parameters.Add("@Guid", SqlDbType.VarChar, 40).Value = guid;

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();


            // FxClear();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }



    }


    protected void btncostadd_Click(object sender, EventArgs e)
    {
        FxCostAdd();
    }
    protected void btncostsource_Click(object sender, EventArgs e)
    {
        FxCostSourceAdd();
    }
    protected void btnsaveall_Click(object sender, EventArgs e)
    {
        FxCostSaveAll();
    }
    protected void drpplanning_SelectedIndexChanged(object sender, EventArgs e)
    {
        FxPlanningDetail(drpplanning.SelectedValue);
    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridView2.SelectedRow;
        Session["ID"] = row.Cells[1].Text;

        drpcostsource.SelectedValue = row.Cells[2].Text;
        txtcostsourceamount.Text = row.Cells[3].Text;

       // txtparticular.Text = row.Cells[1].Text;
      //  txtqty.Text = row.Cells[2].Text;
      //  txtunit.Text = row.Cells[3].Text;
      //  txtrate.Text = row.Cells[4].Text;
       // txttotal.Text = row.Cells[5].Text;


        //  txtremarks.Text = Server.HtmlDecode(row.Cells[5].Text);
       // btncostadd.Text = "Update";
      //  btndelete.Enabled = true;
    }
    protected void GridView2_SelectedIndexChanged1(object sender, EventArgs e)
    {
        GridViewRow row = GridView2.SelectedRow;
        Session["ID"] = row.Cells[1].Text;

        drpcostsource.SelectedItem.Text = row.Cells[2].Text;
        txtcostsourceamount.Text = row.Cells[3].Text;
    }
    protected void btndeleteforcost_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("s_CostEstimationSourceTemp", con);
        cmd.CommandType = CommandType.StoredProcedure;

        cmd.Parameters.Add("@Id", SqlDbType.VarChar, 40).Value = Session["ID"].ToString();

        try
        {
            con.Open();
            cmd.ExecuteNonQuery();
            Class1 a = new Class1();
            a.loadgrid(GridView2, @"select C.Id,P.Name as Source,Amount from CostEstimationSourceTemp C
                                    inner join CostSource P
                                    on C.Source=P.Id where [Guid]='" + guid + "'");

            // FxClear();
          //  ScriptManager.RegisterStartupScript(this, this.GetType(), "alertmessage", "javascript:alert('Data Saved Successfully !')", true);



        }
        catch (Exception ex)
        {
            lblerror.Text = ex.Message.ToString();
        }
        finally
        {
            con.Close();
        }


    }
}