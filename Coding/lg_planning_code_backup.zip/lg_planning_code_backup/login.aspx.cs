﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Response.Redirect("~/Dashboard.aspx");
        FxGetCompanyName();
    }




    private void FxGetCompanyName()
    {

        // sql1 = "";
        lblcompanyname.Text = "नमुना नगरपालिका/गाउँपालिका";


        string sql = @"select top 1 * from ControlTable";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {

            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    lblcompanyname.Text = "कर्जन्हा नगरपालिका ";// "उदयपुरगढी गाउपालिका";//"Demo"; //"गोलबजार नगरपालिका";// "बराहक्षेत्र नगरपालिका";//"Demo Office" ;//"हनुमाननगर कन्कालिन नगरपालिका"; //  myreader["CompanyName"].ToString();
                    Session["CompanyName"] = "कर्जन्हा नगरपालिका"; myreader["CompanyName"].ToString();
                   // string logo = myreader["LogoPath"].ToString();
                   // lbldate.Text = System.DateTime.Now.ToString();


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }


    private void FxLogin(string Url)
    {

        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString))
        using (SqlCommand cmd = new SqlCommand("S_LOGIN", con))
        {
            cmd.CommandType = CommandType.StoredProcedure;

            // set up the parameters
            cmd.Parameters.Add("@USERNAME", SqlDbType.VarChar, 40);
            cmd.Parameters.Add("@PASSWORD", SqlDbType.VarChar, 40);
            cmd.Parameters.Add("@LOGINTIME", SqlDbType.VarChar, 200);
            cmd.Parameters.Add("@IPADDRESS", SqlDbType.VarChar, 100);
            cmd.Parameters.Add("@RESULT", SqlDbType.VarChar, 5).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("@Name", SqlDbType.VarChar, 30).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("@ClientCode", SqlDbType.VarChar, 30).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("@WrongOutput", SqlDbType.VarChar, 30).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("@FiscalYear", SqlDbType.VarChar, 30).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("@Vat", SqlDbType.VarChar, 30).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("@date", SqlDbType.VarChar, 30).Direction = ParameterDirection.Output;
            cmd.Parameters.Add("@usergroup", SqlDbType.VarChar, 30).Direction = ParameterDirection.Output;


           // @usergroup

            // set parameter values
            cmd.Parameters["@USERNAME"].Value = txtusername.Text;
            cmd.Parameters["@PASSWORD"].Value = txtpassword.Text;
            cmd.Parameters["@LOGINTIME"].Value = "2016-01-01";
            cmd.Parameters["@IPADDRESS"].Value = "122";
            
            cmd.Parameters["@ClientCode"].Value = "1";
            cmd.Parameters["@WrongOutput"].Value = "1";
            cmd.Parameters["@FiscalYear"].Value = "1";
            cmd.Parameters["@Vat"].Value = "1";
            cmd.Parameters["@date"].Value = "1";
            cmd.Parameters["@usergroup"].Value = "1";
            // cmd.Parameters["@hpassword"].Value = MyNamespace.Class1.Encrypt(txtpassword.Text, true);

            // open connection and execute stored procedure
          
            con.Open();
            cmd.ExecuteNonQuery();
            string contractID = Convert.ToString(cmd.Parameters["@RESULT"].Value);



            if (contractID == "OK")
            {
                Session["USERNAME"] = txtusername.Text;
                Session["@ClientCode"] = Convert.ToString(cmd.Parameters["@ClientCode"].Value);

                Session["TodayDate"] = Convert.ToString(cmd.Parameters["@date"].Value);

                Session["@Name"] = Convert.ToString(cmd.Parameters["@Name"].Value);
                Session["@FiscalYear"] = Convert.ToString(cmd.Parameters["@FiscalYear"].Value);
                Session["@Vat"] = Convert.ToString(cmd.Parameters["@Vat"].Value);
                Session["UserGroup"] = Convert.ToString(cmd.Parameters["@usergroup"].Value);
                string ddk = Convert.ToString(cmd.Parameters["@ClientCode"].Value);
                Session["OfficeID"] = ddk;


                FxGetCompanyName(Session["USERNAME"].ToString());

                Response.Redirect(Url);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Information", "javascript:alert('Password not matched')", true);
                txtpassword.Text = "";
                txtusername.Text = "";
            }
        }

    }
    private void FxGetCompanyName(String LoginUserName)
    {

        string sql = @"select * from ControlTable C inner join UserTable U on U.OfficeID=C.ID where Username='" + LoginUserName + "'";

        string myconnection = ConfigurationManager.ConnectionStrings["CoreConnectionString"].ConnectionString;
        SqlConnection myconn = new SqlConnection(myconnection);

        //MySqlDataAdapter mydata = new MySqlDataAdapter();
        SqlDataReader myreader;

        SqlCommand SelectCommand = new SqlCommand(sql, myconn);
        try
        {
            myconn.Open();

            myreader = SelectCommand.ExecuteReader();
            // int count = 0;
            if (myreader.HasRows) //returing false but i have 4 row
            {
                while (myreader.Read()) //returing false 
                {

                    lblcompanyname.Text = myreader["OfficeName"].ToString();

                    Session["OfficeID"] = myreader["ID"].ToString();

                    //Session["OfficeCode"] = myreader["OfficeCode"].ToString();
                    Session["Head1"] = myreader["Head1"].ToString();
                    Session["Head2"] = myreader["Head2"].ToString();

                    Session["OfficeName"] = myreader["OfficeName"].ToString();

                    Session["Address"] = myreader["Address"].ToString();


                }
            }
            else
            {

                // P_No.Focus();
            }

        }
        catch (Exception ex)
        {

        }

        finally
        {
            myconn.Close();
        }

    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {
        string url = null;

        url = "~/Dashboard.aspx";
       // Response.Redirect("~/Dashboard.aspx");
        FxLogin(url);
    }
}