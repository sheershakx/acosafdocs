<?php
require "phpmysqlconnect.php";


$query="SELECT vcode FROM version";

$result=mysqli_query($con,$query);

if(mysqli_num_rows($result)>0)
{
	$row=mysqli_fetch_assoc($result);
	
	$vc=$row["vcode"];

	
$data["vc"]="$vc";
	echo json_encode($data); 
	#echo "Login Succesful";


   
   

}
else{
	echo "Sorry, user not found";
}

?>