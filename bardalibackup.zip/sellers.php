<?php
require "phpmysqlconnect.php";
$userid=$_POST["uid"];
$uname=$_POST["uname"];
$name=$_POST["name"];
$description=$_POST["desc"];
$quantity=$_POST["quantity"];
$unit=$_POST["unit"];
$total=$_POST["total"];
$delivery=$_POST["delivery"];
$imageurl=$_POST["imageurl"];
$status=$_POST["status"];


$query="INSERT INTO sellers_tab (userid,username,ItemName,ItemDesc,ItemQuantity,ItemUnit,ItemTotal,HomeDelivery,imageurl,status) VALUES ('$userid','$uname','$name','$description','$quantity','$unit','$total','$delivery','$imageurl','$status')";


 if ($con->query($query) === TRUE) {
    	
    	echo "Upload succesful";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$conn->close();

?>