<?php
require "phpmysqlconnect.php";
$userid=$_POST["userid"];
$latitude=$_POST["latitude"];
$longitude=$_POST["longitude"];

//$query="update location set coordinates='$locationid' where userid='$userid'";
$query="INSERT INTO location (userid,latitude,longitude) VALUES ('$userid','$latitude','$longitude')";


 if ($con->query($query) === TRUE) {
    	
    	echo "Upload succesful";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();

?>