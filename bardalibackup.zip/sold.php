<?php
require "phpmysqlconnect.php";
$itemid=$_REQUEST["itemid"];


$query="UPDATE sellers_tab SET status='1' where id like '$itemid'";

$result=mysqli_query($con,$query);

if(mysqli_num_rows($result)>0)
{
	
}
else{
	echo "Sorry, user not found";
}

?>