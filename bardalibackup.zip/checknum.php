<?php
require "phpmysqlconnect.php";
$mobile=$_POST["mobile"];

$query="SELECT * FROM authentication where mobile like '$mobile'";

$result=mysqli_query($con,$query);

if(mysqli_num_rows($result)>0)
{
    $row=mysqli_fetch_assoc($result);
    $mobile=$row["mobile"];
   
    $data["mobilenumber"] = $mobile;
   
   
    echo json_encode($data); 
    #echo "Login Succesful";

}
else{
    echo "Sorry, user not found";
}

?>