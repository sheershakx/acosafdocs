<?php
require "phpmysqlconnect.php";
$mobile=$_POST["mobile"];
$password=$_POST["password"];

$query="UPDATE authentication SET password='$password' where mobile='$mobile'";

$result=mysqli_query($con,$query);

if($con->query($query) === TRUE)
{
   $data["status"] ="successful";
   
   
    echo json_encode($data); 
    #echo "Login Succesful";

}
else{
    echo "Sorry, user not found";
}

?>