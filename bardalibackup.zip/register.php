
<?php
   require "phpmysqlconnect.php";
    $name=$_POST["name"];
    $mobile=$_POST["mobile"];
    $password=$_POST["password"]; 
  //  $hash=md5($password);

    $query="INSERT INTO authentication (mobile,password,name) VALUES('$mobile','$password','$name')";

    if ($con->query($query)=== TRUE) {

    	echo "Data inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>