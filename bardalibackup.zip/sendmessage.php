
<?php
   require "phpmysqlconnect.php";

  $senderId=$_POST["senderID"];
  $sendername=$_POST["sendername"];
$receiverId=$_POST["receiverID"];
$receivername=$_POST["receivername"];
$message=$_POST["message"];
$datetime=$_POST["datetime"];

    $query="INSERT INTO chat (senderId,sendername,receiverId,receivername,message,datetime) VALUES ('$senderId','$sendername','$receiverId','$receivername','$message','$datetime')";
    
    //  $query="INSERT INTO chat (senderId,sendername,receiverId,message,datetime) VALUES (12,'amit',23,'sdfsdfsdf','2019-10-24 00:00:00.00000')";


    if ($con->query($query)=== TRUE) {

    	echo "Data inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>