<?php
   require "phpmysqlconnect.php";
    $title=$_POST["title"];
    $image=$_POST["image"];

    $path="http://acosaf.000webhostapp.com/images/$title.jpg";
   
    $query="INSERT INTO imageinfo (title,imgpath) VALUES('$title','$path')";

    if ($con->query($query)=== TRUE) {

    	echo "Data inserted succesfully";

    }
    else{
    	echo "Error: ". $query. "<br>". $conn->error;
    }

$con->close();
    ?>