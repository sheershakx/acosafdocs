<?php
require "phpmysqlconnect.php";

$receiverId=$_POST["receiverID"];

$querysent="select * from chat where receiverId like '$receiverId' or senderId like '$receiverId' group by sendername";
// $querysent="select * from chat where id in (select max(id) from chat group by receiverId LIKE '$receiverId')";

// $querysent="SELECT * FROM chat WHERE receiverID like 26 GROUP BY sendername UNIOn SELECT * FROM chat WHERE senderId like 26 ORDER by id DESC";
// $querysent="SELECT * FROM chat WHERE receiverID like '$receiverId' GROUP BY sendername ORDER by id DESC";
//$queryreceived="SELECT * FROM chat WHERE senderId like '$receiverId' and receiverId like '$senderId'  ";

$resultsent=mysqli_query($con,$querysent);

// if(mysqli_num_rows($resultsent)>0)
// {
// 	$row=mysqli_fetch_assoc($resultsent);
// 	$name=$row["sendername"];
	
// 	$querynew="select message from chat where sendername like '$name' order by id desc";
// 	$resultnew=mysqli_query($con,$querynew);
// }
$json_array=array();
//$resultreceived=mysqli_query($con,$queryreceived);

while ($row=mysqli_fetch_assoc($resultsent)) {
	$json_array[]=$row;
}

echo json_encode($json_array); 

?>